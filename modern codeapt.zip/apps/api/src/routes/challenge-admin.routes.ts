/**
 * Daily-challenge admin routes — CRUD + Excel bulk import, behind the admin
 * guard stack (requireAuth + enforcePasswordChange + requireAdmin).
 */
import { Router } from "express";

import {
  adminBulkImportChallengesController,
  adminCreateChallengeController,
  adminDeleteChallengeController,
  adminGetChallengeController,
  adminListChallengesController,
  adminUpdateChallengeController,
} from "../controllers/challenge-admin.controller.js";
import { enforcePasswordChange } from "../middleware/enforce-password-change.js";
import { requireAdmin } from "../middleware/require-role.js";
import { requireAuth } from "../middleware/require-auth.js";

export const challengeAdminRouter: Router = Router();

const admin = [requireAuth, enforcePasswordChange, requireAdmin];

challengeAdminRouter.get(
  "/admin/challenges",
  ...admin,
  adminListChallengesController,
);
challengeAdminRouter.post(
  "/admin/challenges",
  ...admin,
  adminCreateChallengeController,
);
challengeAdminRouter.post(
  "/admin/challenges/bulk-import",
  ...admin,
  adminBulkImportChallengesController,
);
challengeAdminRouter.get(
  "/admin/challenges/:questionId",
  ...admin,
  adminGetChallengeController,
);
challengeAdminRouter.patch(
  "/admin/challenges/:questionId",
  ...admin,
  adminUpdateChallengeController,
);
challengeAdminRouter.delete(
  "/admin/challenges/:questionId",
  ...admin,
  adminDeleteChallengeController,
);
