/**
 * Root API router. Mounts every feature router under `/api`.
 * Feature routers (auth, courses, exams, …) are added in later steps.
 */
import { Router } from "express";

import { adminRouter } from "./admin.routes.js";
import { authRouter } from "./auth.routes.js";
import { challengeRouter } from "./challenge.routes.js";
import { challengeAdminRouter } from "./challenge-admin.routes.js";
import { careersRouter } from "./careers.routes.js";
import { couponRouter } from "./coupon.routes.js";
import { curriculumRouter } from "./curriculum.routes.js";
import { essayRouter } from "./essay.routes.js";
import { essayTopicRouter } from "./essay-topic.routes.js";
import { essayAnalyticsAdminRouter } from "./essay-analytics-admin.routes.js";
import { examRouter } from "./exam.routes.js";
import { paymentRouter } from "./payment.routes.js";
import { executionRouter } from "./execution.routes.js";
import { healthRouter } from "./health.routes.js";
import { meRouter } from "./me.routes.js";
import { orderAdminRouter } from "./order-admin.routes.js";
import { uploadAdminRouter } from "./upload-admin.routes.js";
import { userAdminRouter } from "./user-admin.routes.js";

export const apiRouter: Router = Router();

apiRouter.use(healthRouter);
apiRouter.use(authRouter);
apiRouter.use(meRouter);
apiRouter.use(curriculumRouter);
apiRouter.use(executionRouter);
apiRouter.use(challengeRouter);
apiRouter.use(challengeAdminRouter);
apiRouter.use(examRouter);
apiRouter.use(essayRouter);
apiRouter.use(essayTopicRouter);
apiRouter.use(essayAnalyticsAdminRouter);
apiRouter.use(paymentRouter);
apiRouter.use(careersRouter);
apiRouter.use(couponRouter);
apiRouter.use(userAdminRouter);
apiRouter.use(orderAdminRouter);
apiRouter.use(uploadAdminRouter);
apiRouter.use(adminRouter);
