/**
 * Essay service — browse prompts, submit for grading, poll/finalize, history.
 *
 * Grading rides the async pipeline: `submit` creates an EssayAttempt
 * (gradingStatus=queued) + an ExecutionJob row and enqueues a `grade-essay`
 * job on the `default` queue, then returns a JobRef FAST. The worker computes
 * the deterministic floor (+ optional AI blend) and writes the scores back onto
 * the attempt. `getGradingResult` reports status idempotently and never mutates
 * grading state (the worker owns the write; finalize here is read-only).
 *
 * Reference keywords / rubric internals NEVER leave this layer — student
 * projections omit `semanticKeywords` entirely.
 */
import { randomUUID } from "node:crypto";

import {
  EssayErrorCode,
  EssayGradingStatus,
  ESSAY_DEFAULT_MIN_WORDS,
  JobStatus,
  QueueName,
  TopicType,
  computeEssayRisk,
  countWords,
  computeTextStats,
  type EssayAnalyticsInput,
  type EssayDimensionScoresDto,
  type EssayDraftResponse,
  type EssayGradingResult,
  type EssayListResponse,
  type EssayPromptDetail,
  type EssayPromptSummary,
  type EssayScoreSource,
  type EssaySubmissionListResponse,
  type EssaySubmissionSummary,
  type JobRef,
  type SaveEssayDraftResponse,
} from "@codeapt/shared";
import { Types, type HydratedDocument } from "mongoose";

import { AppError } from "../errors/app-error.js";
import { enqueueEssayGradingJob } from "../lib/execution-queue.js";
import {
  EnrollmentModel,
  ModuleModel,
  TopicModel,
} from "../models/curriculum.model.js";
import {
  EssayAnalyticsModel,
  EssayAttemptModel,
  EssayDraftModel,
  EssayTopicModel,
  type EssayAttempt,
  type EssayTopic,
} from "../models/essay.model.js";
import { ExecutionJobModel } from "../models/execution.model.js";

type TopicDoc = HydratedDocument<EssayTopic>;
type AttemptDoc = HydratedDocument<EssayAttempt>;

// ---------------------------------------------------------------------------
// Enrollment → essay-topic resolution
// ---------------------------------------------------------------------------

/**
 * The set of EssayTopic ids reachable through the user's enrollments: enrolled
 * subject → module → curriculum Topic (type `essay`) → its `essayTopic` ref.
 */
async function enrolledEssayTopicIds(
  userId: string,
): Promise<Types.ObjectId[]> {
  const enrollments = await EnrollmentModel.find({ user: userId }).select(
    "subject",
  );
  const subjectIds = enrollments.map((e) => e.subject);
  if (subjectIds.length === 0) return [];

  const modules = await ModuleModel.find({
    subject: { $in: subjectIds },
  }).select("_id");
  const topics = await TopicModel.find({
    module: { $in: modules.map((m) => m._id) },
    topicType: TopicType.ESSAY,
  }).select("essayTopic");

  return topics
    .map((t) => t.essayTopic)
    .filter((id): id is Types.ObjectId => id != null);
}

/** The curriculum Topic (type essay) that points at a given EssayTopic. */
async function curriculumTopicIdFor(
  essayTopicId: Types.ObjectId,
): Promise<string | null> {
  const topic = await TopicModel.findOne({
    essayTopic: essayTopicId,
    topicType: TopicType.ESSAY,
  }).select("_id");
  return topic ? topic._id.toString() : null;
}

// ---------------------------------------------------------------------------
// Projections (STUDENT — no reference keywords / rubric)
// ---------------------------------------------------------------------------

const ESSAY_GRADING_STATUS_SET = new Set<EssayGradingStatus>([
  EssayGradingStatus.QUEUED,
  EssayGradingStatus.PROCESSING,
  EssayGradingStatus.COMPLETED,
  EssayGradingStatus.FAILED,
]);
const asGradingStatus = (s: string): EssayGradingStatus =>
  ESSAY_GRADING_STATUS_SET.has(s as EssayGradingStatus)
    ? (s as EssayGradingStatus)
    : EssayGradingStatus.QUEUED;

function toSummary(
  topic: TopicDoc,
  topicId: string,
  last: AttemptDoc | null,
  attemptsUsed: number,
): EssayPromptSummary {
  return {
    id: topic._id.toString(),
    topicId,
    title: topic.title,
    description: topic.description,
    // difficultyLevel is 1|2|3 in the schema; the union type mirrors that.
    difficultyLevel: (topic.difficultyLevel ?? 1) as 1 | 2 | 3,
    minWords: topic.minWords,
    maxWords: topic.maxWords,
    timeLimitMinutes: topic.timeLimitMinutes,
    maxAttempts: topic.maxAttempts ?? 3,
    attemptsUsed,
    lastAttempt: last
      ? {
          id: last._id.toString(),
          attemptNumber: last.attemptNumber,
          status: asGradingStatus(last.gradingStatus),
          finalScore:
            last.gradingStatus === JobStatus.COMPLETED ? last.finalScore : null,
          source: (last.scoreSource as EssayScoreSource | null) ?? null,
        }
      : null,
  };
}

async function latestAttempt(
  userId: string,
  essayTopicId: Types.ObjectId,
): Promise<AttemptDoc | null> {
  return EssayAttemptModel.findOne({
    user: new Types.ObjectId(userId),
    essayTopic: essayTopicId,
  }).sort({ attemptNumber: -1 });
}

/**
 * How many attempts the user has already SUBMITTED for a topic. Every
 * EssayAttempt row is a real submission (drafts live in a separate collection),
 * so a document count is the attempt count — this drives the per-topic cap.
 */
async function countAttempts(
  userId: string,
  essayTopicId: Types.ObjectId,
): Promise<number> {
  return EssayAttemptModel.countDocuments({
    user: new Types.ObjectId(userId),
    essayTopic: essayTopicId,
  });
}

// ---------------------------------------------------------------------------
// Browse
// ---------------------------------------------------------------------------

export async function listEssays(userId: string): Promise<EssayListResponse> {
  const essayTopicIds = await enrolledEssayTopicIds(userId);
  if (essayTopicIds.length === 0) return { items: [] };

  const topics = await EssayTopicModel.find({
    _id: { $in: essayTopicIds },
    isActive: true,
  });

  const items: EssayPromptSummary[] = [];
  for (const topic of topics) {
    const topicId = await curriculumTopicIdFor(topic._id);
    if (!topicId) continue;
    const [last, attemptsUsed] = await Promise.all([
      latestAttempt(userId, topic._id),
      countAttempts(userId, topic._id),
    ]);
    items.push(toSummary(topic, topicId, last, attemptsUsed));
  }
  return { items };
}

/** Load an essay prompt the user may access (enrolled + active), or 404. */
async function requireAccessibleTopic(
  userId: string,
  essayTopicId: string,
): Promise<TopicDoc> {
  if (!Types.ObjectId.isValid(essayTopicId)) {
    throw new AppError("Essay not found", 404, EssayErrorCode.ESSAY_NOT_FOUND);
  }
  const allowed = await enrolledEssayTopicIds(userId);
  const inScope = allowed.some((id) => id.toString() === essayTopicId);
  const topic = await EssayTopicModel.findById(essayTopicId);
  if (!topic || !topic.isActive || !inScope) {
    throw new AppError("Essay not found", 404, EssayErrorCode.ESSAY_NOT_FOUND);
  }
  return topic;
}

export async function getEssayDetail(
  userId: string,
  essayTopicId: string,
): Promise<EssayPromptDetail> {
  const topic = await requireAccessibleTopic(userId, essayTopicId);
  const topicId = await curriculumTopicIdFor(topic._id);
  if (!topicId) {
    throw new AppError("Essay not found", 404, EssayErrorCode.ESSAY_NOT_FOUND);
  }
  const [last, attemptsUsed] = await Promise.all([
    latestAttempt(userId, topic._id),
    countAttempts(userId, topic._id),
  ]);
  return {
    ...toSummary(topic, topicId, last, attemptsUsed),
    instructions: topic.instructions,
  };
}

// ---------------------------------------------------------------------------
// Autosave drafts (recovery buffer — NEVER submits, grades, or consumes an
// attempt). Drafts are keyed by (user, essayTopic) because the attempt does not
// exist until submit. The latest N snapshots per (user, topic) are retained.
// ---------------------------------------------------------------------------

/** How many draft snapshots to retain per (user, topic) — matches the original. */
const DRAFT_HISTORY_LIMIT = 10;

/**
 * Snapshot the current essay text as a draft. Access-scoped exactly like
 * compose (enrolled + active topic → else 404); the word count is recomputed
 * server-side. Older snapshots beyond DRAFT_HISTORY_LIMIT are pruned so growth
 * is bounded. This touches nothing the grader reads/writes and never creates an
 * attempt.
 */
export async function saveDraft(
  userId: string,
  essayTopicId: string,
  content: string,
): Promise<SaveEssayDraftResponse> {
  const topic = await requireAccessibleTopic(userId, essayTopicId);
  const wordCount = countWords(content);
  const savedAt = new Date();

  await EssayDraftModel.create({
    user: new Types.ObjectId(userId),
    essayTopic: topic._id,
    content,
    wordCount,
    savedAt,
  });

  // Keep only the latest N snapshots for this (user, topic); prune the rest.
  // Tie-break on _id so ordering is stable even for same-millisecond saves.
  const stale = await EssayDraftModel.find({
    user: new Types.ObjectId(userId),
    essayTopic: topic._id,
  })
    .sort({ savedAt: -1, _id: -1 })
    .skip(DRAFT_HISTORY_LIMIT)
    .select("_id");
  if (stale.length > 0) {
    await EssayDraftModel.deleteMany({
      _id: { $in: stale.map((d) => d._id) },
    });
  }

  return { savedAt: savedAt.toISOString(), wordCount };
}

/**
 * The latest recoverable draft for a prompt, or null when there is nothing to
 * restore. A draft is suppressed once the student has SUBMITTED after it (a
 * later attempt exists), so recovery never resurrects an already-submitted
 * essay.
 */
export async function getLatestDraft(
  userId: string,
  essayTopicId: string,
): Promise<EssayDraftResponse> {
  const topic = await requireAccessibleTopic(userId, essayTopicId);
  const draft = await EssayDraftModel.findOne({
    user: new Types.ObjectId(userId),
    essayTopic: topic._id,
  }).sort({ savedAt: -1, _id: -1 });
  if (!draft) return { draft: null };

  const last = await latestAttempt(userId, topic._id);
  const draftAt = draft.savedAt ?? new Date(0);
  if (last?.submittedAt && last.submittedAt >= draftAt) {
    return { draft: null };
  }

  return {
    draft: {
      content: draft.content ?? "",
      wordCount: draft.wordCount ?? 0,
      savedAt: draftAt.toISOString(),
    },
  };
}

// ---------------------------------------------------------------------------
// Submit (enqueue grading)
// ---------------------------------------------------------------------------

export async function submitEssay(
  userId: string,
  essayTopicId: string,
  content: string,
  meta: { ipAddress?: string; userAgent?: string } = {},
): Promise<JobRef> {
  const topic = await requireAccessibleTopic(userId, essayTopicId);

  // Enforce the per-topic attempt cap BEFORE doing any work. Every attempt row
  // is a real submission (drafts are separate), so a count is the used-count.
  const maxAttempts = topic.maxAttempts ?? 3;
  const attemptsUsed = await countAttempts(userId, topic._id);
  if (attemptsUsed >= maxAttempts) {
    throw new AppError(
      `You have reached the attempt limit for this essay (${maxAttempts})`,
      409,
      EssayErrorCode.ATTEMPT_LIMIT_REACHED,
    );
  }

  // Enforce the prompt's WORD bounds (char ceiling is enforced by the schema).
  const wordCount = countWords(content);
  const minWords = Math.max(topic.minWords || 0, ESSAY_DEFAULT_MIN_WORDS);
  if (wordCount < minWords) {
    throw new AppError(
      `Essay must be at least ${minWords} words (got ${wordCount})`,
      422,
      EssayErrorCode.LENGTH_OUT_OF_RANGE,
    );
  }
  if (topic.maxWords > 0 && wordCount > topic.maxWords) {
    throw new AppError(
      `Essay must be at most ${topic.maxWords} words (got ${wordCount})`,
      422,
      EssayErrorCode.LENGTH_OUT_OF_RANGE,
    );
  }

  // Next attempt number for this (user, topic) — resubmission is allowed.
  const previous = await latestAttempt(userId, topic._id);
  const attemptNumber = (previous?.attemptNumber ?? 0) + 1;

  const stats = computeTextStats(content);
  const jobId = randomUUID();

  const attempt = await EssayAttemptModel.create({
    user: new Types.ObjectId(userId),
    essayTopic: topic._id,
    attemptNumber,
    status: "SUBMITTED",
    content,
    wordCount: stats.wordCount,
    characterCount: stats.characterCount,
    paragraphCount: stats.paragraphCount,
    gradingStatus: JobStatus.QUEUED,
    gradingJobId: jobId,
    submittedAt: new Date(),
    ipAddress: meta.ipAddress ?? "",
    userAgent: meta.userAgent ?? "",
  });

  await ExecutionJobModel.create({
    jobId,
    user: new Types.ObjectId(userId),
    submissionRef: `essay:${attempt._id.toString()}`,
    queue: QueueName.DEFAULT,
    status: JobStatus.QUEUED,
  });

  await enqueueEssayGradingJob({ jobId, attemptId: attempt._id.toString() });

  return { jobId, status: JobStatus.QUEUED };
}

// ---------------------------------------------------------------------------
// Grading status / result (read-only, idempotent)
// ---------------------------------------------------------------------------

export async function getGradingResult(
  userId: string,
  jobId: string,
): Promise<EssayGradingResult> {
  const attempt = await EssayAttemptModel.findOne({ gradingJobId: jobId });
  if (!attempt) {
    throw new AppError(
      "Submission not found",
      404,
      EssayErrorCode.SUBMISSION_NOT_FOUND,
    );
  }
  if (attempt.user.toString() !== userId) {
    throw new AppError(
      "You do not own this submission",
      403,
      EssayErrorCode.NOT_AUTHORIZED,
    );
  }

  const job = await ExecutionJobModel.findOne({ jobId });
  const status = asGradingStatus(attempt.gradingStatus);
  const completed = status === EssayGradingStatus.COMPLETED;
  const failed = status === EssayGradingStatus.FAILED;

  const dimensions: EssayDimensionScoresDto | null = completed
    ? {
        grammar: attempt.subScores?.grammar ?? 0,
        spelling: attempt.subScores?.spelling ?? 0,
        punctuation: attempt.subScores?.punctuation ?? 0,
        readability: attempt.subScores?.readability ?? 0,
        vocabulary: attempt.subScores?.vocabulary ?? 0,
        structure: attempt.subScores?.structure ?? 0,
        relevance: attempt.subScores?.relevance ?? 0,
      }
    : null;

  return {
    jobId,
    submissionId: attempt._id.toString(),
    status,
    gradingPending: !completed && !failed,
    total: completed ? attempt.finalScore : null,
    dimensions,
    source: completed
      ? ((attempt.scoreSource as EssayScoreSource | null) ?? null)
      : null,
    feedback: completed ? attempt.feedback || null : null,
    wordCount: attempt.wordCount,
    error: failed ? (job?.error ?? "Grading failed") : null,
  };
}

// ---------------------------------------------------------------------------
// Submission history
// ---------------------------------------------------------------------------

export async function listSubmissions(
  userId: string,
  essayTopicId: string,
): Promise<EssaySubmissionListResponse> {
  const topic = await requireAccessibleTopic(userId, essayTopicId);
  const attempts = await EssayAttemptModel.find({
    user: new Types.ObjectId(userId),
    essayTopic: topic._id,
  }).sort({ attemptNumber: -1 });

  const items: EssaySubmissionSummary[] = attempts.map((a) => {
    const completed = a.gradingStatus === JobStatus.COMPLETED;
    return {
      id: a._id.toString(),
      jobId: a.gradingJobId ?? null,
      attemptNumber: a.attemptNumber,
      status: asGradingStatus(a.gradingStatus),
      finalScore: completed ? a.finalScore : null,
      source: (a.scoreSource as EssayScoreSource | null) ?? null,
      wordCount: a.wordCount,
      submittedAt: a.submittedAt ? a.submittedAt.toISOString() : null,
      gradedAt: a.gradedAt ? a.gradedAt.toISOString() : null,
    };
  });

  return { promptId: topic._id.toString(), items };
}

// ---------------------------------------------------------------------------
// Writing analytics (Step 11) — ADDITIVE + OPTIONAL, never affects grading.
// ---------------------------------------------------------------------------

/**
 * Persist optional compose analytics for a submission. Fully decoupled from
 * grading: it writes to the EssayAnalytics sidecar (1-to-1 with the attempt)
 * and touches NOTHING the grader reads or writes. The grade is identical
 * whether or not this is ever called. Ownership is enforced via the attempt.
 */
export async function recordAnalytics(
  userId: string,
  jobId: string,
  input: EssayAnalyticsInput,
): Promise<void> {
  const attempt = await EssayAttemptModel.findOne({ gradingJobId: jobId });
  if (!attempt) {
    throw new AppError(
      "Submission not found",
      404,
      EssayErrorCode.SUBMISSION_NOT_FOUND,
    );
  }
  if (attempt.user.toString() !== userId) {
    throw new AppError(
      "You do not own this submission",
      403,
      EssayErrorCode.NOT_AUTHORIZED,
    );
  }

  // Compute the ADVISORY risk assessment server-side from the incoming signals
  // (never a client-supplied score). Purely a review aid — it does not touch
  // grading, the attempt, or the submission in any way.
  const risk = computeEssayRisk({
    keystrokes: input.keystrokes,
    deletes: input.deletes,
    pasteEvents: input.pasteCount,
    pastedChars: input.pastedChars,
    composeSeconds: input.composeSeconds,
    wordCount: input.wordCount,
    characterCount: input.characterCount,
  });

  await EssayAnalyticsModel.updateOne(
    { attempt: attempt._id },
    {
      $set: {
        typingEvents: input.keystrokes,
        deleteEvents: input.deletes,
        pasteEvents: input.pasteCount,
        pastedChars: input.pastedChars,
        composeSeconds: input.composeSeconds,
        finalWordCount: input.wordCount,
        finalCharacterCount: input.characterCount,
        riskScore: risk.riskScore,
        riskLevel: risk.level,
        suspiciousActivity: risk.suspicious,
        riskReasons: risk.reasons,
      },
    },
    { upsert: true },
  );
}
