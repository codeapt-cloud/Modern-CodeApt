/**
 * Careers / placements: Job (posting) and JobApplication.
 *
 * Extends the Step-1 shape minimally (flagged in the Step-14 report):
 *  - `employmentType` is now a typed PostingType (was free text).
 *  - `compensation` free-text field (the source had no monetary field; campus
 *    postings quote ranges/LPA text, so paise would be awkward).
 *  - `deadline` (nullable) application deadline.
 * No eligibility rules exist in the source, so none are modeled.
 */
import { Schema, model, type InferSchemaType } from "mongoose";
import {
  JOB_APPLICATION_STATUS_VALUES,
  JobApplicationStatus,
  POSTING_TYPE_VALUES,
  PostingType,
} from "@codeapt/shared";

// --- Job (posting) -----------------------------------------------------------
const jobSchema = new Schema(
  {
    title: { type: String, required: true, trim: true },
    company: { type: String, required: true, trim: true },
    companyLogo: { type: String, default: "" },
    location: { type: String, default: "" },
    employmentType: {
      type: String,
      enum: POSTING_TYPE_VALUES,
      default: PostingType.FULL_TIME,
    },
    // Free-text compensation, e.g. "₹12 LPA" / "₹25k/month stipend".
    compensation: { type: String, default: "" },
    description: { type: String, default: "" },
    requirements: { type: String, default: "" },
    applyUrl: { type: String, default: "" },
    // Application deadline; null/absent = the posting never closes on time.
    deadline: { type: Date, default: null },
    isActive: { type: Boolean, default: true },
    postedAt: { type: Date, default: () => new Date() },
  },
  { timestamps: true },
);
jobSchema.index({ isActive: 1, postedAt: -1 });
export type Job = InferSchemaType<typeof jobSchema>;
export const JobModel = model("Job", jobSchema);

// --- JobApplication ----------------------------------------------------------
const jobApplicationSchema = new Schema(
  {
    job: { type: Schema.Types.ObjectId, ref: "Job", required: true },
    // Nullable: public tracking by email is supported (track_application).
    user: { type: Schema.Types.ObjectId, ref: "User" },
    fullName: { type: String, required: true, trim: true },
    email: { type: String, required: true, lowercase: true, trim: true },
    phone: { type: String, default: "" },
    resumeUrl: { type: String, default: "" },
    coverLetter: { type: String, default: "" },
    status: {
      type: String,
      enum: JOB_APPLICATION_STATUS_VALUES,
      default: JobApplicationStatus.SUBMITTED,
    },
  },
  { timestamps: true },
);
jobApplicationSchema.index({ job: 1, email: 1 });
jobApplicationSchema.index({ user: 1 });
// A logged-in student applies at most once per posting (Step-14). Partial so
// anonymous (user=null) email-tracked applications are unaffected.
jobApplicationSchema.index(
  { job: 1, user: 1 },
  { unique: true, partialFilterExpression: { user: { $exists: true } } },
);
export type JobApplication = InferSchemaType<typeof jobApplicationSchema>;
export const JobApplicationModel = model(
  "JobApplication",
  jobApplicationSchema,
);
