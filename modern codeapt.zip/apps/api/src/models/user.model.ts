/**
 * User & Profile.
 *
 * We split auth (User) from profile data (Profile), mirroring Django's
 * User + core.Profile 1-to-1 relationship. `forcePasswordChange` moves onto
 * User because it gates the auth flow (it lived on Profile in Django only
 * because Django's User wasn't extended).
 *
 * References over embedding: Profile is a separate collection so auth reads
 * (hot path) don't drag profile blobs, and so admin can query profiles freely.
 */
import { Schema, model, type InferSchemaType } from "mongoose";
import { ROLE_VALUES, Role } from "@codeapt/shared";

const userSchema = new Schema(
  {
    // Login identifier (case preserved); also drives the default avatar.
    username: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    email: {
      type: String,
      required: true,
      lowercase: true,
      trim: true,
    },
    passwordHash: { type: String, required: true },
    role: { type: String, enum: ROLE_VALUES, default: Role.STUDENT },
    isActive: { type: Boolean, default: true },
    forcePasswordChange: { type: Boolean, default: false },
    // Bumped to revoke ALL sessions at once (embedded in every token).
    tokenVersion: { type: Number, default: 0 },
    lastLoginAt: { type: Date },
  },
  { timestamps: true },
);

// username is unique via its field option. email is PARTIAL-unique: migrated
// legacy accounts may have a blank email (a valid state), so uniqueness is
// enforced only on non-empty values ({ $gt: "" } excludes "" and missing).
userSchema.index(
  { email: 1 },
  { unique: true, partialFilterExpression: { email: { $gt: "" } } },
);
userSchema.index({ role: 1 });

export type User = InferSchemaType<typeof userSchema>;
export const UserModel = model("User", userSchema);

const profileSchema = new Schema(
  {
    user: {
      type: Schema.Types.ObjectId,
      ref: "User",
      required: true,
      unique: true,
    },
    fullName: { type: String, required: true, trim: true },
    collegeName: { type: String, trim: true },
    // roll_number uniqueness was enforced at registration in Django. Partial-
    // unique here: migrated staff/older profiles may have a blank roll number.
    rollNumber: { type: String, required: true, trim: true },
    phoneNumber: { type: String, trim: true },
    state: { type: String, trim: true },
    bio: { type: String, default: "" },
    // Defaulted to a ui-avatars URL by the service layer on creation.
    avatarUrl: { type: String, default: "" },
  },
  { timestamps: true },
);
// PARTIAL-unique roll number: migrated staff/older profiles may legitimately
// have a blank roll number, so uniqueness is enforced only on non-empty values.
profileSchema.index(
  { rollNumber: 1 },
  { unique: true, partialFilterExpression: { rollNumber: { $gt: "" } } },
);

export type Profile = InferSchemaType<typeof profileSchema>;
export const ProfileModel = model("Profile", profileSchema);
