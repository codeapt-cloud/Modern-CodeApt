/**
 * Role guards. Must run AFTER requireAuth (they read `req.auth`).
 */
import { AuthErrorCode, Role, type Role as RoleType } from "@codeapt/shared";
import type { RequestHandler } from "express";

import { AppError } from "../errors/app-error.js";

export function requireRole(...roles: RoleType[]): RequestHandler {
  return (req, _res, next) => {
    if (!req.auth) {
      throw new AppError(
        "Authentication required",
        401,
        AuthErrorCode.UNAUTHENTICATED,
      );
    }
    if (!roles.includes(req.auth.role)) {
      throw new AppError(
        "You do not have permission to access this resource",
        403,
        AuthErrorCode.FORBIDDEN,
      );
    }
    next();
  };
}

export const requireAdmin = requireRole(Role.ADMIN);
