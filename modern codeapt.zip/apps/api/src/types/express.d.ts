/**
 * Ambient augmentation: `req.auth` is populated by the requireAuth middleware.
 */
import type { Role } from "@codeapt/shared";

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      auth?: {
        userId: string;
        role: Role;
        forcePasswordChange: boolean;
      };
      /** Raw request body bytes, captured for signature-verified webhooks. */
      rawBody?: string;
    }
  }
}

export {};
