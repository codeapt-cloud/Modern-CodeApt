/**
 * Admin bulk-enroll controller (requireAdmin at the route). Validates with the
 * shared zod schema and delegates to the enrollment-admin service.
 */
import { bulkEnrollRequestSchema } from "@codeapt/shared";
import type { Request, Response } from "express";

import { asyncHandler } from "../lib/async-handler.js";
import { bulkEnrollFromRoster } from "../services/enrollment-admin.service.js";

export const adminBulkEnrollController = asyncHandler(
  async (req: Request, res: Response) => {
    const { subjectIds, fileBase64 } = bulkEnrollRequestSchema.parse(req.body);
    res.status(200).json(await bulkEnrollFromRoster(subjectIds, fileBase64));
  },
);
