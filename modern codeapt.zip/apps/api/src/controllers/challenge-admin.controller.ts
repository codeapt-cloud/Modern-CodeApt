/**
 * Daily-challenge ADMIN controllers (requireAdmin at the route). Validate with
 * the shared zod schemas and delegate to the challenge-admin service.
 */
import {
  adminChallengeBulkImportRequestSchema,
  adminChallengeUpsertSchema,
} from "@codeapt/shared";
import type { Request, Response } from "express";

import { asyncHandler } from "../lib/async-handler.js";
import * as admin from "../services/challenge-admin.service.js";

export const adminListChallengesController = asyncHandler(
  async (_req: Request, res: Response) => {
    res.status(200).json(await admin.listChallengesAdmin());
  },
);

export const adminGetChallengeController = asyncHandler(
  async (req: Request, res: Response) => {
    res
      .status(200)
      .json(await admin.getChallengeAdmin(req.params.questionId ?? ""));
  },
);

export const adminCreateChallengeController = asyncHandler(
  async (req: Request, res: Response) => {
    const input = adminChallengeUpsertSchema.parse(req.body);
    res.status(201).json(await admin.createChallenge(input));
  },
);

export const adminUpdateChallengeController = asyncHandler(
  async (req: Request, res: Response) => {
    const input = adminChallengeUpsertSchema.parse(req.body);
    res
      .status(200)
      .json(await admin.updateChallenge(req.params.questionId ?? "", input));
  },
);

export const adminDeleteChallengeController = asyncHandler(
  async (req: Request, res: Response) => {
    res
      .status(200)
      .json(await admin.deleteChallenge(req.params.questionId ?? ""));
  },
);

export const adminBulkImportChallengesController = asyncHandler(
  async (req: Request, res: Response) => {
    const { fileBase64, startDate } =
      adminChallengeBulkImportRequestSchema.parse(req.body);
    res.status(200).json(await admin.bulkImportChallenges(fileBase64, startDate));
  },
);
