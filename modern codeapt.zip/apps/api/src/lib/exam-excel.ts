/**
 * Excel tooling for exam authoring: parse a bulk-upload workbook into
 * sections/questions/test cases (with per-row validation), and build a results
 * export workbook. Uses ExcelJS (streaming-capable, pure JS, no native deps).
 *
 * Upload workbook shape:
 *   Sheet "Questions": section | sectionOrder | sectionDuration | order | type
 *     | text | marks | option1..option5 | correctOptions | starterCode
 *     | language | allowedLanguages | ref
 *   Sheet "TestCases": ref | input | expectedOutput | hidden
 * `correctOptions` is a comma-separated 1-BASED list (human-friendly), converted
 * to 0-based indices. `ref` links a CODE question to its test-case rows.
 * `allowedLanguages` is the CODE language policy: blank / "all" / "open" = OPEN
 * (any language); a single language = LOCKED to it. A sheet WITHOUT the column
 * imports every CODE question as OPEN (backward-compatible with old templates).
 */
import {
  CODE_LANGUAGE_VALUES,
  EXAM_QUESTION_TYPE_VALUES,
  ExamQuestionType,
  type CodeLanguage,
  type ExamQuestionType as ExamQuestionTypeT,
} from "@codeapt/shared";
import ExcelJS from "exceljs";

export interface ParsedTestCase {
  input: string;
  expectedOutput: string;
  isHidden: boolean;
}
export interface ParsedQuestion {
  ref: string;
  sectionName: string;
  sectionOrder: number;
  sectionDuration: number;
  order: number;
  type: ExamQuestionTypeT;
  text: string;
  marks: number;
  options?: string[];
  correctOptions?: number[];
  starterCode: string;
  language: CodeLanguage;
  /** [] = open (any language), [lang] = locked. */
  allowedLanguages: CodeLanguage[];
  testCases: ParsedTestCase[];
}
export interface RowError {
  sheet: string;
  row: number;
  message: string;
}
export interface ParseResult {
  questions: ParsedQuestion[];
  errors: RowError[];
}

function cellString(row: ExcelJS.Row, col: number): string {
  const v = row.getCell(col).value;
  if (v === null || v === undefined) return "";
  if (typeof v === "object" && "text" in v) return String(v.text);
  return String(v).trim();
}
function cellNumber(row: ExcelJS.Row, col: number): number | null {
  const v = row.getCell(col).value;
  if (typeof v === "number") return v;
  const n = Number(cellString(row, col));
  return Number.isFinite(n) ? n : null;
}

/** Map a header row to { columnName: index } (1-based). */
function headerIndex(row: ExcelJS.Row): Record<string, number> {
  const map: Record<string, number> = {};
  row.eachCell((cell, col) => {
    const name = String(cell.value ?? "").trim();
    if (name) map[name] = col;
  });
  return map;
}

export async function parseQuestionWorkbook(
  buffer: Buffer,
): Promise<ParseResult> {
  const wb = new ExcelJS.Workbook();
  // ExcelJS bundles an older non-generic `Buffer` type than @types/node's
  // generic one; the value is a real Node Buffer, safe at runtime.
  await wb.xlsx.load(buffer as unknown as Parameters<typeof wb.xlsx.load>[0]);
  const errors: RowError[] = [];

  const qSheet = wb.getWorksheet("Questions");
  if (!qSheet) {
    return {
      questions: [],
      errors: [
        { sheet: "Questions", row: 0, message: "Missing 'Questions' sheet" },
      ],
    };
  }

  // --- Test cases (grouped by ref) ---
  const casesByRef = new Map<string, ParsedTestCase[]>();
  const tcSheet = wb.getWorksheet("TestCases");
  if (tcSheet) {
    const h = headerIndex(tcSheet.getRow(1));
    tcSheet.eachRow((row, rowNumber) => {
      if (rowNumber === 1) return;
      const ref = cellString(row, h.ref ?? 1);
      if (!ref) return;
      const list = casesByRef.get(ref) ?? [];
      list.push({
        input: cellString(row, h.input ?? 2),
        expectedOutput: cellString(row, h.expectedOutput ?? 3),
        isHidden: /^(true|1|yes|hidden)$/i.test(cellString(row, h.hidden ?? 4)),
      });
      casesByRef.set(ref, list);
    });
  }

  // --- Questions ---
  const h = headerIndex(qSheet.getRow(1));
  const questions: ParsedQuestion[] = [];
  qSheet.eachRow((row, rowNumber) => {
    if (rowNumber === 1) return; // header
    const sectionName = cellString(row, h.section ?? 1);
    const text = cellString(row, h.text ?? 6);
    const typeRaw = cellString(row, h.type ?? 5).toUpperCase();
    // Skip fully blank rows silently.
    if (!sectionName && !text && !typeRaw) return;

    if (!sectionName) {
      errors.push({
        sheet: "Questions",
        row: rowNumber,
        message: "Missing section",
      });
      return;
    }
    if (!EXAM_QUESTION_TYPE_VALUES.includes(typeRaw as ExamQuestionTypeT)) {
      errors.push({
        sheet: "Questions",
        row: rowNumber,
        message: `Invalid type '${typeRaw}'`,
      });
      return;
    }
    if (!text) {
      errors.push({
        sheet: "Questions",
        row: rowNumber,
        message: "Missing text",
      });
      return;
    }
    const type = typeRaw as ExamQuestionTypeT;
    const marks = cellNumber(row, h.marks ?? 7) ?? 5;
    const order = cellNumber(row, h.order ?? 4) ?? 0;
    const sectionOrder = cellNumber(row, h.sectionOrder ?? 2) ?? 0;
    const sectionDuration = cellNumber(row, h.sectionDuration ?? 3) ?? 30;
    const ref = cellString(row, h.ref ?? 16) || `row-${rowNumber}`;

    const question: ParsedQuestion = {
      ref,
      sectionName,
      sectionOrder,
      sectionDuration,
      order,
      type,
      text,
      marks,
      starterCode: cellString(row, h.starterCode ?? 14),
      language: normalizeLanguage(cellString(row, h.language ?? 15)),
      // Absent column → open (backward-compatible with old templates).
      allowedLanguages: parseLanguagePolicy(
        h.allowedLanguages ? cellString(row, h.allowedLanguages) : "",
      ),
      testCases: [],
    };

    if (type === ExamQuestionType.CODE) {
      question.testCases = casesByRef.get(ref) ?? [];
    } else {
      const options: string[] = [];
      for (let i = 1; i <= 5; i++) {
        const opt = cellString(row, h[`option${i}`] ?? 7 + i);
        if (opt) options.push(opt);
      }
      const correctRaw = cellString(row, h.correctOptions ?? 13);
      const correctOptions = correctRaw
        .split(",")
        .map((s) => Number(s.trim()))
        .filter((n) => Number.isInteger(n))
        .map((n) => n - 1) // 1-based → 0-based
        .filter((n) => n >= 0 && n < options.length);
      if (options.length < 2) {
        errors.push({
          sheet: "Questions",
          row: rowNumber,
          message: "MCQ needs at least 2 options",
        });
        return;
      }
      if (correctOptions.length === 0) {
        errors.push({
          sheet: "Questions",
          row: rowNumber,
          message: "MCQ needs at least 1 valid correct option",
        });
        return;
      }
      question.options = options;
      question.correctOptions = correctOptions;
    }

    questions.push(question);
  });

  return { questions, errors };
}

function normalizeLanguage(raw: string): CodeLanguage {
  const lower = raw.toLowerCase();
  return (CODE_LANGUAGE_VALUES as string[]).includes(lower)
    ? (lower as CodeLanguage)
    : ("python" as CodeLanguage);
}

/**
 * Parse the CODE language policy cell: blank / "all" / "open" (or an
 * unrecognized value) → OPEN ([]); a single supported language → LOCKED to it.
 */
function parseLanguagePolicy(raw: string): CodeLanguage[] {
  const v = raw.trim().toLowerCase();
  if (v === "" || v === "all" || v === "open") return [];
  return (CODE_LANGUAGE_VALUES as string[]).includes(v)
    ? [v as CodeLanguage]
    : [];
}

// --- Results export ---------------------------------------------------------

export interface ResultRow {
  candidate: string;
  rollNumber: string;
  collegeName: string;
  status: string;
  score: number;
  totalMarks: number;
  passed: boolean;
  autoSubmitted: boolean;
  warnings: number;
  sectionScores: { name: string; score: number }[];
  submittedAt: string;
}

export async function buildResultsWorkbook(
  examTitle: string,
  sectionNames: string[],
  rows: ResultRow[],
): Promise<Buffer> {
  const wb = new ExcelJS.Workbook();
  wb.creator = "CodeApt";
  wb.subject = examTitle;
  const ws = wb.addWorksheet("Results");

  const columns: Partial<ExcelJS.Column>[] = [
    { header: "Candidate", key: "candidate", width: 24 },
    { header: "Roll Number", key: "rollNumber", width: 16 },
    { header: "College", key: "collegeName", width: 24 },
    { header: "Status", key: "status", width: 12 },
    ...sectionNames.map((name, i) => ({
      header: name,
      key: `section${i}`,
      width: 14,
    })),
    { header: "Total", key: "score", width: 10 },
    { header: "Out Of", key: "totalMarks", width: 10 },
    { header: "Passed", key: "passed", width: 10 },
    { header: "Auto-Submitted", key: "autoSubmitted", width: 16 },
    { header: "Warnings", key: "warnings", width: 10 },
    { header: "Submitted At", key: "submittedAt", width: 24 },
  ];
  ws.columns = columns;
  ws.getRow(1).font = { bold: true };

  for (const r of rows) {
    const record: Record<string, string | number | boolean> = {
      candidate: r.candidate,
      rollNumber: r.rollNumber,
      collegeName: r.collegeName,
      status: r.status,
      score: r.score,
      totalMarks: r.totalMarks,
      passed: r.passed ? "PASS" : "FAIL",
      autoSubmitted: r.autoSubmitted ? "Yes" : "No",
      warnings: r.warnings,
      submittedAt: r.submittedAt,
    };
    sectionNames.forEach((name, i) => {
      record[`section${i}`] =
        r.sectionScores.find((s) => s.name === name)?.score ?? 0;
    });
    ws.addRow(record);
  }

  const out = await wb.xlsx.writeBuffer();
  return Buffer.from(out);
}
