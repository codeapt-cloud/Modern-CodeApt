/**
 * BullMQ producer side (API). The API only ENQUEUES — it never runs code.
 * Queues + their Redis connection are created lazily on first use so the app
 * (and tests) can import this module without opening a Redis connection.
 *
 * Tests mock this module, so no live Redis is required in CI.
 */
import {
  QUEUE_NAME_VALUES,
  QueueName,
  type CodeExecutionJob,
  type EssayGradingJob,
} from "@codeapt/shared";
import { Queue } from "bullmq";
import { Redis } from "ioredis";

import { env } from "../config/env.js";
import { logger } from "./logger.js";

let connection: Redis | null = null;
const queues = new Map<QueueName, Queue>();

function getConnection(): Redis {
  connection ??= new Redis(env.REDIS_URL, { maxRetriesPerRequest: null });
  return connection;
}

function getQueue(name: QueueName): Queue {
  let queue = queues.get(name);
  if (!queue) {
    queue = new Queue(name, { connection: getConnection() });
    queues.set(name, queue);
  }
  return queue;
}

/**
 * Enqueue a code-execution job. The BullMQ jobId is pinned to our jobId so a
 * duplicate submit is de-duplicated by the queue. `attempts: 1` — the worker
 * turns a failed execution into a finalized (failed) job itself, so BullMQ
 * must not re-run user code on error.
 */
export async function enqueueCodeJob(
  name: QueueName,
  payload: CodeExecutionJob,
): Promise<void> {
  const queue = getQueue(name);
  await queue.add("execute", payload, {
    jobId: payload.jobId,
    attempts: 1,
    removeOnComplete: 1000,
    removeOnFail: 5000,
  });
  logger.debug({ queue: name, jobId: payload.jobId }, "job enqueued");
}

/** BullMQ job name the worker's default-queue dispatcher routes to grading. */
export const ESSAY_GRADING_JOB_NAME = "grade-essay";

/**
 * Enqueue an essay-grading job on the `default` queue. Essay grading does not
 * touch Piston, so it rides the reserved `default` queue rather than one of the
 * code-execution queues. jobId is pinned so a duplicate submit de-duplicates;
 * `attempts: 1` — the worker finalizes failures itself (no blind retry).
 */
export async function enqueueEssayGradingJob(
  payload: EssayGradingJob,
): Promise<void> {
  const queue = getQueue(QueueName.DEFAULT);
  await queue.add(ESSAY_GRADING_JOB_NAME, payload, {
    jobId: payload.jobId,
    attempts: 1,
    removeOnComplete: 1000,
    removeOnFail: 5000,
  });
  logger.debug(
    { queue: QueueName.DEFAULT, jobId: payload.jobId },
    "essay grading job enqueued",
  );
}

/** Close all queues + the Redis connection (graceful shutdown). */
export async function closeQueues(): Promise<void> {
  await Promise.allSettled([...queues.values()].map((q) => q.close()));
  queues.clear();
  if (connection) {
    await connection.quit();
    connection = null;
  }
}

/** Exposed for a startup log line (no behavioural effect). */
export const knownQueues = QUEUE_NAME_VALUES;
