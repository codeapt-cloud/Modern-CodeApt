/**
 * <Stagger> / <StaggerItem> — a container that reveals its children one-by-one
 * on mount. Reduced motion → all children are static and visible immediately
 * (no cascade), still fully functional.
 *
 * Wrap each child in <StaggerItem> (or pass your own motion children that use
 * the "hidden"/"visible" variant names).
 */
import { motion, useReducedMotion } from "framer-motion";
import { createElement, type ElementType, type ReactNode } from "react";

import { staggerContainer, staggerItem, transition } from "../../lib/motion.js";

export interface StaggerProps {
  children: ReactNode;
  as?: ElementType;
  className?: string;
}

export function Stagger({ children, as = "div", className }: StaggerProps) {
  const reduced = useReducedMotion();

  if (reduced) {
    return createElement(as, { className }, children);
  }

  const MotionTag = motion[as as "div"] as typeof motion.div;
  return (
    <MotionTag
      className={className}
      variants={staggerContainer}
      initial="hidden"
      animate="visible"
    >
      {children}
    </MotionTag>
  );
}

export interface StaggerItemProps {
  children: ReactNode;
  as?: ElementType;
  className?: string;
}

export function StaggerItem({
  children,
  as = "div",
  className,
}: StaggerItemProps) {
  const reduced = useReducedMotion();

  if (reduced) {
    return createElement(as, { className }, children);
  }

  const MotionTag = motion[as as "div"] as typeof motion.div;
  return (
    <MotionTag
      className={className}
      variants={staggerItem}
      transition={transition.base}
    >
      {children}
    </MotionTag>
  );
}
