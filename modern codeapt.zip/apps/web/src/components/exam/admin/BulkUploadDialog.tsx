/**
 * Bulk-upload questions from an .xlsx workbook. The backend
 * (POST /admin/exams/:examId/bulk-upload) accepts the workbook base64-encoded in
 * the JSON body (not multipart) and returns a per-row report
 * { createdSections, createdQuestions, createdTestCases, errors[] }.
 *
 * Workbook shape (verified against the parser):
 *   Sheet "Questions": section | sectionOrder | sectionDuration | order | type
 *     | text | marks | option1..option5 | correctOptions (1-based, comma list)
 *     | starterCode | language | ref
 *   Sheet "TestCases": ref | input | expectedOutput | hidden
 *
 * NOTE: the parser does NOT import question images from URLs (the original
 * downloaded them to Cloudinary). Image handling is a separate, undecided
 * dependency — see the flagged note in the dialog.
 */
import type { ExcelUploadResponse } from "@codeapt/shared";
import { FileUp } from "lucide-react";
import { useState } from "react";

import { api, parseApiError } from "../../../lib/api-client.js";
import { Alert } from "../../ui/alert.js";
import { Button } from "../../ui/button.js";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "../../ui/dialog.js";
import { useToast } from "../../ui/toast.js";

function readAsBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Could not read file"));
    reader.onload = () => {
      const result = String(reader.result);
      // Strip the "data:...;base64," prefix.
      resolve(result.slice(result.indexOf(",") + 1));
    };
    reader.readAsDataURL(file);
  });
}

export function BulkUploadDialog({
  open,
  onOpenChange,
  examId,
  onUploaded,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  examId: string;
  onUploaded: () => void;
}) {
  const { toast } = useToast();
  const [file, setFile] = useState<File | null>(null);
  const [report, setReport] = useState<ExcelUploadResponse | null>(null);
  const [formError, setFormError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const submit = async (): Promise<void> => {
    if (!file) return;
    setFormError("");
    setReport(null);
    setSubmitting(true);
    try {
      const fileBase64 = await readAsBase64(file);
      const result = await api.adminExams.bulkUpload(examId, fileBase64);
      setReport(result);
      toast({
        variant: "success",
        title: `Imported ${result.createdQuestions} question${result.createdQuestions === 1 ? "" : "s"}`,
      });
      onUploaded();
    } catch (err) {
      setFormError(parseApiError(err).message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Bulk upload questions</DialogTitle>
          <DialogDescription>
            Upload an .xlsx workbook with a “Questions” sheet (and an optional
            “TestCases” sheet). Sections are created by name as needed.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {formError ? <Alert variant="error">{formError}</Alert> : null}

          <Alert variant="warning">
            Question images are not imported — exam image storage is undecided
            (the original used Cloudinary). Everything else imports normally.
          </Alert>

          <label className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border border-dashed border-subtle bg-surface-base p-8 text-center hover:border-primary/60">
            <FileUp className="h-6 w-6 text-primary" />
            <span className="text-sm text-ink">
              {file ? file.name : "Choose an .xlsx workbook"}
            </span>
            <span className="text-xs text-ink-muted">
              Columns: section, type, text, marks, option1–5, correctOptions
              (1-based), starterCode, language, ref
            </span>
            <input
              type="file"
              accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
              className="hidden"
              onChange={(e) => {
                setReport(null);
                setFile(e.target.files?.[0] ?? null);
              }}
            />
          </label>

          {report ? (
            <div className="space-y-3 rounded-xl border border-subtle bg-surface-base p-4">
              <div className="flex flex-wrap gap-4 text-sm">
                <Stat label="Sections" value={report.createdSections} />
                <Stat label="Questions" value={report.createdQuestions} />
                <Stat label="Test cases" value={report.createdTestCases} />
                <Stat label="Row errors" value={report.errors.length} />
              </div>
              {report.errors.length > 0 ? (
                <ul className="max-h-40 space-y-1 overflow-y-auto text-xs">
                  {report.errors.map((e, i) => (
                    <li key={i} className="text-error-fg">
                      {e.sheet} row {e.row}: {e.message}
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-xs text-success-fg">
                  No row errors — all rows imported.
                </p>
              )}
            </div>
          ) : null}
        </div>

        <DialogFooter>
          <Button
            type="button"
            variant="ghost"
            onClick={() => onOpenChange(false)}
          >
            {report ? "Close" : "Cancel"}
          </Button>
          <Button
            type="button"
            loading={submitting}
            disabled={!file}
            onClick={() => void submit()}
          >
            <FileUp className="h-4 w-4" /> Upload
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <p className="font-mono text-lg font-bold text-ink">{value}</p>
      <p className="text-xs text-ink-muted">{label}</p>
    </div>
  );
}
