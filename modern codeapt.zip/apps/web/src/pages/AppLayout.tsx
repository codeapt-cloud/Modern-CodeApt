import { Role } from "@codeapt/shared";
import {
  Briefcase,
  BookOpen,
  ClipboardCheck,
  FilePenLine,
  Flame,
  FolderTree,
  IndianRupee,
  LayoutDashboard,
  Ticket,
  PenLine,
  Receipt,
  Settings,
  ShieldAlert,
  Sparkles,
  TerminalSquare,
  Trophy,
  Users,
} from "lucide-react";
import { Outlet, useNavigate } from "react-router-dom";

import { AppShell, type NavItem } from "../components/layout/AppShell.js";
import { useToast } from "../components/ui/toast.js";
import { imageUrl } from "../lib/cloudinary.js";
import { useAuth } from "../providers/AuthProvider.js";

const baseNav: NavItem[] = [
  { label: "Dashboard", to: "/app", icon: LayoutDashboard, end: true },
  { label: "Courses", to: "/courses", icon: BookOpen },
  { label: "Daily challenge", to: "/challenge", icon: Flame },
  { label: "Exams", to: "/exams", icon: ClipboardCheck },
  { label: "Essays", to: "/essays", icon: PenLine },
  { label: "Careers", to: "/careers", icon: Briefcase },
  { label: "Leaderboard", to: "/leaderboard", icon: Trophy },
  { label: "Playground", to: "/playground", icon: TerminalSquare },
  { label: "My orders", to: "/orders", icon: Receipt },
];

/** Authenticated shell layout shared by all protected pages. */
export function AppLayout() {
  const { user, profile, logout } = useAuth();
  const nav: NavItem[] = [
    ...baseNav,
    ...(user?.role === Role.ADMIN
      ? [
          {
            label: "Manage curriculum",
            to: "/admin/curriculum",
            icon: FolderTree,
          },
          { label: "Manage postings", to: "/admin/careers", icon: Settings },
          { label: "Manage exams", to: "/admin/exams", icon: FilePenLine },
          {
            label: "Manage essay prompts",
            to: "/admin/essay-topics",
            icon: PenLine,
          },
          { label: "Manage challenges", to: "/admin/challenges", icon: Flame },
          { label: "Manage coupons", to: "/admin/coupons", icon: Ticket },
          { label: "Users", to: "/admin/users", icon: Users },
          { label: "Orders", to: "/admin/orders", icon: IndianRupee },
          {
            label: "Essay analytics",
            to: "/admin/essay-analytics",
            icon: ShieldAlert,
          },
        ]
      : []),
    // Dev-only design-system gallery (route exists only in dev builds).
    ...(import.meta.env.DEV
      ? [{ label: "Component gallery", to: "/dev/ui", icon: Sparkles }]
      : []),
  ];
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleLogout = async () => {
    await logout();
    toast({ title: "Signed out" });
    navigate("/login", { replace: true });
  };

  return (
    <AppShell
      nav={nav}
      user={{
        name: profile?.fullName ?? user?.username ?? "User",
        email: user?.email ?? "",
        avatarUrl: imageUrl(profile?.avatarUrl),
      }}
      onLogout={handleLogout}
    >
      <Outlet />
    </AppShell>
  );
}
