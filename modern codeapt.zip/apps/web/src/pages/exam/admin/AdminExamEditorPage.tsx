/**
 * Exam editor (route: /admin/exams/:examId). Loads the full authored tree and
 * manages its structure: exam settings (title / pass %), sections, questions
 * (type-adaptive), and CODE test cases. All mutations hit the real admin
 * endpoints and refetch; the server is authoritative.
 *
 * Power features (Excel bulk-upload, public links, results export, attempt
 * reset) are Step 2b — shown here as disabled placeholders only.
 */
import type { AdminExamDetail } from "@codeapt/shared";
import {
  ArrowLeft,
  CheckCircle2,
  Clock,
  Download,
  FileUp,
  Link2,
  Pencil,
  Plus,
  RotateCcw,
  Settings,
  Trash2,
} from "lucide-react";
import { useState } from "react";
import { Link, useParams } from "react-router-dom";

import { BulkUploadDialog } from "../../../components/exam/admin/BulkUploadDialog.js";
import { ExamSettingsDialog } from "../../../components/exam/admin/ExamSettingsDialog.js";
import { PublicLinksDialog } from "../../../components/exam/admin/PublicLinksDialog.js";
import { QuestionEditorDialog } from "../../../components/exam/admin/QuestionEditorDialog.js";
import { AttemptManagementDialog } from "../../../components/exam/admin/AttemptManagementDialog.js";
import { SectionEditorDialog } from "../../../components/exam/admin/SectionEditorDialog.js";
import { TestCaseEditor } from "../../../components/exam/admin/TestCaseEditor.js";
import { PageHeader } from "../../../components/layout/PageHeader.js";
import { Alert } from "../../../components/ui/alert.js";
import { Badge } from "../../../components/ui/badge.js";
import { Button } from "../../../components/ui/button.js";
import { Card } from "../../../components/ui/card.js";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "../../../components/ui/dialog.js";
import { EmptyState } from "../../../components/ui/empty-state.js";
import { IconButton } from "../../../components/ui/icon-button.js";
import { Skeleton } from "../../../components/ui/skeleton.js";
import { useToast } from "../../../components/ui/toast.js";
import { api, parseApiError } from "../../../lib/api-client.js";
import {
  codeLanguageLabel,
  isCode,
  questionTypeLabel,
} from "../../../lib/exam-authoring.js";
import { useQuery } from "../../../lib/use-query.js";

type Section = AdminExamDetail["sections"][number];
type Question = Section["questions"][number];

const LETTERS = ["A", "B", "C", "D", "E"];

type DeleteTarget =
  | { kind: "section"; id: string; label: string }
  | { kind: "question"; id: string; label: string }
  | { kind: "test case"; id: string; label: string };

export function AdminExamEditorPage() {
  const { examId = "" } = useParams();
  const { toast } = useToast();
  const { data, loading, error, refetch } = useQuery(
    () => api.adminExams.get(examId),
    [examId],
  );

  const [settingsOpen, setSettingsOpen] = useState(false);
  const [addSectionOpen, setAddSectionOpen] = useState(false);
  const [editSectionFor, setEditSectionFor] = useState<Section | null>(null);
  const [addQuestionFor, setAddQuestionFor] = useState<Section | null>(null);
  const [editQuestionFor, setEditQuestionFor] = useState<{
    section: Section;
    question: Question;
  } | null>(null);
  const [confirm, setConfirm] = useState<DeleteTarget | null>(null);
  const [busy, setBusy] = useState(false);
  const [bulkOpen, setBulkOpen] = useState(false);
  const [linksOpen, setLinksOpen] = useState(false);
  const [resetOpen, setResetOpen] = useState(false);
  const [downloading, setDownloading] = useState(false);

  const downloadResults = async (): Promise<void> => {
    setDownloading(true);
    try {
      const { blob, filename } = await api.adminExams.resultsBlob(examId);
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      toast({ title: "Results downloaded" });
    } catch (err) {
      toast({ variant: "error", title: parseApiError(err).message });
    } finally {
      setDownloading(false);
    }
  };

  const performDelete = async (): Promise<void> => {
    if (!confirm) return;
    setBusy(true);
    try {
      if (confirm.kind === "section") {
        await api.adminExams.deleteSection(confirm.id);
      } else if (confirm.kind === "question") {
        await api.adminExams.deleteQuestion(confirm.id);
      } else {
        await api.adminExams.deleteTestCase(confirm.id);
      }
      toast({ title: `Deleted ${confirm.kind}` });
      setConfirm(null);
      refetch();
    } catch (err) {
      toast({ variant: "error", title: parseApiError(err).message });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-6">
      <Link
        to="/admin/exams"
        className="inline-flex items-center gap-1 text-sm text-ink-muted hover:text-ink"
      >
        <ArrowLeft className="h-4 w-4" /> All exams
      </Link>

      {loading ? (
        <Skeleton className="h-64 w-full rounded-2xl" />
      ) : error ? (
        <Alert variant="error">{error}</Alert>
      ) : !data ? null : (
        <>
          <PageHeader
            title={data.title}
            description={`${data.totalMarks} total marks · pass ${data.passPercentage}% · ${data.sections.length} section${data.sections.length === 1 ? "" : "s"}`}
            actions={
              <Button variant="secondary" onClick={() => setSettingsOpen(true)}>
                <Settings className="h-4 w-4" /> Exam settings
              </Button>
            }
          />

          {/* Power tools */}
          <div className="flex flex-wrap items-center gap-2 rounded-xl border border-subtle bg-surface-base p-3">
            <span className="mr-1 text-xs font-medium text-ink-muted">
              Power tools
            </span>
            <Button variant="ghost" size="sm" onClick={() => setBulkOpen(true)}>
              <FileUp className="h-4 w-4" /> Bulk upload
            </Button>
            <Button variant="ghost" size="sm" onClick={() => setLinksOpen(true)}>
              <Link2 className="h-4 w-4" /> Public links
              {data.publicLinks.length > 0 ? (
                <Badge variant="neutral">{data.publicLinks.length}</Badge>
              ) : null}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              loading={downloading}
              onClick={() => void downloadResults()}
            >
              <Download className="h-4 w-4" /> Download results
            </Button>
            <Button variant="ghost" size="sm" onClick={() => setResetOpen(true)}>
              <RotateCcw className="h-4 w-4" /> Attempt management
            </Button>
          </div>

          {/* Sections */}
          {data.sections.length === 0 ? (
            <EmptyState
              title="No sections yet"
              description="Add a section, then add questions to it."
              icon={<Clock />}
              action={
                <Button size="sm" onClick={() => setAddSectionOpen(true)}>
                  <Plus className="h-4 w-4" /> Add section
                </Button>
              }
            />
          ) : (
            <div className="space-y-4">
              {data.sections.map((section) => (
                <SectionCard
                  key={section.id}
                  section={section}
                  onAddQuestion={() => setAddQuestionFor(section)}
                  onEditSection={() => setEditSectionFor(section)}
                  onEditQuestion={(q) =>
                    setEditQuestionFor({ section, question: q })
                  }
                  onDeleteSection={() =>
                    setConfirm({
                      kind: "section",
                      id: section.id,
                      label: section.name,
                    })
                  }
                  onDeleteQuestion={(q) =>
                    setConfirm({
                      kind: "question",
                      id: q.id,
                      label: q.text.slice(0, 60) || "question",
                    })
                  }
                  onRequestDeleteTestCase={(id) =>
                    setConfirm({ kind: "test case", id, label: "test case" })
                  }
                  onChanged={refetch}
                />
              ))}
            </div>
          )}

          {data.sections.length > 0 ? (
            <Button variant="secondary" onClick={() => setAddSectionOpen(true)}>
              <Plus className="h-4 w-4" /> Add section
            </Button>
          ) : null}

          {/* Dialogs */}
          {settingsOpen ? (
            <ExamSettingsDialog
              open
              onOpenChange={setSettingsOpen}
              initial={data}
              onSaved={() => refetch()}
            />
          ) : null}

          {addSectionOpen ? (
            <SectionEditorDialog
              open
              onOpenChange={setAddSectionOpen}
              examId={data.id}
              nextOrder={data.sections.length}
              onSaved={() => refetch()}
            />
          ) : null}

          {editSectionFor ? (
            <SectionEditorDialog
              key={`edit-section-${editSectionFor.id}`}
              open
              onOpenChange={(o) => {
                if (!o) setEditSectionFor(null);
              }}
              examId={data.id}
              nextOrder={editSectionFor.order}
              initial={{
                id: editSectionFor.id,
                name: editSectionFor.name,
                order: editSectionFor.order,
                durationMinutes: editSectionFor.durationMinutes,
                description: editSectionFor.description,
              }}
              onSaved={() => refetch()}
            />
          ) : null}

          {addQuestionFor ? (
            <QuestionEditorDialog
              key={addQuestionFor.id}
              open
              onOpenChange={(o) => {
                if (!o) setAddQuestionFor(null);
              }}
              sectionId={addQuestionFor.id}
              sectionName={addQuestionFor.name}
              order={addQuestionFor.questions.length}
              onSaved={refetch}
            />
          ) : null}

          {editQuestionFor ? (
            <QuestionEditorDialog
              key={`edit-${editQuestionFor.question.id}`}
              open
              onOpenChange={(o) => {
                if (!o) setEditQuestionFor(null);
              }}
              sectionId={editQuestionFor.section.id}
              sectionName={editQuestionFor.section.name}
              order={editQuestionFor.question.order}
              initial={editQuestionFor.question}
              onSaved={refetch}
            />
          ) : null}

          {bulkOpen ? (
            <BulkUploadDialog
              open
              onOpenChange={setBulkOpen}
              examId={data.id}
              onUploaded={refetch}
            />
          ) : null}

          {linksOpen ? (
            <PublicLinksDialog
              open
              onOpenChange={setLinksOpen}
              examId={data.id}
              links={data.publicLinks}
              onChanged={refetch}
            />
          ) : null}

          {resetOpen ? (
            <AttemptManagementDialog
              open
              onOpenChange={setResetOpen}
              examId={data.id}
            />
          ) : null}
        </>
      )}

      {/* Unified delete confirm (sections, questions, test cases) */}
      <Dialog
        open={confirm !== null}
        onOpenChange={(o) => {
          if (!o) setConfirm(null);
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete {confirm?.kind}?</DialogTitle>
            <DialogDescription>
              {confirm?.kind === "section"
                ? `“${confirm?.label}” and all its questions and test cases will be permanently deleted.`
                : confirm?.kind === "question"
                  ? `This question and its test cases will be permanently deleted.`
                  : `This test case will be permanently deleted.`}{" "}
              This cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setConfirm(null)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              loading={busy}
              onClick={() => void performDelete()}
            >
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function SectionCard({
  section,
  onAddQuestion,
  onEditSection,
  onEditQuestion,
  onDeleteSection,
  onDeleteQuestion,
  onRequestDeleteTestCase,
  onChanged,
}: {
  section: Section;
  onAddQuestion: () => void;
  onEditSection: () => void;
  onEditQuestion: (q: Question) => void;
  onDeleteSection: () => void;
  onDeleteQuestion: (q: Question) => void;
  onRequestDeleteTestCase: (id: string) => void;
  onChanged: () => void;
}) {
  return (
    <Card className="overflow-hidden">
      <div className="flex items-start justify-between gap-4 border-b border-subtle bg-surface-base p-4">
        <div>
          <div className="flex items-center gap-2">
            <Badge variant="neutral">#{section.order}</Badge>
            <h3 className="font-semibold text-ink">{section.name}</h3>
          </div>
          <p className="mt-1 flex items-center gap-3 text-xs text-ink-muted">
            <span className="inline-flex items-center gap-1">
              <Clock className="h-3.5 w-3.5" /> {section.durationMinutes} min
            </span>
            <span>
              {section.questions.length} question
              {section.questions.length === 1 ? "" : "s"}
            </span>
          </p>
          {section.description ? (
            <p className="mt-1 text-sm text-ink-secondary">
              {section.description}
            </p>
          ) : null}
        </div>
        <div className="flex shrink-0 items-center gap-1">
          <Button size="sm" variant="ghost" onClick={onAddQuestion}>
            <Plus className="h-4 w-4" /> Question
          </Button>
          <IconButton
            aria-label="Edit section"
            variant="ghost"
            size="sm"
            icon={<Pencil className="h-4 w-4" />}
            onClick={onEditSection}
          />
          <IconButton
            aria-label="Delete section"
            variant="ghost"
            size="sm"
            icon={<Trash2 className="h-4 w-4 text-error-fg" />}
            onClick={onDeleteSection}
          />
        </div>
      </div>

      {section.questions.length === 0 ? (
        <p className="p-4 text-sm text-ink-muted">
          No questions yet. Use “Question” to add one.
        </p>
      ) : (
        <ul className="divide-y divide-subtle">
          {section.questions.map((q, i) => (
            <li key={q.id} className="space-y-3 p-4">
              <div className="flex items-start justify-between gap-4">
                <div className="min-w-0 space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono text-xs text-ink-muted">
                      Q{i + 1}
                    </span>
                    <Badge variant="info">{questionTypeLabel(q.type)}</Badge>
                    <span className="text-xs text-ink-muted">
                      {q.marks} marks
                    </span>
                    {isCode(q.type) ? (
                      <Badge variant="neutral">
                        {codeLanguageLabel(q.language)}
                      </Badge>
                    ) : null}
                  </div>
                  <p className="whitespace-pre-line text-sm text-ink">
                    {q.text}
                  </p>
                </div>
                <div className="flex shrink-0 items-center gap-1">
                  <IconButton
                    aria-label="Edit question"
                    variant="ghost"
                    size="sm"
                    icon={<Pencil className="h-4 w-4" />}
                    onClick={() => onEditQuestion(q)}
                  />
                  <IconButton
                    aria-label="Delete question"
                    variant="ghost"
                    size="sm"
                    icon={<Trash2 className="h-4 w-4 text-error-fg" />}
                    onClick={() => onDeleteQuestion(q)}
                  />
                </div>
              </div>

              {/* MCQ options with the correct answer(s) highlighted */}
              {q.options && q.options.length > 0 ? (
                <ul className="grid gap-1.5">
                  {q.options.map((opt, oi) => {
                    const correct = q.correctOptions?.includes(oi) ?? false;
                    return (
                      <li
                        key={oi}
                        className={
                          "flex items-center gap-2 rounded-lg border px-3 py-1.5 text-sm " +
                          (correct
                            ? "border-success/40 bg-success-subtle text-ink"
                            : "border-subtle text-ink-secondary")
                        }
                      >
                        <span className="font-mono text-xs text-ink-muted">
                          {LETTERS[oi] ?? oi + 1}
                        </span>
                        <span className="flex-1">{opt}</span>
                        {correct ? (
                          <CheckCircle2 className="h-4 w-4 text-success-fg" />
                        ) : null}
                      </li>
                    );
                  })}
                </ul>
              ) : null}

              {/* CODE: starter code + test cases */}
              {isCode(q.type) ? (
                <div className="space-y-3">
                  {q.starterCode ? (
                    <pre className="overflow-x-auto rounded-xl border border-subtle bg-surface-sunken p-3 font-mono text-xs text-ink-secondary">
                      {q.starterCode}
                    </pre>
                  ) : null}
                  <TestCaseEditor
                    questionId={q.id}
                    testCases={q.testCases}
                    onChanged={onChanged}
                    onRequestDelete={onRequestDeleteTestCase}
                  />
                </div>
              ) : null}
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}
