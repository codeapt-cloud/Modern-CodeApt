/**
 * Exams list — the exams a logged-in student can take, with attempt usage and
 * their last result. "Start"/"Resume" enters the fullscreen runner; disabled
 * (with a reason) once the attempt limit is reached.
 */
import { FileCheck2 } from "lucide-react";

import { ExamStatusCard } from "../../components/exam/ExamStatusCard.js";
import { PageHeader } from "../../components/layout/PageHeader.js";
import { Alert } from "../../components/ui/alert.js";
import { Card, CardContent } from "../../components/ui/card.js";
import { EmptyState } from "../../components/ui/empty-state.js";
import { Skeleton } from "../../components/ui/skeleton.js";
import { api } from "../../lib/api-client.js";
import { useQuery } from "../../lib/use-query.js";

export function ExamsPage() {
  const { data, loading, error } = useQuery(() => api.exams.list(), []);
  const items = data?.items ?? [];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Mock Exams"
        description="Timed, sectioned exams. Each section is separately timed and grading is automatic."
      />

      {loading ? (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Card key={i}>
              <CardContent className="space-y-3 p-5">
                <Skeleton className="h-5 w-2/3" />
                <Skeleton className="h-3 w-full" />
                <Skeleton className="h-9 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : error ? (
        <Alert variant="error">{error}</Alert>
      ) : items.length === 0 ? (
        <EmptyState
          title="No exams available"
          description="Exams appear here when you're enrolled in a subject that includes one."
          icon={<FileCheck2 />}
        />
      ) : (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((item) => (
            <ExamStatusCard key={item.id} item={item} />
          ))}
        </div>
      )}
    </div>
  );
}
