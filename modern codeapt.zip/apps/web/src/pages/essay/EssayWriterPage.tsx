/**
 * The essay-writing screen (its own lazy chunk). Loads the prompt, drives the
 * compose → submit → poll → results flow via `useEssayGrading`, shows the
 * submission history, and posts optional (non-grading) analytics on submit.
 */
import type { EssayAnalyticsInput } from "@codeapt/shared";
import { useReducedMotion, motion } from "framer-motion";
import { ArrowLeft } from "lucide-react";
import { useEffect } from "react";
import { Link, useParams } from "react-router-dom";

import { EssayComposer } from "../../components/essay/EssayComposer.js";
import { EssayHistory } from "../../components/essay/EssayHistory.js";
import { EssayResult } from "../../components/essay/EssayResult.js";
import { PageHeader } from "../../components/layout/PageHeader.js";
import { Alert } from "../../components/ui/alert.js";
import { Button } from "../../components/ui/button.js";
import { Spinner } from "../../components/ui/spinner.js";
import { api } from "../../lib/api-client.js";
import { essayAttemptStatus } from "../../lib/essay-compose.js";
import { useEssayGrading } from "../../lib/use-essay-grading.js";
import { useQuery } from "../../lib/use-query.js";

function GradingState({ reduced }: { reduced: boolean }) {
  return (
    <div className="flex min-h-[46vh] flex-col items-center justify-center gap-4 text-center">
      <motion.span
        className="font-mono text-5xl text-primary"
        animate={reduced ? undefined : { opacity: [0.4, 1, 0.4] }}
        transition={{ duration: 1.2, repeat: Infinity, ease: "easeInOut" }}
      >
        {"{ }"}
      </motion.span>
      <p className="text-ink">Grading your essay…</p>
      <p className="text-sm text-ink-muted">
        Scoring seven dimensions — this only takes a moment.
      </p>
    </div>
  );
}

export function EssayWriterPage() {
  const { id = "" } = useParams();
  const reduced = useReducedMotion() ?? false;

  const prompt = useQuery(() => api.essays.get(id), [id]);
  const history = useQuery(() => api.essays.submissions(id), [id]);
  const grading = useEssayGrading(id);

  const refreshHistory = history.refetch;
  const refreshPrompt = prompt.refetch;

  // Refresh history AND the prompt the moment a grade lands, so the new attempt
  // appears below the results and the attempt counter/cap stays accurate.
  const phase = grading.phase;
  useEffect(() => {
    if (phase === "done") {
      refreshHistory();
      refreshPrompt();
    }
  }, [phase, refreshHistory, refreshPrompt]);

  const attempts = prompt.data
    ? essayAttemptStatus(prompt.data.attemptsUsed, prompt.data.maxAttempts)
    : null;

  const handleSubmit = async (
    content: string,
    analytics: EssayAnalyticsInput,
  ): Promise<void> => {
    const jobId = await grading.submit(content);
    if (jobId) {
      // Fire-and-forget: analytics are additive and never affect the grade.
      grading.sendAnalytics(jobId, analytics);
    }
  };

  const handleWriteAnother = (): void => {
    grading.reset();
    refreshHistory();
    refreshPrompt();
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Write essay"
        breadcrumbs={[
          { label: "Essays", href: "/essays" },
          { label: prompt.data?.title ?? "Prompt" },
        ]}
        actions={
          <Button asChild variant="ghost" size="sm">
            <Link to="/essays">
              <ArrowLeft className="h-4 w-4" /> All essays
            </Link>
          </Button>
        }
      />

      {prompt.loading ? (
        <div className="flex min-h-[40vh] items-center justify-center">
          <Spinner size="lg" />
        </div>
      ) : prompt.error || !prompt.data ? (
        <Alert variant="error">
          {prompt.error ?? "This essay isn’t available to you."}
        </Alert>
      ) : (
        <>
          {grading.phase === "compose" ? (
            attempts?.atLimit ? (
              <Alert variant="warning">
                Attempt limit reached — you’ve used all {attempts.max} attempts
                for this prompt. Your submissions are listed below.
              </Alert>
            ) : (
              <EssayComposer
                prompt={prompt.data}
                submitting={false}
                submitError={grading.submitError}
                attemptLabel={
                  attempts
                    ? `Attempt ${attempts.used + 1} of ${attempts.max}`
                    : null
                }
                onSubmit={(c, a) => void handleSubmit(c, a)}
              />
            )
          ) : null}

          {grading.phase === "submitting" || grading.phase === "grading" ? (
            <GradingState reduced={reduced} />
          ) : null}

          {grading.phase === "done" && grading.result ? (
            <EssayResult
              result={grading.result}
              reduced={reduced}
              onWriteAnother={handleWriteAnother}
            />
          ) : null}

          {grading.phase === "error" ? (
            <div className="space-y-4">
              <Alert variant="error">
                {grading.error ?? "Grading failed. Please try again."}
              </Alert>
              <Button onClick={handleWriteAnother}>Try again</Button>
            </div>
          ) : null}

          {/* Submission history — always visible below the active view. */}
          <section className="space-y-3 rounded-2xl border border-subtle bg-surface-raised p-5">
            <h3 className="text-sm font-semibold text-ink">Your submissions</h3>
            {history.loading ? (
              <Spinner size="sm" />
            ) : (
              <EssayHistory
                items={history.data?.items ?? []}
                onOpen={(jobId) => grading.showAttempt(jobId)}
              />
            )}
          </section>
        </>
      )}
    </div>
  );
}
