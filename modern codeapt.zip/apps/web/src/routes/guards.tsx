/**
 * Route guards driven by AuthProvider state.
 * - ProtectedRoute: requires auth; bounces forced-change users to the gate.
 * - GuestOnlyRoute: redirects already-authed users away from login/register.
 * - ForcedPasswordChangeRoute: only reachable while a change is pending.
 */
import { Role } from "@codeapt/shared";
import { Navigate, Outlet, useLocation } from "react-router-dom";

import { Spinner } from "../components/ui/spinner.js";
import { useAuth } from "../providers/AuthProvider.js";

function FullPageLoader() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-surface">
      <div className="flex flex-col items-center gap-3">
        <span className="font-mono text-2xl text-primary" aria-hidden="true">
          {"{ }"}
        </span>
        <Spinner />
      </div>
    </div>
  );
}

export function ProtectedRoute() {
  const { status, mustChangePassword } = useAuth();
  const location = useLocation();

  if (status === "loading") return <FullPageLoader />;
  if (status === "unauthenticated") {
    return <Navigate to="/login" replace state={{ from: location }} />;
  }
  if (mustChangePassword) {
    return <Navigate to="/forced-password-change" replace />;
  }
  return <Outlet />;
}

export function GuestOnlyRoute() {
  const { status, mustChangePassword } = useAuth();

  if (status === "loading") return <FullPageLoader />;
  if (status === "authenticated") {
    return (
      <Navigate
        to={mustChangePassword ? "/forced-password-change" : "/app"}
        replace
      />
    );
  }
  return <Outlet />;
}

/** Admin-only sub-guard (nest inside ProtectedRoute). Non-admins bounce home. */
export function RequireAdmin() {
  const { user } = useAuth();
  if (user?.role !== Role.ADMIN) return <Navigate to="/app" replace />;
  return <Outlet />;
}

export function ForcedPasswordChangeRoute() {
  const { status, mustChangePassword } = useAuth();

  if (status === "loading") return <FullPageLoader />;
  if (status === "unauthenticated") return <Navigate to="/login" replace />;
  if (!mustChangePassword) return <Navigate to="/app" replace />;
  return <Outlet />;
}
