import { Suspense, lazy, type ComponentType } from "react";
import { Navigate, Route, Routes } from "react-router-dom";

import { Spinner } from "./components/ui/spinner.js";
import { PublicLayout } from "./components/layout/PublicLayout.js";
import { AppLayout } from "./pages/AppLayout.js";
import { NotFoundPage } from "./pages/NotFoundPage.js";
import { useAuth } from "./providers/AuthProvider.js";
import {
  ForcedPasswordChangeRoute,
  GuestOnlyRoute,
  ProtectedRoute,
  RequireAdmin,
} from "./routes/guards.js";

// Route-level code-splitting: each feature page is its own chunk, so the
// initial bundle stays small and grows lazily as the app expands.
const named = <T,>(load: () => Promise<Record<string, T>>, key: string) =>
  lazy(async () => {
    const mod = await load();
    return { default: mod[key] as ComponentType };
  });

const LoginPage = named(() => import("./pages/auth/LoginPage.js"), "LoginPage");
const RegisterPage = named(
  () => import("./pages/auth/RegisterPage.js"),
  "RegisterPage",
);
const ForcedPasswordChangePage = named(
  () => import("./pages/auth/ForcedPasswordChangePage.js"),
  "ForcedPasswordChangePage",
);
const DashboardPage = named(
  () => import("./pages/DashboardPage.js"),
  "DashboardPage",
);
const ChangePasswordPage = named(
  () => import("./pages/ChangePasswordPage.js"),
  "ChangePasswordPage",
);
const CatalogPage = named(
  () => import("./pages/CatalogPage.js"),
  "CatalogPage",
);
const CourseDetailPage = named(
  () => import("./pages/CourseDetailPage.js"),
  "CourseDetailPage",
);
const PlaygroundPage = named(
  () => import("./pages/PlaygroundPage.js"),
  "PlaygroundPage",
);
const DailyChallengePage = named(
  () => import("./pages/DailyChallengePage.js"),
  "DailyChallengePage",
);
const LeaderboardPage = named(
  () => import("./pages/LeaderboardPage.js"),
  "LeaderboardPage",
);
const PlayerPage = named(
  () => import("./pages/player/PlayerPage.js"),
  "PlayerPage",
);
const ExamsPage = named(() => import("./pages/exam/ExamsPage.js"), "ExamsPage");
const EssaysPage = named(
  () => import("./pages/essay/EssaysPage.js"),
  "EssaysPage",
);
const EssayWriterPage = named(
  () => import("./pages/essay/EssayWriterPage.js"),
  "EssayWriterPage",
);
const CheckoutPage = named(
  () => import("./pages/payments/CheckoutPage.js"),
  "CheckoutPage",
);
const PaymentReturnPage = named(
  () => import("./pages/payments/PaymentReturnPage.js"),
  "PaymentReturnPage",
);
const OrdersPage = named(
  () => import("./pages/payments/OrdersPage.js"),
  "OrdersPage",
);
const ExamRunnerPage = named(
  () => import("./pages/exam/ExamRunnerPage.js"),
  "ExamRunnerPage",
);
const PublicExamPage = named(
  () => import("./pages/exam/PublicExamPage.js"),
  "PublicExamPage",
);
const CareersPage = named(
  () => import("./pages/careers/CareersPage.js"),
  "CareersPage",
);
const PostingDetailPage = named(
  () => import("./pages/careers/PostingDetailPage.js"),
  "PostingDetailPage",
);
const MyApplicationsPage = named(
  () => import("./pages/careers/MyApplicationsPage.js"),
  "MyApplicationsPage",
);
const AdminCareersPage = named(
  () => import("./pages/careers/admin/AdminCareersPage.js"),
  "AdminCareersPage",
);
const AdminApplicationsPage = named(
  () => import("./pages/careers/admin/AdminApplicationsPage.js"),
  "AdminApplicationsPage",
);
const AdminExamsPage = named(
  () => import("./pages/exam/admin/AdminExamsPage.js"),
  "AdminExamsPage",
);
const AdminExamEditorPage = named(
  () => import("./pages/exam/admin/AdminExamEditorPage.js"),
  "AdminExamEditorPage",
);
const AdminCurriculumPage = named(
  () => import("./pages/curriculum/admin/AdminCurriculumPage.js"),
  "AdminCurriculumPage",
);
const AdminCouponsPage = named(
  () => import("./pages/coupons/admin/AdminCouponsPage.js"),
  "AdminCouponsPage",
);
const AdminEssayTopicsPage = named(
  () => import("./pages/essays/admin/AdminEssayTopicsPage.js"),
  "AdminEssayTopicsPage",
);
const AdminChallengesPage = named(
  () => import("./pages/challenges/admin/AdminChallengesPage.js"),
  "AdminChallengesPage",
);
const AdminUsersPage = named(
  () => import("./pages/users/admin/AdminUsersPage.js"),
  "AdminUsersPage",
);
const AdminEssayAnalyticsPage = named(
  () => import("./pages/essays/admin/AdminEssayAnalyticsPage.js"),
  "AdminEssayAnalyticsPage",
);
const AdminOrdersPage = named(
  () => import("./pages/orders/admin/AdminOrdersPage.js"),
  "AdminOrdersPage",
);
const AdminSubjectEditorPage = named(
  () => import("./pages/curriculum/admin/AdminSubjectEditorPage.js"),
  "AdminSubjectEditorPage",
);
const UiGalleryPage = named(
  () => import("./pages/dev/UiGalleryPage.js"),
  "UiGalleryPage",
);

// Public marketing landing (the site root for logged-out visitors).
const LandingPage = named(
  () => import("./pages/landing/LandingPage.js"),
  "LandingPage",
);

// Public informational / legal pages (reachable logged-out and logged-in).
const AboutPage = named(() => import("./pages/static/AboutPage.js"), "AboutPage");
const ContactPage = named(
  () => import("./pages/static/ContactPage.js"),
  "ContactPage",
);
const TrainingPage = named(
  () => import("./pages/static/TrainingPage.js"),
  "TrainingPage",
);
const PlacementsPage = named(
  () => import("./pages/static/PlacementsPage.js"),
  "PlacementsPage",
);
const TermsPage = named(() => import("./pages/static/TermsPage.js"), "TermsPage");
const PrivacyPage = named(
  () => import("./pages/static/PrivacyPage.js"),
  "PrivacyPage",
);
const RefundPolicyPage = named(
  () => import("./pages/static/RefundPolicyPage.js"),
  "RefundPolicyPage",
);

function RouteFallback() {
  return (
    <div className="flex min-h-[60vh] items-center justify-center">
      <Spinner size="lg" />
    </div>
  );
}

/**
 * The site root. Logged-out visitors get the marketing landing page;
 * authenticated visitors are sent straight to the app. While the session is
 * still resolving we show the neutral loader (not the landing) so a returning
 * user never sees a flash of marketing before the redirect.
 */
function RootRoute() {
  const { status } = useAuth();
  if (status === "loading") return <RouteFallback />;
  if (status === "authenticated") return <Navigate to="/app" replace />;
  return <LandingPage />;
}

export function App() {
  return (
    <Suspense fallback={<RouteFallback />}>
      <Routes>
        {/* Guest-only auth screens */}
        <Route element={<GuestOnlyRoute />}>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
        </Route>

        {/* Forced password change (authenticated, blocking) */}
        <Route element={<ForcedPasswordChangeRoute />}>
          <Route
            path="/forced-password-change"
            element={<ForcedPasswordChangePage />}
          />
        </Route>

        {/* Protected app (inside the shell) */}
        <Route element={<ProtectedRoute />}>
          <Route element={<AppLayout />}>
            <Route path="/app" element={<DashboardPage />} />
            <Route path="/courses" element={<CatalogPage />} />
            <Route path="/courses/:slug" element={<CourseDetailPage />} />
            <Route path="/playground" element={<PlaygroundPage />} />
            <Route path="/challenge" element={<DailyChallengePage />} />
            <Route path="/leaderboard" element={<LeaderboardPage />} />
            <Route path="/exams" element={<ExamsPage />} />
            <Route path="/essays" element={<EssaysPage />} />
            <Route path="/essays/:id" element={<EssayWriterPage />} />
            <Route path="/checkout/:slug" element={<CheckoutPage />} />
            <Route path="/payments/return" element={<PaymentReturnPage />} />
            <Route path="/orders" element={<OrdersPage />} />
            <Route path="/careers" element={<CareersPage />} />
            <Route
              path="/careers/applications"
              element={<MyApplicationsPage />}
            />
            <Route path="/careers/:id" element={<PostingDetailPage />} />
            <Route path="/change-password" element={<ChangePasswordPage />} />

            {/* Admin-only careers management */}
            <Route element={<RequireAdmin />}>
              <Route path="/admin/careers" element={<AdminCareersPage />} />
              <Route
                path="/admin/careers/:id/applications"
                element={<AdminApplicationsPage />}
              />
              <Route path="/admin/exams" element={<AdminExamsPage />} />
              <Route
                path="/admin/exams/:examId"
                element={<AdminExamEditorPage />}
              />
              <Route
                path="/admin/curriculum"
                element={<AdminCurriculumPage />}
              />
              <Route
                path="/admin/curriculum/subjects/:subjectId"
                element={<AdminSubjectEditorPage />}
              />
              <Route path="/admin/coupons" element={<AdminCouponsPage />} />
              <Route
                path="/admin/essay-topics"
                element={<AdminEssayTopicsPage />}
              />
              <Route
                path="/admin/challenges"
                element={<AdminChallengesPage />}
              />
              <Route path="/admin/users" element={<AdminUsersPage />} />
              <Route path="/admin/orders" element={<AdminOrdersPage />} />
              <Route
                path="/admin/essay-analytics"
                element={<AdminEssayAnalyticsPage />}
              />
            </Route>
          </Route>

          {/* Course player — distraction-reduced, outside the AppShell */}
          <Route path="/learn/:slug" element={<PlayerPage />} />
          <Route path="/learn/:slug/:topicId" element={<PlayerPage />} />

          {/* Fullscreen exam runner — outside the AppShell */}
          <Route path="/exam/:examId" element={<ExamRunnerPage />} />
        </Route>

        {/* Public anonymous exam — no auth, reachable only by token */}
        <Route path="/public/exam/:token" element={<PublicExamPage />} />

        {/* Public informational + legal pages (logged-out and logged-in) */}
        <Route element={<PublicLayout />}>
          <Route path="/about" element={<AboutPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/training" element={<TrainingPage />} />
          <Route path="/placements" element={<PlacementsPage />} />
          <Route path="/terms" element={<TermsPage />} />
          <Route path="/privacy" element={<PrivacyPage />} />
          <Route path="/refund-policy" element={<RefundPolicyPage />} />
        </Route>

        {/* Dev-only component gallery (excluded from production build) */}
        {import.meta.env.DEV ? (
          <Route path="/dev/ui" element={<UiGalleryPage />} />
        ) : null}

        <Route path="/" element={<RootRoute />} />
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </Suspense>
  );
}
