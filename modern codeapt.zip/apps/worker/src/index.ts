/**
 * Worker entrypoint: connect to MongoDB + Redis and register one BullMQ Worker
 * per queue (default / practice / assessment / playground). The code-execution
 * processors read/write ExecutionJob docs, so the DB connection is established
 * before any worker starts. Wires graceful shutdown so in-flight jobs finish
 * cleanly.
 */
import { QUEUE_CONFIGS, QUEUE_NAME_VALUES } from "@codeapt/shared";
import { Worker } from "bullmq";

import { env } from "./config/env.js";
import { connectDb, disconnectDb } from "./lib/db.js";
import { createRedisConnection } from "./lib/redis.js";
import { logger } from "./lib/logger.js";
import { processors } from "./processors/index.js";

function start(): Worker[] {
  const connection = createRedisConnection();

  connection.on("connect", () => logger.info("Redis connected"));
  connection.on("error", (err: Error) =>
    logger.error({ err }, "Redis connection error"),
  );

  const workers = QUEUE_NAME_VALUES.map((queue) => {
    const config = QUEUE_CONFIGS[queue];
    const worker = new Worker(queue, processors[queue], {
      connection,
      concurrency: env.WORKER_CONCURRENCY,
      // Lock as long as the queue's timeout: a job that outlives this (a wedged
      // execution) is treated as stalled and reclaimed rather than stuck.
      lockDuration: config.timeoutSeconds * 1000,
    });

    worker.on("completed", (job) =>
      logger.debug({ queue, jobId: job.id }, "job completed"),
    );
    worker.on("failed", (job, err) =>
      logger.error({ queue, jobId: job?.id, err }, "job failed"),
    );

    logger.info(
      {
        queue,
        timeoutSeconds: config.timeoutSeconds,
        priority: config.priority,
      },
      `Registered worker for "${queue}" queue`,
    );
    return worker;
  });

  logger.info(`Worker up — listening on ${workers.length} queues`);
  setupGracefulShutdown(workers, connection);
  return workers;
}

async function bootstrap(): Promise<void> {
  await connectDb();
  start();
}

function setupGracefulShutdown(
  workers: Worker[],
  connection: ReturnType<typeof createRedisConnection>,
): void {
  const shutdown = (signal: string): void => {
    logger.info(`${signal} received — closing workers`);
    Promise.allSettled(workers.map((w) => w.close()))
      .then(() => connection.quit())
      .then(() => disconnectDb())
      .finally(() => {
        logger.info("Worker shutdown complete");
        process.exit(0);
      });
    setTimeout(() => process.exit(1), 10_000).unref();
  };

  process.on("SIGINT", () => shutdown("SIGINT"));
  process.on("SIGTERM", () => shutdown("SIGTERM"));
}

bootstrap().catch((err: unknown) => {
  logger.error({ err }, "worker failed to start");
  process.exit(1);
});
