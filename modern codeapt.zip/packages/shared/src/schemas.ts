/**
 * Zod schemas for payloads shared across the API boundary.
 *
 * These are the single source of truth for request/response shapes: the API
 * validates against them, the worker consumes the job payloads, and the web
 * client infers its types from them. No feature/business logic here — only
 * the shapes the walking skeleton needs plus the ones every later step reuses.
 */
import { z } from "zod";

import {
  CODE_LANGUAGE_VALUES,
  CodeLanguage,
  COUPON_DISCOUNT_TYPE_VALUES,
  CouponDiscountType,
  DAILY_QUESTION_TYPE_VALUES,
  DailyQuestionType,
  ESSAY_GRADING_STATUS_VALUES,
  ESSAY_SCORE_SOURCE_VALUES,
  ESSAY_STATUS_VALUES,
  EXAM_ATTEMPT_STATUS_VALUES,
  EXAM_QUESTION_TYPE_VALUES,
  JOB_APPLICATION_STATUS_VALUES,
  JOB_STATUS_VALUES,
  PAYMENT_STATUS_VALUES,
  POSTING_TYPE_VALUES,
  ROLE_VALUES,
  TOPIC_TYPE_VALUES,
  TopicType,
  type CouponDiscountType as CouponDiscountTypeT,
  type EssayGradingStatus,
  type EssayScoreSource,
  type EssayStatus,
  type ExamAttemptStatus,
  type ExamQuestionType,
  type JobApplicationStatus,
  type JobStatus,
  type PaymentStatus,
  type PostingType,
  type Role,
} from "./enums.js";
import {
  ADMIN_ORDERS_DEFAULT_PAGE_SIZE,
  ADMIN_ORDERS_MAX_PAGE_SIZE,
  CAREERS_DEFAULT_PAGE_SIZE,
  CAREERS_MAX_PAGE_SIZE,
  COUPON_REJECT_REASON_VALUES,
  EnrollResult,
  ESSAY_MAX_CONTENT_CHARS,
  ESSAY_SCORE_WEIGHTS,
  EXECUTION_PURPOSE_VALUES,
  LEADERBOARD_DEFAULT_PAGE_SIZE,
  LEADERBOARD_MAX_PAGE_SIZE,
  MAX_SOURCE_BYTES,
  MAX_STDIN_BYTES,
  MAX_TEST_CASES,
  QUEUE_NAME_VALUES,
  type CouponRejectReason,
  type EssayScoreDimension,
  type ExecutionPurpose,
  type QueueName,
} from "./constants.js";
import { ESSAY_RISK_LEVELS, type EssayRiskLevel } from "./essay-risk.js";

// ---------------------------------------------------------------------------
// Health
// ---------------------------------------------------------------------------

export const healthResponseSchema = z.object({
  status: z.enum(["ok", "degraded"]),
  uptime: z.number().nonnegative(),
  timestamp: z.string().datetime(),
  services: z.object({
    database: z.enum(["connected", "disconnected", "connecting", "unknown"]),
  }),
});
export type HealthResponse = z.infer<typeof healthResponseSchema>;

// ---------------------------------------------------------------------------
// Auth — requests
// ---------------------------------------------------------------------------

export const roleSchema = z.enum(ROLE_VALUES as [Role, ...Role[]]);

/** Username: 3–30 chars, letters/digits/`_ . -`. */
export const usernameSchema = z
  .string()
  .trim()
  .min(3, "Username must be at least 3 characters")
  .max(30, "Username must be at most 30 characters")
  .regex(
    /^[a-zA-Z0-9_.-]+$/,
    "Username may only contain letters, digits, and _ . -",
  );

/**
 * Password strength: 8–128 chars with at least one lowercase, one uppercase,
 * and one digit. Reused by register and change-password.
 */
export const passwordSchema = z
  .string()
  .min(8, "Password must be at least 8 characters")
  .max(128, "Password must be at most 128 characters")
  .regex(/[a-z]/, "Password must contain a lowercase letter")
  .regex(/[A-Z]/, "Password must contain an uppercase letter")
  .regex(/[0-9]/, "Password must contain a digit");

export const registerSchema = z.object({
  username: usernameSchema,
  email: z.string().email().toLowerCase(),
  password: passwordSchema,
  fullName: z.string().trim().min(1).max(150),
  rollNumber: z.string().trim().min(1).max(50),
  collegeName: z.string().trim().min(1).max(200),
  phoneNumber: z.string().trim().min(7).max(20),
  state: z.string().trim().min(1).max(100),
});
export type RegisterInput = z.infer<typeof registerSchema>;

/** Login accepts a username OR an email in a single `identifier` field. */
export const loginSchema = z.object({
  identifier: z.string().trim().min(1, "Username or email is required"),
  password: z.string().min(1, "Password is required"),
});
export type LoginInput = z.infer<typeof loginSchema>;

export const changePasswordSchema = z
  .object({
    currentPassword: z.string().min(1, "Current password is required"),
    newPassword: passwordSchema,
    confirmPassword: z.string(),
  })
  .refine((data) => data.newPassword === data.confirmPassword, {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  });
export type ChangePasswordInput = z.infer<typeof changePasswordSchema>;

/** Optional body for refresh/logout when a client sends the token explicitly
 * (browsers use the httpOnly cookie instead). */
export const refreshSchema = z.object({
  refreshToken: z.string().optional(),
});
export type RefreshInput = z.infer<typeof refreshSchema>;

/**
 * PATCH /api/me — mirrors the original UserUpdateForm (email) +
 * ProfileUpdateForm split. All fields optional; rollNumber is immutable.
 */
export const updateMeSchema = z
  .object({
    email: z.string().email().toLowerCase().optional(),
    fullName: z.string().trim().min(1).max(150).optional(),
    collegeName: z.string().trim().min(1).max(200).optional(),
    phoneNumber: z.string().trim().min(7).max(20).optional(),
    state: z.string().trim().min(1).max(100).optional(),
    bio: z.string().trim().max(500).optional(),
  })
  .refine((data) => Object.keys(data).length > 0, {
    message: "At least one field must be provided",
  });
export type UpdateMeInput = z.infer<typeof updateMeSchema>;

// ---------------------------------------------------------------------------
// Auth — responses (the typed contract the UI consumes)
// ---------------------------------------------------------------------------

export const publicUserSchema = z.object({
  id: z.string(),
  username: z.string(),
  email: z.string().email(),
  role: roleSchema,
  forcePasswordChange: z.boolean(),
  isActive: z.boolean(),
  createdAt: z.string().datetime(),
});
export type PublicUser = z.infer<typeof publicUserSchema>;

export const publicProfileSchema = z.object({
  fullName: z.string(),
  collegeName: z.string(),
  rollNumber: z.string(),
  phoneNumber: z.string(),
  state: z.string(),
  bio: z.string(),
  avatarUrl: z.string(),
});
export type PublicProfile = z.infer<typeof publicProfileSchema>;

/** GET /api/me and PATCH /api/me response body. */
export const meResponseSchema = z.object({
  user: publicUserSchema,
  profile: publicProfileSchema,
});
export type MeResponse = z.infer<typeof meResponseSchema>;

/**
 * Response for login / refresh / change-password. Tokens are ALSO set as
 * httpOnly cookies; they are echoed in the body so non-browser API clients can
 * use `Authorization: Bearer` and drive refresh themselves.
 * Read `user.forcePasswordChange` to decide whether to route to change-password.
 */
export const authResponseSchema = z.object({
  user: publicUserSchema,
  profile: publicProfileSchema,
  accessToken: z.string(),
  refreshToken: z.string(),
});
export type AuthResponse = z.infer<typeof authResponseSchema>;

/** POST /api/auth/register response — no tokens (client then logs in). */
export const registerResponseSchema = meResponseSchema;
export type RegisterResponse = z.infer<typeof registerResponseSchema>;

// ---------------------------------------------------------------------------
// Async execution / grading jobs (api -> worker payloads)
// ---------------------------------------------------------------------------

export const queueNameSchema = z.enum(
  QUEUE_NAME_VALUES as [QueueName, ...QueueName[]],
);
export const jobStatusSchema = z.enum(
  JOB_STATUS_VALUES as [JobStatus, ...JobStatus[]],
);
export const codeLanguageSchema = z.enum(
  CODE_LANGUAGE_VALUES as [CodeLanguage, ...CodeLanguage[]],
);
export const executionPurposeSchema = z.enum(
  EXECUTION_PURPOSE_VALUES as [ExecutionPurpose, ...ExecutionPurpose[]],
);

/** One graded test case (input piped to stdin; output compared to expected). */
export const testCaseSchema = z.object({
  input: z.string(),
  expectedOutput: z.string(),
});
export type TestCase = z.infer<typeof testCaseSchema>;

// TextEncoder is a standard global in both browsers and Node 18+.
const byteLen = (s: string): number => new TextEncoder().encode(s).length;

/**
 * Client → API request for `POST /api/execute`. The API generates the jobId and
 * decides the queue; the client never sets those. Size caps guard the worker
 * and Piston from oversized inputs.
 */
export const executeRequestSchema = z.object({
  language: codeLanguageSchema,
  source: z
    .string()
    .min(1, "Source cannot be empty")
    .refine((s) => byteLen(s) <= MAX_SOURCE_BYTES, {
      message: `Source exceeds ${Math.floor(MAX_SOURCE_BYTES / 1024)} KB limit`,
    }),
  stdin: z
    .string()
    .refine((s) => byteLen(s) <= MAX_STDIN_BYTES, {
      message: `stdin exceeds ${Math.floor(MAX_STDIN_BYTES / 1024)} KB limit`,
    })
    .optional(),
  /** Optional test cases for a graded run; absent for a plain playground run. */
  testCases: z.array(testCaseSchema).max(MAX_TEST_CASES).optional(),
  /** Which queue to route to; defaults to the playground queue. */
  purpose: executionPurposeSchema.default("playground"),
});
export type ExecuteRequest = z.infer<typeof executeRequestSchema>;

/** Payload enqueued onto BullMQ; the worker consumes exactly this shape. */
export const codeExecutionJobSchema = z.object({
  jobId: z.string().min(1),
  submissionRef: z.string().min(1),
  language: codeLanguageSchema,
  source: z.string(),
  stdin: z.string().optional(),
  /** Optional test cases for graded runs; absent for playground runs. */
  testCases: z.array(testCaseSchema).optional(),
});
export type CodeExecutionJob = z.infer<typeof codeExecutionJobSchema>;

/** Result of a single program run (plain or one test case). */
export const runOutputSchema = z.object({
  stdout: z.string(),
  stderr: z.string(),
  /** Process exit code; null when the run was killed by a signal/timeout. */
  exitCode: z.number().nullable(),
  /** Signal that killed the process, if any (e.g. "SIGKILL"). */
  signal: z.string().nullable(),
});
export type RunOutput = z.infer<typeof runOutputSchema>;

/** Per-test-case grading detail (present only for graded runs). */
export const testCaseResultSchema = z.object({
  index: z.number().int().nonnegative(),
  passed: z.boolean(),
  input: z.string(),
  expectedOutput: z.string(),
  actualOutput: z.string(),
  stderr: z.string(),
});
export type TestCaseResult = z.infer<typeof testCaseResultSchema>;

/**
 * The result written to ExecutionJob.result for a code job. Shared by the
 * playground now and reused by exam/challenge grading later (per-case pass/fail
 * + a passed/total tally live here).
 */
export const executionResultSchema = z.object({
  language: codeLanguageSchema,
  version: z.string(),
  /** Compile phase output (compiled languages only; null for interpreted). */
  compile: runOutputSchema.nullable(),
  /** Program run — for graded runs this is the FIRST case's run (diagnostics). */
  run: runOutputSchema,
  /** True when Piston reported the run was killed for exceeding a limit. */
  timedOut: z.boolean(),
  /** Present only for graded runs. */
  testResults: z.array(testCaseResultSchema).nullable(),
  passedCount: z.number().int().nonnegative().nullable(),
  totalCount: z.number().int().nonnegative().nullable(),
});
export type ExecutionResult = z.infer<typeof executionResultSchema>;

/** Returned immediately on submit — the client then polls/streams status. */
export const jobRefSchema = z.object({
  jobId: z.string(),
  status: jobStatusSchema,
});
export type JobRef = z.infer<typeof jobRefSchema>;

/** Payload enqueued when an essay attempt needs grading. */
export const essayGradingJobSchema = z.object({
  jobId: z.string().min(1),
  attemptId: z.string().min(1),
});
export type EssayGradingJob = z.infer<typeof essayGradingJobSchema>;

/** Generic job-status response (essay grading etc. reuse this shape). */
export const jobStatusResponseSchema = z.object({
  jobId: z.string(),
  status: jobStatusSchema,
  result: z.unknown().nullable(),
  error: z.string().nullable(),
  createdAt: z.string().datetime(),
  updatedAt: z.string().datetime(),
});
export type JobStatusResponse = z.infer<typeof jobStatusResponseSchema>;

/** `GET /api/execute/:jobId` — the generic shape narrowed to a code result. */
export const executeStatusResponseSchema = jobStatusResponseSchema.extend({
  result: executionResultSchema.nullable(),
});
export type ExecuteStatusResponse = z.infer<typeof executeStatusResponseSchema>;

// ---------------------------------------------------------------------------
// Curriculum / LMS
// ---------------------------------------------------------------------------

export const topicTypeSchema = z.enum(
  TOPIC_TYPE_VALUES as [TopicType, ...TopicType[]],
);

/** Query-string boolean ("true"/"false" -> boolean; avoids z.coerce pitfalls). */
const queryBoolean = z.enum(["true", "false"]).transform((v) => v === "true");

export const programSummarySchema = z.object({
  id: z.string(),
  name: z.string(),
  slug: z.string(),
});
export type ProgramSummary = z.infer<typeof programSummarySchema>;

// --- Catalog ---------------------------------------------------------------

export const catalogItemSchema = z.object({
  id: z.string(),
  slug: z.string(),
  name: z.string(),
  description: z.string(),
  image: z.string(),
  price: z.number().int().nonnegative(), // paise
  discountPrice: z.number().int().nonnegative(), // paise
  effectivePrice: z.number().int().nonnegative(), // paise
  isFree: z.boolean(),
  isPopular: z.boolean(),
  moduleCount: z.number().int().nonnegative(),
  topicCount: z.number().int().nonnegative(),
  program: programSummarySchema.nullable(),
  /** Only meaningful when the request is authenticated; false otherwise. */
  isEnrolled: z.boolean(),
});
export type CatalogItem = z.infer<typeof catalogItemSchema>;

export const catalogQuerySchema = z.object({
  page: z.coerce.number().int().positive().default(1),
  limit: z.coerce.number().int().positive().max(100).default(24),
  program: z.string().trim().optional(), // program slug filter
  popular: queryBoolean.optional(),
  free: queryBoolean.optional(),
  q: z.string().trim().max(120).optional(),
});
export type CatalogQuery = z.infer<typeof catalogQuerySchema>;

export const catalogResponseSchema = z.object({
  items: z.array(catalogItemSchema),
  programs: z.array(programSummarySchema),
  page: z.number().int(),
  limit: z.number().int(),
  total: z.number().int(),
  totalPages: z.number().int(),
});
export type CatalogResponse = z.infer<typeof catalogResponseSchema>;

// --- Subject detail (browse) -----------------------------------------------

export const topicNodeSchema = z.object({
  id: z.string(),
  name: z.string(),
  topicType: topicTypeSchema,
  order: z.number(),
  duration: z.string(),
  /** Content is gated: locked until the user is enrolled. */
  isLocked: z.boolean(),
  isCompleted: z.boolean(),
});
export type TopicNode = z.infer<typeof topicNodeSchema>;

export const moduleNodeSchema = z.object({
  id: z.string(),
  name: z.string(),
  order: z.number(),
  topics: z.array(topicNodeSchema),
});
export type ModuleNode = z.infer<typeof moduleNodeSchema>;

export const progressInfoSchema = z.object({
  completedTopics: z.number().int().nonnegative(),
  totalTopics: z.number().int().nonnegative(),
  percentage: z.number().int().min(0).max(100),
});
export type ProgressInfo = z.infer<typeof progressInfoSchema>;

export const enrollmentInfoSchema = z.object({
  isEnrolled: z.boolean(),
  enrolledAt: z.string().datetime().nullable(),
});
export type EnrollmentInfo = z.infer<typeof enrollmentInfoSchema>;

export const subjectDetailSchema = z.object({
  id: z.string(),
  slug: z.string(),
  name: z.string(),
  description: z.string(),
  image: z.string(),
  price: z.number().int().nonnegative(),
  discountPrice: z.number().int().nonnegative(),
  effectivePrice: z.number().int().nonnegative(),
  isFree: z.boolean(),
  isPopular: z.boolean(),
  program: programSummarySchema.nullable(),
  moduleCount: z.number().int().nonnegative(),
  topicCount: z.number().int().nonnegative(),
  modules: z.array(moduleNodeSchema),
  enrollment: enrollmentInfoSchema,
  progress: progressInfoSchema,
});
export type SubjectDetail = z.infer<typeof subjectDetailSchema>;

// --- Enrollment ------------------------------------------------------------

export const enrollResponseSchema = z.object({
  result: z.enum([EnrollResult.ENROLLED, EnrollResult.ALREADY_ENROLLED]),
  subjectSlug: z.string(),
  progress: progressInfoSchema,
});
export type EnrollResponse = z.infer<typeof enrollResponseSchema>;

export const enrollmentListItemSchema = z.object({
  subject: z.object({
    id: z.string(),
    slug: z.string(),
    name: z.string(),
    image: z.string(),
    program: programSummarySchema.nullable(),
  }),
  enrolledAt: z.string().datetime(),
  progress: progressInfoSchema,
});
export type EnrollmentListItem = z.infer<typeof enrollmentListItemSchema>;

export const myEnrollmentsResponseSchema = z.object({
  items: z.array(enrollmentListItemSchema),
});
export type MyEnrollmentsResponse = z.infer<typeof myEnrollmentsResponseSchema>;

// --- Topic content (player step consumes this) -----------------------------

export const topicContentSchema = z.object({
  id: z.string(),
  moduleId: z.string(),
  name: z.string(),
  topicType: topicTypeSchema,
  order: z.number(),
  content: z.string(),
  videoId: z.string(),
  duration: z.string(),
  isCompleted: z.boolean(),
});
export type TopicContent = z.infer<typeof topicContentSchema>;

export const topicCompleteRequestSchema = z.object({
  completed: z.boolean(),
});
export type TopicCompleteRequest = z.infer<typeof topicCompleteRequestSchema>;

export const topicCompleteResponseSchema = z.object({
  topicId: z.string(),
  isCompleted: z.boolean(),
  progress: progressInfoSchema,
});
export type TopicCompleteResponse = z.infer<typeof topicCompleteResponseSchema>;

// --- Quiz (subject-level quiz topic) ---------------------------------------

export const quizChoiceSchema = z.object({
  id: z.string(),
  text: z.string(),
});
export type QuizChoice = z.infer<typeof quizChoiceSchema>;

export const quizQuestionSchema = z.object({
  id: z.string(),
  text: z.string(),
  marks: z.number().int().nonnegative(),
  /** Choices WITHOUT the correct flag — answers never leave the server. */
  choices: z.array(quizChoiceSchema),
});
export type QuizQuestion = z.infer<typeof quizQuestionSchema>;

export const quizSchema = z.object({
  topicId: z.string(),
  subjectSlug: z.string(),
  title: z.string(),
  questions: z.array(quizQuestionSchema),
});
export type Quiz = z.infer<typeof quizSchema>;

export const quizAnswerSchema = z.object({
  questionId: z.string(),
  choiceIds: z.array(z.string()),
});
export const quizSubmitRequestSchema = z.object({
  answers: z.array(quizAnswerSchema),
});
export type QuizSubmitRequest = z.infer<typeof quizSubmitRequestSchema>;

export const quizQuestionResultSchema = z.object({
  questionId: z.string(),
  correct: z.boolean(),
  selectedChoiceIds: z.array(z.string()),
  /** Revealed only in the graded RESULT (never in the quiz GET). */
  correctChoiceIds: z.array(z.string()),
});
export type QuizQuestionResult = z.infer<typeof quizQuestionResultSchema>;

export const quizResultSchema = z.object({
  score: z.number().nonnegative(),
  maxScore: z.number().nonnegative(),
  totalQuestions: z.number().int().nonnegative(),
  correctCount: z.number().int().nonnegative(),
  percentage: z.number().int().min(0).max(100),
  results: z.array(quizQuestionResultSchema),
});
export type QuizResult = z.infer<typeof quizResultSchema>;

// ---------------------------------------------------------------------------
// Daily challenges
// ---------------------------------------------------------------------------

export const dailyQuestionTypeSchema = z.enum(
  DAILY_QUESTION_TYPE_VALUES as [DailyQuestionType, ...DailyQuestionType[]],
);

/** The user's streak snapshot, returned alongside every challenge response. */
export const streakInfoSchema = z.object({
  currentStreak: z.number().int().nonnegative(),
  maxStreak: z.number().int().nonnegative(),
  totalScore: z.number().int().nonnegative(),
  /** A correct submission exists for today's question. */
  solvedToday: z.boolean(),
  /** Any scoring submission exists for today (a wrong MCQ still counts). */
  attemptedToday: z.boolean(),
});
export type StreakInfo = z.infer<typeof streakInfoSchema>;

/** A visible sample test case (hidden cases are NEVER sent to the client). */
export const challengeSampleCaseSchema = z.object({
  input: z.string(),
  expectedOutput: z.string(),
});
export type ChallengeSampleCase = z.infer<typeof challengeSampleCaseSchema>;

/**
 * Today's challenge, sanitized: MCQ options WITHOUT `correctOption`; CODE
 * starter + language + visible sample cases only (hidden tests stay server-side).
 */
export const todayChallengeSchema = z.object({
  available: z.literal(true),
  id: z.string(),
  questionType: dailyQuestionTypeSchema,
  title: z.string(),
  description: z.string(),
  points: z.number().int().nonnegative(),
  dayKey: z.string(),
  // MCQ only.
  options: z.array(z.string()).nullable(),
  // CODE only.
  starterCode: z.string().nullable(),
  language: codeLanguageSchema.nullable(),
  sampleCases: z.array(challengeSampleCaseSchema).nullable(),
  streak: streakInfoSchema,
});
export type TodayChallenge = z.infer<typeof todayChallengeSchema>;

/** Empty-state response when no challenge is released today. */
export const noChallengeTodaySchema = z.object({
  available: z.literal(false),
  streak: streakInfoSchema,
});
export type NoChallengeToday = z.infer<typeof noChallengeTodaySchema>;

/** GET /api/challenges/today — a challenge, or the empty state (still w/ streak). */
export const challengeTodayResponseSchema = z.union([
  todayChallengeSchema,
  noChallengeTodaySchema,
]);
export type ChallengeTodayResponse = z.infer<
  typeof challengeTodayResponseSchema
>;

// --- Submit MCQ ---
export const submitMcqRequestSchema = z.object({
  option: z.number().int().nonnegative(),
});
export type SubmitMcqRequest = z.infer<typeof submitMcqRequestSchema>;

export const submitMcqResponseSchema = z.object({
  correct: z.boolean(),
  /** Revealed only in the RESULT (never in the today GET). */
  correctOption: z.number().int().nonnegative(),
  awardedPoints: z.number().int().nonnegative(),
  streak: streakInfoSchema,
});
export type SubmitMcqResponse = z.infer<typeof submitMcqResponseSchema>;

// --- Submit CODE (rides the execution pipeline) ---
export const submitCodeRequestSchema = z.object({
  language: codeLanguageSchema,
  source: z
    .string()
    .min(1, "Source cannot be empty")
    .refine((s) => byteLen(s) <= MAX_SOURCE_BYTES, {
      message: `Source exceeds ${Math.floor(MAX_SOURCE_BYTES / 1024)} KB limit`,
    }),
});
export type SubmitCodeRequest = z.infer<typeof submitCodeRequestSchema>;

/**
 * Result of finalizing a CODE submission. Poll GET /api/execute/:jobId for the
 * run itself; this reports whether it counted as solved + the updated streak.
 * Idempotent: re-finalizing returns the same result without re-awarding.
 */
export const finalizeChallengeResponseSchema = z.object({
  status: jobStatusSchema,
  graded: z
    .object({
      passedCount: z.number().int().nonnegative(),
      totalCount: z.number().int().nonnegative(),
    })
    .nullable(),
  solved: z.boolean(),
  /** Whether points were awarded (now or on a prior finalize). */
  awarded: z.boolean(),
  awardedPoints: z.number().int().nonnegative(),
  error: z.string().nullable(),
  streak: streakInfoSchema,
});
export type FinalizeChallengeResponse = z.infer<
  typeof finalizeChallengeResponseSchema
>;

// --- Leaderboard ---
export const leaderboardRowSchema = z.object({
  rank: z.number().int().positive(),
  userId: z.string(),
  name: z.string(),
  avatarUrl: z.string().nullable(),
  totalScore: z.number().int().nonnegative(),
  currentStreak: z.number().int().nonnegative(),
  isCurrentUser: z.boolean(),
});
export type LeaderboardRow = z.infer<typeof leaderboardRowSchema>;

export const leaderboardResponseSchema = z.object({
  rows: z.array(leaderboardRowSchema),
  /** The caller's own row — included even when off the visible page. */
  me: leaderboardRowSchema.nullable(),
  page: z.number().int().positive(),
  pageSize: z.number().int().positive(),
  total: z.number().int().nonnegative(),
});
export type LeaderboardResponse = z.infer<typeof leaderboardResponseSchema>;

export const leaderboardQuerySchema = z.object({
  page: z.coerce.number().int().positive().default(1),
  pageSize: z.coerce
    .number()
    .int()
    .positive()
    .max(LEADERBOARD_MAX_PAGE_SIZE)
    .default(LEADERBOARD_DEFAULT_PAGE_SIZE),
});
export type LeaderboardQuery = z.infer<typeof leaderboardQuerySchema>;

// ---------------------------------------------------------------------------
// Assessments / mock exams
// ---------------------------------------------------------------------------

export const examQuestionTypeSchema = z.enum(
  EXAM_QUESTION_TYPE_VALUES as [ExamQuestionType, ...ExamQuestionType[]],
);
export const attemptStatusSchema = z.enum(
  EXAM_ATTEMPT_STATUS_VALUES as [ExamAttemptStatus, ...ExamAttemptStatus[]],
);

export const examSampleCaseSchema = z.object({
  input: z.string(),
  expectedOutput: z.string(),
});

/** One candidate answer (MCQ selections OR code + language). */
export const answerInputSchema = z.object({
  questionId: z.string(),
  selectedOptions: z.array(z.number().int().nonnegative()).optional(),
  code: z.string().optional(),
  language: codeLanguageSchema.optional(),
});
export type AnswerInput = z.infer<typeof answerInputSchema>;

export const savedAnswerSchema = z.object({
  selectedOptions: z.array(z.number().int().nonnegative()).nullable(),
  code: z.string().nullable(),
  language: codeLanguageSchema.nullable(),
});
export type SavedAnswer = z.infer<typeof savedAnswerSchema>;

/** A question as the CANDIDATE sees it — no correctOptions, no hidden tests. */
export const sanitizedQuestionSchema = z.object({
  id: z.string(),
  type: examQuestionTypeSchema,
  text: z.string(),
  order: z.number(),
  marks: z.number().int().nonnegative(),
  image: z.string(),
  options: z.array(z.string()).nullable(),
  starterCode: z.string().nullable(),
  language: codeLanguageSchema.nullable(),
  // Language policy the candidate sees: [] = open (pick any), [lang] = locked.
  allowedLanguages: z.array(codeLanguageSchema),
  sampleCases: z.array(examSampleCaseSchema).nullable(),
  savedAnswer: savedAnswerSchema.nullable(),
});
export type SanitizedQuestion = z.infer<typeof sanitizedQuestionSchema>;

/** The current section as the candidate sees it, with server-computed time. */
export const attemptSectionViewSchema = z.object({
  attemptId: z.string(),
  status: attemptStatusSchema,
  examId: z.string(),
  examTitle: z.string(),
  sectionIndex: z.number().int().nonnegative(),
  totalSections: z.number().int().positive(),
  section: z.object({
    id: z.string(),
    name: z.string(),
    order: z.number(),
    description: z.string(),
    durationMinutes: z.number(),
  }),
  sectionRemainingSeconds: z.number().int().nonnegative(),
  questions: z.array(sanitizedQuestionSchema),
  /** Question ids in THIS section the candidate flagged for review (persisted). */
  markedForReview: z.array(z.string()),
});
export type AttemptSectionView = z.infer<typeof attemptSectionViewSchema>;

/** Start-attempt echoes the attempt token (required for anonymous continuation). */
export const startAttemptResponseSchema = attemptSectionViewSchema.extend({
  attemptToken: z.string(),
});
export type StartAttemptResponse = z.infer<typeof startAttemptResponseSchema>;

export const saveSectionAnswersRequestSchema = z.object({
  answers: z.array(answerInputSchema),
  /** Marked-for-review question ids IN THE CURRENT SECTION (persisted as-is). */
  markedForReview: z.array(z.string()).optional(),
});
export type SaveSectionAnswersRequest = z.infer<
  typeof saveSectionAnswersRequestSchema
>;
export const saveSectionAnswersResponseSchema = z.object({
  saved: z.number().int().nonnegative(),
  sectionRemainingSeconds: z.number().int().nonnegative(),
});
export type SaveSectionAnswersResponse = z.infer<
  typeof saveSectionAnswersResponseSchema
>;

export const submitAttemptRequestSchema = z.object({
  auto: z.boolean().optional(),
});
export type SubmitAttemptRequest = z.infer<typeof submitAttemptRequestSchema>;

export const recordWarningResponseSchema = z.object({
  warningsTriggered: z.number().int().nonnegative(),
  isMalpractice: z.boolean(),
  /** True when this warning crossed the limit and force-submitted the attempt. */
  autoSubmitted: z.boolean(),
});
export type RecordWarningResponse = z.infer<typeof recordWarningResponseSchema>;

// --- Graded result / review (reveals correctOptions AFTER grading) ---
export const questionResultSchema = z.object({
  questionId: z.string(),
  type: examQuestionTypeSchema,
  text: z.string(),
  maxMarks: z.number().int().nonnegative(),
  awardedMarks: z.number().int().nonnegative(),
  selectedOptions: z.array(z.number().int()).nullable(),
  correctOptions: z.array(z.number().int()).nullable(),
  code: z.string().nullable(),
  testsPassed: z.number().int().nonnegative().nullable(),
  testsTotal: z.number().int().nonnegative().nullable(),
  note: z.string().nullable(),
});
export type QuestionResult = z.infer<typeof questionResultSchema>;

export const sectionResultSchema = z.object({
  sectionId: z.string(),
  name: z.string(),
  score: z.number().int().nonnegative(),
  maxScore: z.number().int().nonnegative(),
  questions: z.array(questionResultSchema),
});
export type SectionResult = z.infer<typeof sectionResultSchema>;

export const examResultSchema = z.object({
  attemptId: z.string(),
  status: attemptStatusSchema,
  score: z.number().int().nonnegative(),
  totalMarks: z.number().int().nonnegative(),
  passPercentage: z.number().int().min(0).max(100),
  passed: z.boolean(),
  autoSubmitted: z.boolean(),
  warnings: z.number().int().nonnegative(),
  isMalpractice: z.boolean(),
  /** True while CODE grading jobs are still running. */
  gradingPending: z.boolean(),
  /** Null until fully graded. */
  sections: z.array(sectionResultSchema).nullable(),
});
export type ExamResult = z.infer<typeof examResultSchema>;

// --- Student exam list ---
export const examListItemSchema = z.object({
  id: z.string(),
  topicId: z.string(),
  title: z.string(),
  totalMarks: z.number().int().nonnegative(),
  passPercentage: z.number().int().min(0).max(100),
  sectionCount: z.number().int().nonnegative(),
  questionCount: z.number().int().nonnegative(),
  totalDurationMinutes: z.number().int().nonnegative(),
  attemptsUsed: z.number().int().nonnegative(),
  maxAttempts: z.number().int().nonnegative(),
  lastAttempt: z
    .object({
      id: z.string(),
      status: attemptStatusSchema,
      score: z.number().int().nonnegative(),
      passed: z.boolean(),
    })
    .nullable(),
});
export type ExamListItem = z.infer<typeof examListItemSchema>;
export const examListResponseSchema = z.object({
  items: z.array(examListItemSchema),
});
export type ExamListResponse = z.infer<typeof examListResponseSchema>;

// --- Public link (anonymous) ---
export const publicExamSummarySchema = z.object({
  title: z.string(),
  totalMarks: z.number().int().nonnegative(),
  passPercentage: z.number().int().min(0).max(100),
  sectionCount: z.number().int().nonnegative(),
  totalDurationMinutes: z.number().int().nonnegative(),
});
export const publicExamAvailabilitySchema = z.object({
  available: z.boolean(),
  reason: z.string().nullable(),
  exam: publicExamSummarySchema.nullable(),
});
export type PublicExamAvailability = z.infer<
  typeof publicExamAvailabilitySchema
>;
export const publicStartRequestSchema = z.object({
  rollNumber: z.string().min(1, "Roll number is required").max(64),
  collegeName: z.string().min(1, "College name is required").max(200),
});
export type PublicStartRequest = z.infer<typeof publicStartRequestSchema>;

// --- Admin authoring ---
export const adminExamUpsertSchema = z.object({
  topicId: z.string().min(1),
  title: z.string().min(1),
  passPercentage: z.number().int().min(0).max(100).default(40),
});
export type AdminExamUpsert = z.infer<typeof adminExamUpsertSchema>;

export const adminSectionUpsertSchema = z.object({
  name: z.string().min(1),
  order: z.number().int().nonnegative().default(0),
  durationMinutes: z.number().int().positive(),
  description: z.string().default(""),
});
export type AdminSectionUpsert = z.infer<typeof adminSectionUpsertSchema>;

export const adminQuestionUpsertSchema = z.object({
  sectionId: z.string().min(1),
  type: examQuestionTypeSchema,
  text: z.string().min(1),
  order: z.number().int().nonnegative().default(0),
  marks: z.number().int().nonnegative().default(5),
  options: z.array(z.string()).max(5).optional(),
  correctOptions: z.array(z.number().int().nonnegative()).optional(),
  starterCode: z.string().default(""),
  language: codeLanguageSchema.default("python"),
  // Language policy (CODE): [] = open (any language), [lang] = locked to it.
  allowedLanguages: z.array(codeLanguageSchema).default([]),
  image: z.string().default(""),
});
export type AdminQuestionUpsert = z.infer<typeof adminQuestionUpsertSchema>;

export const adminTestCaseUpsertSchema = z.object({
  input: z.string().default(""),
  expectedOutput: z.string().default(""),
  isHidden: z.boolean().default(false),
  order: z.number().int().nonnegative().default(0),
});
export type AdminTestCaseUpsert = z.infer<typeof adminTestCaseUpsertSchema>;

export const adminPublicLinkUpsertSchema = z.object({
  isActive: z.boolean().default(true),
  startTime: z.string().datetime().nullable().optional(),
  endTime: z.string().datetime().nullable().optional(),
});
export type AdminPublicLinkUpsert = z.infer<typeof adminPublicLinkUpsertSchema>;
export const publicLinkSchema = z.object({
  id: z.string(),
  accessToken: z.string(),
  isActive: z.boolean(),
  startTime: z.string().datetime().nullable(),
  endTime: z.string().datetime().nullable(),
});
export type PublicLink = z.infer<typeof publicLinkSchema>;

export const adminResetAttemptsRequestSchema = z.object({
  userId: z.string().min(1),
  reason: z.string().default(""),
});
export type AdminResetAttemptsRequest = z.infer<
  typeof adminResetAttemptsRequestSchema
>;

// Admin exam detail — the full authored tree, INCLUDING answers + test cases.
export const adminTestCaseSchema = z.object({
  id: z.string(),
  input: z.string(),
  expectedOutput: z.string(),
  isHidden: z.boolean(),
  order: z.number(),
});
export const adminQuestionSchema = z.object({
  id: z.string(),
  type: examQuestionTypeSchema,
  text: z.string(),
  order: z.number(),
  marks: z.number().int().nonnegative(),
  options: z.array(z.string()).nullable(),
  correctOptions: z.array(z.number().int()).nullable(),
  starterCode: z.string(),
  language: codeLanguageSchema,
  // Language policy (CODE): [] = open, [lang] = locked to that language.
  allowedLanguages: z.array(codeLanguageSchema),
  image: z.string(),
  testCases: z.array(adminTestCaseSchema),
});
export const adminSectionSchema = z.object({
  id: z.string(),
  name: z.string(),
  order: z.number(),
  durationMinutes: z.number(),
  description: z.string(),
  questions: z.array(adminQuestionSchema),
});
export const adminExamDetailSchema = z.object({
  id: z.string(),
  topicId: z.string(),
  title: z.string(),
  totalMarks: z.number().int().nonnegative(),
  passPercentage: z.number().int().min(0).max(100),
  sections: z.array(adminSectionSchema),
  publicLinks: z.array(publicLinkSchema),
});
export type AdminExamDetail = z.infer<typeof adminExamDetailSchema>;

// Admin exam list — every exam (regardless of enrollment) with cheap counts.
export const adminExamSummarySchema = z.object({
  id: z.string(),
  topicId: z.string(),
  title: z.string(),
  totalMarks: z.number().int().nonnegative(),
  passPercentage: z.number().int().min(0).max(100),
  sectionCount: z.number().int().nonnegative(),
  questionCount: z.number().int().nonnegative(),
});
export type AdminExamSummary = z.infer<typeof adminExamSummarySchema>;
export const adminExamListResponseSchema = z.object({
  items: z.array(adminExamSummarySchema),
});
export type AdminExamListResponse = z.infer<
  typeof adminExamListResponseSchema
>;

// ---------------------------------------------------------------------------
// Curriculum admin authoring — structural tree (Program / Subject / Module).
// Money stays integer paise. Slug is optional on write: derived from the name
// when omitted; a clean validation error (SLUG_TAKEN) on collision.
// ---------------------------------------------------------------------------

/** Reorder a sibling set by supplying the full ordered id array (order = index). */
export const adminReorderSchema = z.object({
  ids: z.array(z.string().min(1)).min(1),
});
export type AdminReorder = z.infer<typeof adminReorderSchema>;

/** Optional slug on write: lowercase kebab, letters/numbers/hyphens only. */
const adminSlugField = z
  .string()
  .trim()
  .toLowerCase()
  .regex(
    /^[a-z0-9]+(?:-[a-z0-9]+)*$/,
    "Slug may contain only lowercase letters, numbers, and single hyphens",
  )
  .optional();

// --- Program ---
export const adminProgramUpsertSchema = z.object({
  name: z.string().trim().min(1),
  slug: adminSlugField,
  description: z.string().default(""),
  order: z.number().int().nonnegative().default(0),
  isVisible: z.boolean().default(true),
});
export type AdminProgramUpsert = z.infer<typeof adminProgramUpsertSchema>;

export const adminProgramSchema = z.object({
  id: z.string(),
  name: z.string(),
  slug: z.string(),
  description: z.string(),
  order: z.number(),
  isVisible: z.boolean(),
  subjectCount: z.number().int().nonnegative(),
});
export type AdminProgram = z.infer<typeof adminProgramSchema>;
export const adminProgramListResponseSchema = z.object({
  items: z.array(adminProgramSchema),
});
export type AdminProgramListResponse = z.infer<
  typeof adminProgramListResponseSchema
>;

// --- Subject ---
export const adminSubjectUpsertSchema = z.object({
  name: z.string().trim().min(1),
  slug: adminSlugField,
  /** Program to file the subject under; null/omitted = unfiled. */
  programId: z.string().min(1).nullable().optional(),
  /**
   * Stored as a URL string (or empty). Populated by the Cloudinary signed-upload
   * pipeline (ImageUpload → secure_url); a pasted URL is still accepted for
   * backward-compat with existing records.
   */
  image: z
    .union([z.string().trim().url(), z.literal("")])
    .default(""),
  description: z.string().default(""),
  price: z.number().int().nonnegative().default(0), // paise
  discountPrice: z.number().int().nonnegative().default(0), // paise
  isPopular: z.boolean().default(false),
  isVisible: z.boolean().default(true),
});
export type AdminSubjectUpsert = z.infer<typeof adminSubjectUpsertSchema>;

export const adminSubjectSchema = z.object({
  id: z.string(),
  programId: z.string().nullable(),
  programName: z.string().nullable(),
  name: z.string(),
  slug: z.string(),
  image: z.string(),
  description: z.string(),
  price: z.number().int().nonnegative(),
  discountPrice: z.number().int().nonnegative(),
  isPopular: z.boolean(),
  isVisible: z.boolean(),
  moduleCount: z.number().int().nonnegative(),
  enrollmentCount: z.number().int().nonnegative(),
});
export type AdminSubject = z.infer<typeof adminSubjectSchema>;
export const adminSubjectListResponseSchema = z.object({
  items: z.array(adminSubjectSchema),
});
export type AdminSubjectListResponse = z.infer<
  typeof adminSubjectListResponseSchema
>;

// --- Module ---
export const adminModuleUpsertSchema = z.object({
  name: z.string().trim().min(1),
  order: z.number().int().nonnegative().default(0),
});
export type AdminModuleUpsert = z.infer<typeof adminModuleUpsertSchema>;

export const adminModuleSchema = z.object({
  id: z.string(),
  subjectId: z.string(),
  name: z.string(),
  order: z.number(),
  topicCount: z.number().int().nonnegative(),
});
export type AdminModule = z.infer<typeof adminModuleSchema>;
export const adminModuleListResponseSchema = z.object({
  items: z.array(adminModuleSchema),
});
export type AdminModuleListResponse = z.infer<
  typeof adminModuleListResponseSchema
>;

// ---------------------------------------------------------------------------
// Curriculum admin authoring — leaf tree (Topic + quiz Question/Choice).
//
// The Topic upsert is a DISCRIMINATED UNION on topicType so each type carries
// only its own fields (matches the original admin form, which shows type-
// specific inputs). `order` is optional on write — omit to append at the end of
// the module (service assigns max+1); it is a FLOAT so topics insert between.
// ---------------------------------------------------------------------------

// Fields shared by every topic type. `order` omitted => append (service-side).
const adminTopicBase = {
  name: z.string().trim().min(1),
  order: z.number().optional(),
  isVisible: z.boolean().default(true),
};

export const adminTopicUpsertSchema = z.discriminatedUnion("topicType", [
  z.object({
    topicType: z.literal(TopicType.TEXT),
    ...adminTopicBase,
    content: z.string().default(""),
  }),
  z.object({
    topicType: z.literal(TopicType.VIDEO),
    ...adminTopicBase,
    // Bare YouTube id (extraction is a UI concern); duration is a label string.
    videoId: z.string().trim().default(""),
    duration: z.string().trim().default(""),
  }),
  z.object({
    topicType: z.literal(TopicType.QUIZ),
    ...adminTopicBase,
  }),
  z.object({
    topicType: z.literal(TopicType.EXAM),
    ...adminTopicBase,
  }),
  z.object({
    topicType: z.literal(TopicType.ESSAY),
    ...adminTopicBase,
    // Optional + nullable: an essay topic may exist with no prompt linked yet.
    essayTopicId: z.string().min(1).nullable().optional(),
  }),
]);
export type AdminTopicUpsert = z.infer<typeof adminTopicUpsertSchema>;

export const adminTopicSchema = z.object({
  id: z.string(),
  moduleId: z.string(),
  name: z.string(),
  topicType: topicTypeSchema,
  order: z.number(),
  isVisible: z.boolean(),
  content: z.string(),
  videoId: z.string(),
  duration: z.string(),
  /** Set only for essay topics (null when unlinked or not an essay topic). */
  essayTopicId: z.string().nullable(),
  essayTopicTitle: z.string().nullable(),
  /** Set only for exam topics — the linked Exam's id (null otherwise). */
  examId: z.string().nullable(),
  /** Authored quiz question count (0 unless a quiz topic). */
  questionCount: z.number().int().nonnegative(),
});
export type AdminTopic = z.infer<typeof adminTopicSchema>;
export const adminTopicListResponseSchema = z.object({
  items: z.array(adminTopicSchema),
});
export type AdminTopicListResponse = z.infer<
  typeof adminTopicListResponseSchema
>;

// --- Quiz Question / Choice (subject-level quiz, scoped to a quiz topic) ---
export const adminChoiceUpsertSchema = z.object({
  text: z.string().trim().min(1),
  isCorrect: z.boolean().default(false),
});
export type AdminChoiceUpsert = z.infer<typeof adminChoiceUpsertSchema>;

export const adminQuizQuestionUpsertSchema = z
  .object({
    text: z.string().trim().min(1),
    marks: z.number().int().nonnegative().default(1),
    // Choices are a nested write (replace-all on update). A quiz question is
    // always MCQ: >= 2 choices, >= 1 correct (multiple correct is allowed).
    choices: z
      .array(adminChoiceUpsertSchema)
      .min(2, "A question needs at least 2 choices"),
  })
  .refine((q) => q.choices.some((c) => c.isCorrect), {
    message: "At least one choice must be marked correct",
    path: ["choices"],
  });
export type AdminQuizQuestionUpsert = z.infer<
  typeof adminQuizQuestionUpsertSchema
>;

export const adminChoiceSchema = z.object({
  id: z.string(),
  text: z.string(),
  isCorrect: z.boolean(),
});
export const adminQuizQuestionSchema = z.object({
  id: z.string(),
  topicId: z.string(),
  text: z.string(),
  marks: z.number().int().nonnegative(),
  choices: z.array(adminChoiceSchema),
});
export type AdminQuizQuestion = z.infer<typeof adminQuizQuestionSchema>;
export const adminQuizQuestionListResponseSchema = z.object({
  items: z.array(adminQuizQuestionSchema),
});
export type AdminQuizQuestionListResponse = z.infer<
  typeof adminQuizQuestionListResponseSchema
>;

// --- Exam-topic picker (what the 4b exam editor needs to attach/find exams) ---
export const adminExamTopicSchema = z.object({
  topicId: z.string(),
  examId: z.string(),
  name: z.string(),
  moduleId: z.string(),
  moduleName: z.string(),
  subjectId: z.string(),
  subjectName: z.string(),
});
export type AdminExamTopic = z.infer<typeof adminExamTopicSchema>;
export const adminExamTopicListResponseSchema = z.object({
  items: z.array(adminExamTopicSchema),
});
export type AdminExamTopicListResponse = z.infer<
  typeof adminExamTopicListResponseSchema
>;

// --- Excel bulk upload ---
export const excelUploadRequestSchema = z.object({
  /** The .xlsx workbook, base64-encoded. */
  fileBase64: z.string().min(1),
});
export type ExcelUploadRequest = z.infer<typeof excelUploadRequestSchema>;
export const excelRowErrorSchema = z.object({
  sheet: z.string(),
  row: z.number().int(),
  message: z.string(),
});
export const excelUploadResponseSchema = z.object({
  createdSections: z.number().int().nonnegative(),
  createdQuestions: z.number().int().nonnegative(),
  createdTestCases: z.number().int().nonnegative(),
  errors: z.array(excelRowErrorSchema),
});
export type ExcelUploadResponse = z.infer<typeof excelUploadResponseSchema>;

// --- Bulk topic import (text/video only; per-subject) ---
/** One per-row failure in a topic bulk-upload (partial success is the norm). */
export const topicRowErrorSchema = z.object({
  row: z.number().int(),
  message: z.string(),
});
export const topicExcelUploadResponseSchema = z.object({
  createdModules: z.number().int().nonnegative(),
  createdTopics: z.number().int().nonnegative(),
  errors: z.array(topicRowErrorSchema),
});
export type TopicExcelUploadResponse = z.infer<
  typeof topicExcelUploadResponseSchema
>;

// --- Bulk enroll (roster → provision users + enroll across subjects) ---
export const bulkEnrollRequestSchema = z.object({
  /** Enroll the roster across one or more subjects in a single pass. */
  subjectIds: z.array(z.string().min(1)).min(1, "Select at least one course"),
  /** The .xlsx roster, base64-encoded. */
  fileBase64: z.string().min(1),
});
export type BulkEnrollRequest = z.infer<typeof bulkEnrollRequestSchema>;
export const bulkEnrollResponseSchema = z.object({
  /** Newly provisioned student accounts (existing users are reused). */
  createdUsers: z.number().int().nonnegative(),
  /** New enrollments added across the selected subjects. */
  enrolledCount: z.number().int().nonnegative(),
  errors: z.array(topicRowErrorSchema),
});
export type BulkEnrollResponse = z.infer<typeof bulkEnrollResponseSchema>;

// ---------------------------------------------------------------------------
// Generic API error envelope
// ---------------------------------------------------------------------------

export const apiErrorSchema = z.object({
  error: z.object({
    message: z.string(),
    code: z.string().optional(),
    /** Field-level validation issues, when applicable. */
    details: z.unknown().optional(),
  }),
});
export type ApiError = z.infer<typeof apiErrorSchema>;

// ---------------------------------------------------------------------------
// Essays (AI-graded writing)
//
// Two projections of a prompt: the STUDENT projection (browse + detail) never
// carries reference keywords or rubric internals; those live only in the ADMIN
// projection. Grading results expose the per-dimension breakdown, the score
// source (ai_hybrid | deterministic_fallback), and a feedback summary.
// ---------------------------------------------------------------------------

export const essayGradingStatusSchema = z.enum(
  ESSAY_GRADING_STATUS_VALUES as [EssayGradingStatus, ...EssayGradingStatus[]],
);
export const essayScoreSourceSchema = z.enum(
  ESSAY_SCORE_SOURCE_VALUES as [EssayScoreSource, ...EssayScoreSource[]],
);
export const essayDifficultySchema = z.union([
  z.literal(1),
  z.literal(2),
  z.literal(3),
]);

// ---------------------------------------------------------------------------
// Essay-topic (prompt) admin authoring — CRUD over the EssayTopic model. The
// semanticKeywords feed the grader's relevance dimension (manual for now; AI
// keyword-generation awaits the real essay-AI integration — see the service).
// ---------------------------------------------------------------------------

export const adminEssayTopicUpsertSchema = z
  .object({
    title: z.string().trim().min(1),
    description: z.string().default(""),
    instructions: z.string().default(""),
    difficultyLevel: essayDifficultySchema.default(1),
    minWords: z.number().int().nonnegative().default(0),
    maxWords: z.number().int().nonnegative().default(0),
    timeLimitMinutes: z.number().int().nonnegative().default(0),
    /** Per-topic attempt cap (submitted attempts). Defaults to the original's 3. */
    maxAttempts: z.number().int().min(1).default(3),
    isActive: z.boolean().default(true),
    /** Reference keywords for the relevance analyzer (deduped, non-empty). */
    semanticKeywords: z.array(z.string().trim().min(1)).default([]),
  })
  .refine((t) => t.maxWords === 0 || t.minWords === 0 || t.maxWords >= t.minWords, {
    message: "Max words must be greater than or equal to min words",
    path: ["maxWords"],
  });
export type AdminEssayTopicUpsert = z.infer<typeof adminEssayTopicUpsertSchema>;

export const adminEssayTopicSchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string(),
  instructions: z.string(),
  difficultyLevel: essayDifficultySchema,
  minWords: z.number().int().nonnegative(),
  maxWords: z.number().int().nonnegative(),
  timeLimitMinutes: z.number().int().nonnegative(),
  maxAttempts: z.number().int().positive(),
  isActive: z.boolean(),
  semanticKeywords: z.array(z.string()),
  /** Student attempts referencing this prompt (drives delete-block). */
  attemptCount: z.number().int().nonnegative(),
  /** Curriculum essay-topics linking this prompt (SET_NULL on delete). */
  linkedTopicCount: z.number().int().nonnegative(),
});
export type AdminEssayTopic = z.infer<typeof adminEssayTopicSchema>;
/**
 * Generate semantic keywords for a topic (LLM-assisted, ADVISORY). Works for
 * unsaved topics too — the dialog sends the current title/description/
 * instructions, not an id. The response is a PROPOSAL the admin edits + saves;
 * it is never auto-applied. `source` reveals whether the LLM ran or the
 * deterministic fallback did.
 */
export const generateKeywordsRequestSchema = z.object({
  title: z.string().trim().min(1),
  description: z.string().default(""),
  instructions: z.string().default(""),
});
export type GenerateKeywordsRequest = z.infer<
  typeof generateKeywordsRequestSchema
>;

export const keywordSourceSchema = z.enum(["llm", "deterministic"]);
export type KeywordSource = z.infer<typeof keywordSourceSchema>;

export const generateKeywordsResponseSchema = z.object({
  keywords: z.array(z.string()),
  source: keywordSourceSchema,
});
export type GenerateKeywordsResponse = z.infer<
  typeof generateKeywordsResponseSchema
>;

export const adminEssayTopicListResponseSchema = z.object({
  items: z.array(adminEssayTopicSchema),
});
export type AdminEssayTopicListResponse = z.infer<
  typeof adminEssayTopicListResponseSchema
>;

// ---------------------------------------------------------------------------
// Daily-challenge authoring (admin)
// ---------------------------------------------------------------------------

/** An IST "challenge day" key, `YYYY-MM-DD` (the canonical schedule slot). */
export const challengeDayKeySchema = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}$/, "Date must be YYYY-MM-DD");

/** A CODE challenge's test case (hidden cases never leave the server). */
export const adminChallengeTestCaseSchema = z.object({
  input: z.string().default(""),
  expectedOutput: z.string().default(""),
  isHidden: z.boolean().default(false),
});
export type AdminChallengeTestCase = z.infer<
  typeof adminChallengeTestCaseSchema
>;

/**
 * Create/update payload for a DailyQuestion. `releaseDate` is a day key; the
 * service normalizes it to the IST-midnight instant the serving query matches.
 * MCQ needs ≥2 options and an in-range correct index; CODE carries a starter,
 * language, and test cases (the MCQ fields are ignored, and vice versa).
 */
export const adminChallengeUpsertSchema = z
  .object({
    questionType: dailyQuestionTypeSchema,
    releaseDate: challengeDayKeySchema,
    title: z.string().trim().min(1),
    description: z.string().default(""),
    marks: z.number().int().nonnegative().default(5),
    // MCQ
    options: z.array(z.string().trim().min(1)).default([]),
    correctOption: z.number().int().nonnegative().default(0),
    // CODE
    starterCode: z.string().default(""),
    language: codeLanguageSchema.default(CodeLanguage.PYTHON),
    testCases: z.array(adminChallengeTestCaseSchema).default([]),
  })
  .superRefine((v, ctx) => {
    if (v.questionType === DailyQuestionType.MCQ) {
      if (v.options.length < 2) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "An MCQ needs at least two options",
          path: ["options"],
        });
      }
      if (v.correctOption >= v.options.length) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "Correct option is out of range",
          path: ["correctOption"],
        });
      }
    }
  });
export type AdminChallengeUpsert = z.infer<typeof adminChallengeUpsertSchema>;

/** Full challenge detail (create/update/get) — includes test cases. */
export const adminChallengeSchema = z.object({
  id: z.string(),
  questionType: dailyQuestionTypeSchema,
  releaseDate: challengeDayKeySchema,
  title: z.string(),
  description: z.string(),
  marks: z.number().int().nonnegative(),
  options: z.array(z.string()),
  correctOption: z.number().int().nonnegative(),
  starterCode: z.string(),
  language: codeLanguageSchema,
  testCases: z.array(adminChallengeTestCaseSchema),
  /** Scored submissions referencing this question (drives delete-block). */
  submissionCount: z.number().int().nonnegative(),
});
export type AdminChallenge = z.infer<typeof adminChallengeSchema>;

/** Lightweight list row (no test-case bodies). */
export const adminChallengeListItemSchema = z.object({
  id: z.string(),
  questionType: dailyQuestionTypeSchema,
  releaseDate: challengeDayKeySchema,
  title: z.string(),
  marks: z.number().int().nonnegative(),
  testCaseCount: z.number().int().nonnegative(),
  submissionCount: z.number().int().nonnegative(),
});
export type AdminChallengeListItem = z.infer<
  typeof adminChallengeListItemSchema
>;
export const adminChallengeListResponseSchema = z.object({
  items: z.array(adminChallengeListItemSchema),
});
export type AdminChallengeListResponse = z.infer<
  typeof adminChallengeListResponseSchema
>;

/**
 * Excel bulk import. `startDate` present ⇒ SEQUENTIAL scheduling (row order,
 * one per consecutive day); absent ⇒ each row's `date` column is EXPLICIT.
 * Reuses the base64 body shape. Conflicts (an occupied date, in the DB or
 * earlier in the sheet) are reported per-row and skipped — never overwritten.
 */
export const adminChallengeBulkImportRequestSchema = z.object({
  fileBase64: z.string().min(1),
  startDate: challengeDayKeySchema.optional(),
});
export type AdminChallengeBulkImportRequest = z.infer<
  typeof adminChallengeBulkImportRequestSchema
>;
export const adminChallengeBulkImportResponseSchema = z.object({
  scheduled: z.number().int().nonnegative(),
  errors: z.array(topicRowErrorSchema),
});
export type AdminChallengeBulkImportResponse = z.infer<
  typeof adminChallengeBulkImportResponseSchema
>;

// ---------------------------------------------------------------------------
// User admin + per-college performance (item 4-i) — read/reporting
// ---------------------------------------------------------------------------

export const ADMIN_USER_DEFAULT_PAGE_SIZE = 20;
export const ADMIN_USER_MAX_PAGE_SIZE = 100;

/** List/search query (coerced from query-string params). */
export const adminUserListQuerySchema = z.object({
  q: z.string().trim().default(""),
  role: roleSchema.optional(),
  college: z.string().trim().optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce
    .number()
    .int()
    .min(1)
    .max(ADMIN_USER_MAX_PAGE_SIZE)
    .default(ADMIN_USER_DEFAULT_PAGE_SIZE),
});
export type AdminUserListQuery = z.infer<typeof adminUserListQuerySchema>;

export const adminUserListItemSchema = z.object({
  id: z.string(),
  username: z.string(),
  email: z.string(),
  role: roleSchema,
  isActive: z.boolean(),
  fullName: z.string(),
  collegeName: z.string(),
  rollNumber: z.string(),
  createdAt: z.string(),
  lastLoginAt: z.string().nullable(),
});
export type AdminUserListItem = z.infer<typeof adminUserListItemSchema>;

export const adminUserListResponseSchema = z.object({
  items: z.array(adminUserListItemSchema),
  total: z.number().int().nonnegative(),
  page: z.number().int().min(1),
  pageSize: z.number().int().min(1),
});
export type AdminUserListResponse = z.infer<typeof adminUserListResponseSchema>;

/** One enrollment row on the user-detail view. */
export const adminUserEnrollmentSchema = z.object({
  id: z.string(),
  subject: z.string(),
  source: z.string(),
  createdAt: z.string(),
});
/** One exam attempt row. */
export const adminUserExamAttemptSchema = z.object({
  exam: z.string(),
  score: z.number(),
  totalMarks: z.number(),
  passed: z.boolean(),
  status: z.string(),
  completedAt: z.string().nullable(),
});
/** One essay attempt row. */
export const adminUserEssayAttemptSchema = z.object({
  topic: z.string(),
  finalScore: z.number(),
  status: z.string(),
  submittedAt: z.string().nullable(),
});
/** One topic-progress row (ledger read — CRUD batch 3a). */
export const adminUserTopicProgressSchema = z.object({
  topic: z.string(),
  isCompleted: z.boolean(),
  completedAt: z.string().nullable(),
});
/** One subject-quiz submission row. `percentage` derives from score/total. */
export const adminUserQuizSubmissionSchema = z.object({
  subject: z.string(),
  topic: z.string().nullable(),
  score: z.number(),
  totalQuestions: z.number(),
  percentage: z.number(),
  submittedAt: z.string().nullable(),
});
/** One daily-challenge submission row. */
export const adminUserDailySubmissionSchema = z.object({
  question: z.string(),
  releaseDate: z.string().nullable(),
  isCorrect: z.boolean(),
  score: z.number(),
  submittedAt: z.string().nullable(),
});

/** Read-only aggregate of everything queryable about one user. */
export const adminUserDetailSchema = z.object({
  id: z.string(),
  username: z.string(),
  email: z.string(),
  role: roleSchema,
  isActive: z.boolean(),
  createdAt: z.string(),
  lastLoginAt: z.string().nullable(),
  profile: z.object({
    fullName: z.string(),
    collegeName: z.string(),
    rollNumber: z.string(),
    phoneNumber: z.string(),
    state: z.string(),
    bio: z.string(),
  }),
  stats: z.object({
    enrollments: z.number().int().nonnegative(),
    examAttempts: z.number().int().nonnegative(),
    examsPassed: z.number().int().nonnegative(),
    essayAttempts: z.number().int().nonnegative(),
    topicsCompleted: z.number().int().nonnegative(),
    quizSubmissions: z.number().int().nonnegative(),
    dailySubmissions: z.number().int().nonnegative(),
    currentStreak: z.number().int().nonnegative(),
    maxStreak: z.number().int().nonnegative(),
    dailyTotalScore: z.number().int().nonnegative(),
  }),
  enrollments: z.array(adminUserEnrollmentSchema),
  examAttempts: z.array(adminUserExamAttemptSchema),
  essayAttempts: z.array(adminUserEssayAttemptSchema),
  // Ledger read rows (CRUD batch 3a) — the detail already carried counts in
  // `stats`; these expose the underlying per-row history read-only.
  topicProgress: z.array(adminUserTopicProgressSchema),
  quizSubmissions: z.array(adminUserQuizSubmissionSchema),
  dailySubmissions: z.array(adminUserDailySubmissionSchema),
});
export type AdminUserDetail = z.infer<typeof adminUserDetailSchema>;

/** CONFIG mutations (item CRUD-batch-2). Machinery fields are never accepted. */
export const adminSetUserActiveSchema = z.object({ isActive: z.boolean() });
export type AdminSetUserActive = z.infer<typeof adminSetUserActiveSchema>;

export const adminSetUserRoleSchema = z.object({ role: roleSchema });
export type AdminSetUserRole = z.infer<typeof adminSetUserRoleSchema>;

/** Editable Profile fields only — no passwordHash / tokenVersion / role here. */
export const adminUpdateProfileSchema = z.object({
  fullName: z.string().trim().min(1),
  collegeName: z.string().trim().default(""),
  rollNumber: z.string().trim().min(1),
  phoneNumber: z.string().trim().default(""),
  state: z.string().trim().default(""),
  bio: z.string().default(""),
});
export type AdminUpdateProfile = z.infer<typeof adminUpdateProfileSchema>;

// ---------------------------------------------------------------------------
// Essay analytics review (item 4-ii) — read/reporting
// ---------------------------------------------------------------------------

export const essayStatusSchema = z.enum(
  ESSAY_STATUS_VALUES as [EssayStatus, ...EssayStatus[]],
);

export const essayRiskLevelSchema = z.enum(
  ESSAY_RISK_LEVELS as unknown as [EssayRiskLevel, ...EssayRiskLevel[]],
);

export const ADMIN_ESSAY_ANALYTICS_DEFAULT_PAGE_SIZE = 20;
export const ADMIN_ESSAY_ANALYTICS_MAX_PAGE_SIZE = 100;

export const adminEssayAnalyticsListQuerySchema = z.object({
  essayTopic: z.string().trim().optional(),
  status: essayStatusSchema.optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce
    .number()
    .int()
    .min(1)
    .max(ADMIN_ESSAY_ANALYTICS_MAX_PAGE_SIZE)
    .default(ADMIN_ESSAY_ANALYTICS_DEFAULT_PAGE_SIZE),
});
export type AdminEssayAnalyticsListQuery = z.infer<
  typeof adminEssayAnalyticsListQuerySchema
>;

/** One row in the essay-analytics review list. */
export const adminEssayAnalyticsListItemSchema = z.object({
  attemptId: z.string(),
  student: z.string(),
  topic: z.string(),
  finalScore: z.number(),
  status: z.string(),
  submittedAt: z.string().nullable(),
  /** Whether a stored analytics sidecar exists for this attempt. */
  hasAnalytics: z.boolean(),
  /** Compact real-signal preview (0 when no analytics stored). */
  pasteEvents: z.number().int().nonnegative(),
  pastedChars: z.number().int().nonnegative(),
  /** Advisory risk (computed from stored signals; 0/low when no analytics). */
  riskScore: z.number().int().nonnegative(),
  riskLevel: essayRiskLevelSchema,
  suspicious: z.boolean(),
});
export type AdminEssayAnalyticsListItem = z.infer<
  typeof adminEssayAnalyticsListItemSchema
>;

export const adminEssayAnalyticsListResponseSchema = z.object({
  items: z.array(adminEssayAnalyticsListItemSchema),
  total: z.number().int().nonnegative(),
  page: z.number().int().min(1),
  pageSize: z.number().int().min(1),
});
export type AdminEssayAnalyticsListResponse = z.infer<
  typeof adminEssayAnalyticsListResponseSchema
>;

/** The REAL compose signals `recordAnalytics` actually persists. */
export const adminEssaySignalsSchema = z.object({
  keystrokes: z.number().int().nonnegative(),
  deletes: z.number().int().nonnegative(),
  pasteEvents: z.number().int().nonnegative(),
  pastedChars: z.number().int().nonnegative(),
  composeSeconds: z.number().int().nonnegative(),
  finalWordCount: z.number().int().nonnegative(),
  finalCharacterCount: z.number().int().nonnegative(),
});

/**
 * Per-attempt analytics detail. `signals` are the genuine stored values;
 * `riskScoring` is the ADVISORY anti-cheat assessment, computed server-side
 * from the stored signals (never a client value). `wired` is now true, and
 * `reasons` explains every signal that fired. It is a review aid — it never
 * penalizes a student or affects a grade.
 */
export const adminEssayAttemptAnalyticsSchema = z.object({
  attemptId: z.string(),
  student: z.string(),
  topic: z.string(),
  finalScore: z.number(),
  status: z.string(),
  submittedAt: z.string().nullable(),
  wordCount: z.number().int().nonnegative(),
  characterCount: z.number().int().nonnegative(),
  hasAnalytics: z.boolean(),
  signals: adminEssaySignalsSchema.nullable(),
  riskScoring: z.object({
    /** True — the advisory scoring model is wired (computed from signals). */
    wired: z.boolean(),
    /** 0..100 advisory score computed from the stored compose signals. */
    riskScore: z.number().int().nonnegative(),
    level: essayRiskLevelSchema,
    /** Advisory flag (MEDIUM or worse); never auto-penalizes. */
    suspiciousActivity: z.boolean(),
    /** Human-readable explanation of each signal that fired (may be empty). */
    reasons: z.array(z.string()),
  }),
});
export type AdminEssayAttemptAnalytics = z.infer<
  typeof adminEssayAttemptAnalyticsSchema
>;

// ---------------------------------------------------------------------------
// Exam attempt-management reads (item C4) — read/reporting
// ---------------------------------------------------------------------------

/** One row of the per-exam attempt-counter list. */
export const adminExamAttemptCounterSchema = z.object({
  userId: z.string(),
  student: z.string(),
  rollNumber: z.string(),
  attemptCount: z.number().int().nonnegative(),
  maxAttempts: z.number().int().nonnegative(),
  /** attemptCount >= maxAttempts. */
  exhausted: z.boolean(),
});
export type AdminExamAttemptCounter = z.infer<
  typeof adminExamAttemptCounterSchema
>;
export const adminExamAttemptCountersResponseSchema = z.object({
  examId: z.string(),
  examTitle: z.string(),
  items: z.array(adminExamAttemptCounterSchema),
});
export type AdminExamAttemptCountersResponse = z.infer<
  typeof adminExamAttemptCountersResponseSchema
>;

/** One of a user's attempt rows on a given exam. */
export const adminExamAttemptRowSchema = z.object({
  attemptId: z.string(),
  status: z.string(),
  score: z.number(),
  passed: z.boolean(),
  warnings: z.number().int().nonnegative(),
  isMalpractice: z.boolean(),
  startedAt: z.string().nullable(),
  completedAt: z.string().nullable(),
});
export type AdminExamAttemptRow = z.infer<typeof adminExamAttemptRowSchema>;

export const adminUserExamAttemptsResponseSchema = z.object({
  examId: z.string(),
  examTitle: z.string(),
  userId: z.string(),
  student: z.string(),
  counter: z
    .object({
      attemptCount: z.number().int().nonnegative(),
      maxAttempts: z.number().int().nonnegative(),
    })
    .nullable(),
  attempts: z.array(adminExamAttemptRowSchema),
});
export type AdminUserExamAttemptsResponse = z.infer<
  typeof adminUserExamAttemptsResponseSchema
>;

/** One immutable reset-audit row. */
export const adminExamResetLogRowSchema = z.object({
  id: z.string(),
  student: z.string(),
  resetBy: z.string(),
  previousCount: z.number().int().nonnegative(),
  reason: z.string(),
  resetAt: z.string(),
});
export type AdminExamResetLogRow = z.infer<typeof adminExamResetLogRowSchema>;
export const adminExamResetLogResponseSchema = z.object({
  examId: z.string(),
  examTitle: z.string(),
  items: z.array(adminExamResetLogRowSchema),
});
export type AdminExamResetLogResponse = z.infer<
  typeof adminExamResetLogResponseSchema
>;

/** The seven weighted 0..100 sub-scores. Keys are fixed by ESSAY_SCORE_WEIGHTS. */
export const essayDimensionScoresSchema = z.object(
  Object.fromEntries(
    (Object.keys(ESSAY_SCORE_WEIGHTS) as EssayScoreDimension[]).map((d) => [
      d,
      z.number(),
    ]),
  ) as Record<EssayScoreDimension, z.ZodNumber>,
);
export type EssayDimensionScoresDto = z.infer<
  typeof essayDimensionScoresSchema
>;

/** Compact summary of the caller's latest attempt at a prompt (list view). */
export const essayLastAttemptSchema = z.object({
  id: z.string(),
  attemptNumber: z.number().int().positive(),
  status: essayGradingStatusSchema,
  finalScore: z.number().nullable(),
  source: essayScoreSourceSchema.nullable(),
});
export type EssayLastAttempt = z.infer<typeof essayLastAttemptSchema>;

/** Essay prompt as it appears in the STUDENT browse list. No rubric internals. */
export const essayPromptSummarySchema = z.object({
  id: z.string(),
  topicId: z.string(),
  title: z.string(),
  description: z.string(),
  difficultyLevel: essayDifficultySchema,
  minWords: z.number().int().nonnegative(),
  maxWords: z.number().int().nonnegative(),
  timeLimitMinutes: z.number().int().nonnegative(),
  /** Per-topic attempt cap and how many the student has already submitted. */
  maxAttempts: z.number().int().positive(),
  attemptsUsed: z.number().int().nonnegative(),
  lastAttempt: essayLastAttemptSchema.nullable(),
});
export type EssayPromptSummary = z.infer<typeof essayPromptSummarySchema>;

export const essayListResponseSchema = z.object({
  items: z.array(essayPromptSummarySchema),
});
export type EssayListResponse = z.infer<typeof essayListResponseSchema>;

/** STUDENT prompt detail — adds instructions; still NO reference keywords. */
export const essayPromptDetailSchema = essayPromptSummarySchema.extend({
  instructions: z.string(),
});
export type EssayPromptDetail = z.infer<typeof essayPromptDetailSchema>;

/**
 * ADMIN prompt projection — the ONLY place reference keywords are exposed. The
 * relevance analyzer measures coverage against these; leaking them to a student
 * would trivially game the score, so they never appear in the student schemas.
 */
export const essayPromptAdminSchema = essayPromptDetailSchema.extend({
  referenceKeywords: z.array(z.string()),
  isActive: z.boolean(),
});
export type EssayPromptAdmin = z.infer<typeof essayPromptAdminSchema>;

/**
 * Submit an essay for grading. Content is bounded here by a hard character
 * ceiling (abuse guard); the topic's min/max WORD limits are enforced in the
 * service, since they depend on the specific prompt.
 */
export const submitEssayRequestSchema = z.object({
  content: z
    .string()
    .min(1, "Essay cannot be empty")
    .max(ESSAY_MAX_CONTENT_CHARS, "Essay is too long"),
});
export type SubmitEssayRequest = z.infer<typeof submitEssayRequestSchema>;

/**
 * Grading status/result for one submission (poll GET .../submissions/:jobId).
 * `gradingPending` is true until the worker finalizes; scores/source/feedback
 * are null until then. When complete, `source` distinguishes an AI-blended
 * result from a deterministic-only fallback.
 */
export const essayGradingResultSchema = z.object({
  jobId: z.string(),
  submissionId: z.string(),
  status: essayGradingStatusSchema,
  gradingPending: z.boolean(),
  total: z.number().nullable(),
  dimensions: essayDimensionScoresSchema.nullable(),
  source: essayScoreSourceSchema.nullable(),
  feedback: z.string().nullable(),
  wordCount: z.number().int().nonnegative(),
  error: z.string().nullable(),
});
export type EssayGradingResult = z.infer<typeof essayGradingResultSchema>;

/** One row of a student's submission history for a prompt. */
export const essaySubmissionSummarySchema = z.object({
  id: z.string(),
  jobId: z.string().nullable(),
  attemptNumber: z.number().int().positive(),
  status: essayGradingStatusSchema,
  finalScore: z.number().nullable(),
  source: essayScoreSourceSchema.nullable(),
  wordCount: z.number().int().nonnegative(),
  submittedAt: z.string().datetime().nullable(),
  gradedAt: z.string().datetime().nullable(),
});
export type EssaySubmissionSummary = z.infer<
  typeof essaySubmissionSummarySchema
>;

export const essaySubmissionListResponseSchema = z.object({
  promptId: z.string(),
  items: z.array(essaySubmissionSummarySchema),
});
export type EssaySubmissionListResponse = z.infer<
  typeof essaySubmissionListResponseSchema
>;

/**
 * Optional, ADDITIVE writing-analytics payload (Step 11). Posted to the
 * separate, non-grading endpoint `POST /essays/submissions/:jobId/analytics`.
 * It records cheap compose signals (counts + timings, never keylogged content)
 * and has ZERO effect on the grade — the grade is written by the worker and is
 * identical whether or not analytics are ever sent.
 */
export const essayAnalyticsRequestSchema = z.object({
  keystrokes: z.number().int().nonnegative().max(1_000_000),
  deletes: z.number().int().nonnegative().max(1_000_000),
  pasteCount: z.number().int().nonnegative().max(100_000),
  pastedChars: z.number().int().nonnegative().max(10_000_000),
  composeSeconds: z.number().int().nonnegative().max(1_000_000),
  wordCount: z.number().int().nonnegative().max(1_000_000),
  characterCount: z.number().int().nonnegative().max(10_000_000),
});
export type EssayAnalyticsInput = z.infer<typeof essayAnalyticsRequestSchema>;

/**
 * Autosave a draft snapshot of an in-progress essay (PUT /essays/:id/draft).
 * Content is bounded by the same hard character ceiling as a submission; the
 * server recomputes the word count and NEVER trusts a client-sent one. This is
 * a pure snapshot: it does not submit, grade, or consume an attempt.
 */
export const saveEssayDraftRequestSchema = z.object({
  content: z.string().max(ESSAY_MAX_CONTENT_CHARS, "Essay is too long"),
});
export type SaveEssayDraftRequest = z.infer<typeof saveEssayDraftRequestSchema>;

/** Acknowledgement of a saved draft snapshot. */
export const saveEssayDraftResponseSchema = z.object({
  savedAt: z.string().datetime(),
  wordCount: z.number().int().nonnegative(),
});
export type SaveEssayDraftResponse = z.infer<
  typeof saveEssayDraftResponseSchema
>;

/** A recoverable draft snapshot as returned by GET /essays/:id/draft. */
export const essayDraftDtoSchema = z.object({
  content: z.string(),
  wordCount: z.number().int().nonnegative(),
  savedAt: z.string().datetime(),
});
export type EssayDraftDto = z.infer<typeof essayDraftDtoSchema>;

/**
 * Latest recoverable draft for a prompt, or null when there is nothing to
 * restore (no draft, or the student already submitted after the last draft).
 */
export const essayDraftResponseSchema = z.object({
  draft: essayDraftDtoSchema.nullable(),
});
export type EssayDraftResponse = z.infer<typeof essayDraftResponseSchema>;

// ---------------------------------------------------------------------------
// Payments / coupons (PhonePe order lifecycle)
//
// All amounts are INTEGER PAISE; the UI formats with formatINR. The client
// never sends an amount — the server always re-resolves price + coupon.
// ---------------------------------------------------------------------------

export const paymentStatusSchema = z.enum(
  PAYMENT_STATUS_VALUES as [PaymentStatus, ...PaymentStatus[]],
);
export const couponRejectReasonSchema = z.enum(
  COUPON_REJECT_REASON_VALUES as [CouponRejectReason, ...CouponRejectReason[]],
);

// ---------------------------------------------------------------------------
// Order admin read (ledger read — CRUD batch 3a). READ-ONLY: no admin mutation.
// Gateway-owned fields (transactionId + gateway status) are surfaced in a
// dedicated `gateway` block and never presented as editable.
// ---------------------------------------------------------------------------

export const adminOrderListQuerySchema = z.object({
  /** Filter by lifecycle status. */
  status: paymentStatusSchema.optional(),
  /** Free-text search over orderId / transactionId / couponCode. */
  q: z.string().trim().optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce
    .number()
    .int()
    .min(1)
    .max(ADMIN_ORDERS_MAX_PAGE_SIZE)
    .default(ADMIN_ORDERS_DEFAULT_PAGE_SIZE),
});
export type AdminOrderListQuery = z.infer<typeof adminOrderListQuerySchema>;

/** One row in the order admin list. Amounts are integer PAISE. */
export const adminOrderListItemSchema = z.object({
  id: z.string(),
  orderId: z.string(),
  status: paymentStatusSchema,
  amount: z.number().int().nonnegative(),
  student: z.string(),
  subject: z.string(),
  couponCode: z.string().nullable(),
  // Nullable: migrated/imported orders can lack a stored timestamp.
  createdAt: z.string().nullable(),
});
export type AdminOrderListItem = z.infer<typeof adminOrderListItemSchema>;

export const adminOrderListResponseSchema = z.object({
  items: z.array(adminOrderListItemSchema),
  total: z.number().int().nonnegative(),
  page: z.number().int().min(1),
  pageSize: z.number().int().min(1),
});
export type AdminOrderListResponse = z.infer<
  typeof adminOrderListResponseSchema
>;

// ---------------------------------------------------------------------------
// Image uploads (Cloudinary signed uploads). The API computes a short-lived
// signature from the server-only api_secret; the browser uploads directly to
// Cloudinary with it. This response carries the PUBLIC values only (cloud name
// + api_key are public) plus the computed signature — NEVER the api_secret.
// ---------------------------------------------------------------------------

export const uploadSignatureResponseSchema = z.object({
  cloudName: z.string(),
  /** Public Cloudinary API key (safe to expose; the secret is not). */
  apiKey: z.string(),
  /** Unix seconds; part of the signed payload and short-lived. */
  timestamp: z.number().int(),
  /** Server-controlled folder the upload is pinned to. */
  folder: z.string(),
  /** SHA-1 signature over the signed params, computed with the api_secret. */
  signature: z.string(),
});
export type UploadSignatureResponse = z.infer<
  typeof uploadSignatureResponseSchema
>;

/** Full order detail. Amounts are integer PAISE. */
export const adminOrderDetailSchema = z.object({
  id: z.string(),
  orderId: z.string(),
  status: paymentStatusSchema,
  amount: z.number().int().nonnegative(),
  discountAmount: z.number().int().nonnegative(),
  couponCode: z.string().nullable(),
  student: z.string(),
  studentEmail: z.string(),
  subject: z.string(),
  // Nullable: migrated/imported orders can lack stored timestamps.
  createdAt: z.string().nullable(),
  updatedAt: z.string().nullable(),
  /**
   * Gateway-owned (PhonePe) fields. Set by the verified payment callback /
   * webhook, NEVER edited from the admin — surfaced read-only for support.
   */
  gateway: z.object({
    transactionId: z.string().nullable(),
    status: paymentStatusSchema,
  }),
});
export type AdminOrderDetail = z.infer<typeof adminOrderDetailSchema>;
export const couponDiscountTypeSchema = z.enum(
  COUPON_DISCOUNT_TYPE_VALUES as [
    CouponDiscountTypeT,
    ...CouponDiscountTypeT[],
  ],
);

// ---------------------------------------------------------------------------
// Coupon admin authoring — CRUD over the Coupon model used by checkout.
//
// discountValue is discriminated on discountType: an integer PERCENT (1–100)
// for "percentage", or integer PAISE for "fixed" (money stays paise). Scope is
// nullable (global vs one subject). Validity window + usage caps mirror the
// redemption path (applyCoupon + resolvePricing).
// ---------------------------------------------------------------------------

// Fields shared by both discount types.
const couponCommon = {
  code: z
    .string()
    .trim()
    .min(1)
    .max(64)
    .regex(
      /^[A-Za-z0-9._-]+$/,
      "Code may contain only letters, numbers, and . _ -",
    ),
  active: z.boolean().default(true),
  /** ISO datetimes; null/omitted = open-ended on that side. */
  validFrom: z.string().datetime().nullable().optional(),
  validTo: z.string().datetime().nullable().optional(),
  /** Global redemption cap; null = unlimited. */
  usageLimit: z.number().int().positive().nullable().optional(),
  perUserLimit: z.number().int().positive().default(1),
  minOrderPaise: z.number().int().nonnegative().default(0),
  /** Scope: null/omitted = global; else the subject it applies to. */
  subjectId: z.string().min(1).nullable().optional(),
};

export const adminCouponUpsertSchema = z.discriminatedUnion("discountType", [
  z.object({
    discountType: z.literal(CouponDiscountType.PERCENTAGE),
    /** Percent off, 1–100. */
    discountValue: z.number().int().min(1).max(100),
    ...couponCommon,
  }),
  z.object({
    discountType: z.literal(CouponDiscountType.FIXED),
    /** Flat amount off, in paise (>= 1). */
    discountValue: z.number().int().min(1),
    ...couponCommon,
  }),
]);
export type AdminCouponUpsert = z.infer<typeof adminCouponUpsertSchema>;

export const adminCouponSchema = z.object({
  id: z.string(),
  code: z.string(),
  discountType: couponDiscountTypeSchema,
  discountValue: z.number().int().nonnegative(),
  active: z.boolean(),
  validFrom: z.string().datetime().nullable(),
  validTo: z.string().datetime().nullable(),
  usageLimit: z.number().int().positive().nullable(),
  perUserLimit: z.number().int().positive(),
  minOrderPaise: z.number().int().nonnegative(),
  /** Successful redemptions counted so far. */
  usedCount: z.number().int().nonnegative(),
  /** Orders referencing this coupon (any status) — drives delete-block. */
  orderCount: z.number().int().nonnegative(),
  subjectId: z.string().nullable(),
  subjectName: z.string().nullable(),
});
export type AdminCoupon = z.infer<typeof adminCouponSchema>;
export const adminCouponListResponseSchema = z.object({
  items: z.array(adminCouponSchema),
});
export type AdminCouponListResponse = z.infer<
  typeof adminCouponListResponseSchema
>;

/** Price preview / coupon check (POST /payments/quote) — no side effects. */
export const quoteRequestSchema = z.object({
  subjectId: z.string().min(1),
  couponCode: z.string().trim().min(1).max(64).optional(),
});
export type QuoteRequest = z.infer<typeof quoteRequestSchema>;

export const quoteResponseSchema = z.object({
  subjectId: z.string(),
  subjectSlug: z.string(),
  subjectName: z.string(),
  basePricePaise: z.number().int().nonnegative(),
  discountPaise: z.number().int().nonnegative(),
  finalPaise: z.number().int().nonnegative(),
  /** True when a coupon code was supplied AND accepted. */
  couponApplied: z.boolean(),
  /** Echoed (normalized) coupon code when applied. */
  couponCode: z.string().nullable(),
  /** Rejection reason when a supplied coupon could not be applied. */
  reason: couponRejectReasonSchema.nullable(),
  /** The subject is free (nothing to pay). */
  isFree: z.boolean(),
  /** The caller already owns this subject. */
  alreadyEnrolled: z.boolean(),
});
export type QuoteResponse = z.infer<typeof quoteResponseSchema>;

/** Create an order (POST /payments/orders). */
export const createOrderRequestSchema = z.object({
  subjectId: z.string().min(1),
  couponCode: z.string().trim().min(1).max(64).optional(),
});
export type CreateOrderRequest = z.infer<typeof createOrderRequestSchema>;

/** The gateway redirect the client follows to complete payment. */
export const createOrderResponseSchema = z.object({
  orderId: z.string(),
  /** Hosted-checkout URL the client redirects to (gateway or mock-pay). */
  redirectUrl: z.string(),
  amountPaise: z.number().int().nonnegative(),
  discountPaise: z.number().int().nonnegative(),
  couponCode: z.string().nullable(),
});
export type CreateOrderResponse = z.infer<typeof createOrderResponseSchema>;

/** Order status (GET /payments/orders/:orderId) — poll target after return. */
export const orderStatusResponseSchema = z.object({
  orderId: z.string(),
  status: paymentStatusSchema,
  amountPaise: z.number().int().nonnegative(),
  discountPaise: z.number().int().nonnegative(),
  couponCode: z.string().nullable(),
  transactionId: z.string().nullable(),
  subject: z.object({
    id: z.string(),
    slug: z.string(),
    name: z.string(),
  }),
  /** Whether enrollment has been granted (true only after verified success). */
  enrolled: z.boolean(),
  createdAt: z.string().datetime(),
});
export type OrderStatusResponse = z.infer<typeof orderStatusResponseSchema>;

/** One row of the caller's order history. */
export const orderSummarySchema = z.object({
  orderId: z.string(),
  status: paymentStatusSchema,
  amountPaise: z.number().int().nonnegative(),
  discountPaise: z.number().int().nonnegative(),
  couponCode: z.string().nullable(),
  subjectSlug: z.string(),
  subjectName: z.string(),
  createdAt: z.string().datetime(),
});
export type OrderSummary = z.infer<typeof orderSummarySchema>;

export const orderListResponseSchema = z.object({
  items: z.array(orderSummarySchema),
});
export type OrderListResponse = z.infer<typeof orderListResponseSchema>;

/**
 * Mock-only affordance (POST /payments/mock/pay) used by tests + Part 2 to
 * drive a verified success/failure callback without a real gateway. Rejected
 * unless PAYMENT_GATEWAY=mock.
 */
export const mockPayRequestSchema = z.object({
  orderId: z.string().min(1),
  outcome: z.enum(["success", "failure"]),
});
export type MockPayRequest = z.infer<typeof mockPayRequestSchema>;

// ---------------------------------------------------------------------------
// Careers / placements (job postings + student applications)
//
// The source (Django `Job` + `JobApplication`) confirmed an application flow
// but specified no fields/statuses/eligibility. These schemas reuse the Step-1
// field set + the 5-state status enum; admin-only applicant contact never
// appears in a student projection.
// ---------------------------------------------------------------------------

export const postingTypeSchema = z.enum(
  POSTING_TYPE_VALUES as [PostingType, ...PostingType[]],
);
export const applicationStatusSchema = z.enum(
  JOB_APPLICATION_STATUS_VALUES as [
    JobApplicationStatus,
    ...JobApplicationStatus[],
  ],
);

/** A posting as the STUDENT sees it in the list (no internal fields). */
export const postingSummarySchema = z.object({
  id: z.string(),
  title: z.string(),
  company: z.string(),
  companyLogo: z.string(),
  location: z.string(),
  type: postingTypeSchema,
  /** Free-text compensation (e.g. "₹12 LPA", "₹25k/month"). */
  compensation: z.string(),
  /** ISO deadline, or null when the posting never closes. */
  deadline: z.string().datetime().nullable(),
  /** Server-computed: active AND not past deadline. */
  isOpen: z.boolean(),
  postedAt: z.string().datetime(),
});
export type PostingSummary = z.infer<typeof postingSummarySchema>;

/** Compact record of the caller's own application to a posting. */
export const myApplicationRefSchema = z.object({
  id: z.string(),
  status: applicationStatusSchema,
  appliedAt: z.string().datetime(),
});
export type MyApplicationRef = z.infer<typeof myApplicationRefSchema>;

/** STUDENT posting detail — adds description/requirements + the caller's own application. */
export const postingDetailSchema = postingSummarySchema.extend({
  description: z.string(),
  requirements: z.string(),
  /**
   * External application URL, or "" for in-app apply. Exposed on the student
   * detail (a public company link, not sensitive) so the UI can branch the
   * primary action between "Apply on company site" and the in-app form. Added
   * in Part 2 — a minimal, additive extension to the Part-1 read projection.
   */
  applyUrl: z.string(),
  myApplication: myApplicationRefSchema.nullable(),
});
export type PostingDetail = z.infer<typeof postingDetailSchema>;

export const postingListQuerySchema = z.object({
  page: z.coerce.number().int().positive().default(1),
  pageSize: z.coerce
    .number()
    .int()
    .positive()
    .max(CAREERS_MAX_PAGE_SIZE)
    .default(CAREERS_DEFAULT_PAGE_SIZE),
  type: postingTypeSchema.optional(),
  q: z.string().trim().max(100).optional(),
  /** Include postings that are closed / past deadline (default false). */
  includeClosed: z.enum(["true", "false"]).optional(),
});
export type PostingListQuery = z.infer<typeof postingListQuerySchema>;

export const postingListResponseSchema = z.object({
  items: z.array(postingSummarySchema),
  page: z.number().int().positive(),
  pageSize: z.number().int().positive(),
  total: z.number().int().nonnegative(),
  totalPages: z.number().int().nonnegative(),
});
export type PostingListResponse = z.infer<typeof postingListResponseSchema>;

/** Apply to a posting (POST /careers/:id/apply). Applicant snapshot. */
export const applyRequestSchema = z.object({
  fullName: z.string().trim().min(1).max(150),
  email: z.string().email().toLowerCase(),
  phone: z.string().trim().max(20).optional(),
  resumeUrl: z.string().url().max(500).optional().or(z.literal("")),
  coverLetter: z.string().trim().max(5000).optional(),
});
export type ApplyRequest = z.infer<typeof applyRequestSchema>;

export const applicationResponseSchema = z.object({
  id: z.string(),
  postingId: z.string(),
  status: applicationStatusSchema,
  appliedAt: z.string().datetime(),
});
export type ApplicationResponse = z.infer<typeof applicationResponseSchema>;

/** One row of the student's "my applications" list. */
export const myApplicationSchema = z.object({
  id: z.string(),
  status: applicationStatusSchema,
  appliedAt: z.string().datetime(),
  posting: postingSummarySchema,
});
export type MyApplication = z.infer<typeof myApplicationSchema>;

export const myApplicationsResponseSchema = z.object({
  items: z.array(myApplicationSchema),
});
export type MyApplicationsResponse = z.infer<
  typeof myApplicationsResponseSchema
>;

// --- Admin projections ---

/** Create/update a posting (admin). `deadline` null clears it. */
export const adminPostingUpsertSchema = z.object({
  title: z.string().trim().min(1).max(200),
  company: z.string().trim().min(1).max(150),
  companyLogo: z.string().url().max(500).optional().or(z.literal("")),
  location: z.string().trim().max(150).optional(),
  type: postingTypeSchema,
  compensation: z.string().trim().max(100).optional(),
  description: z.string().max(10_000).optional(),
  requirements: z.string().max(10_000).optional(),
  applyUrl: z.string().url().max(500).optional().or(z.literal("")),
  deadline: z.string().datetime().nullable().optional(),
  isActive: z.boolean().optional(),
});
export type AdminPostingUpsert = z.infer<typeof adminPostingUpsertSchema>;

/** Admin posting projection — includes internal flags + application count. */
export const adminPostingSchema = postingSummarySchema.extend({
  description: z.string(),
  requirements: z.string(),
  applyUrl: z.string(),
  isActive: z.boolean(),
  applicationCount: z.number().int().nonnegative(),
});
export type AdminPosting = z.infer<typeof adminPostingSchema>;

export const adminPostingListResponseSchema = z.object({
  items: z.array(adminPostingSchema),
});
export type AdminPostingListResponse = z.infer<
  typeof adminPostingListResponseSchema
>;

/** An application row as the ADMIN sees it — full applicant contact. */
export const adminApplicationRowSchema = z.object({
  id: z.string(),
  status: applicationStatusSchema,
  appliedAt: z.string().datetime(),
  userId: z.string().nullable(),
  fullName: z.string(),
  email: z.string(),
  phone: z.string(),
  resumeUrl: z.string(),
  coverLetter: z.string(),
});
export type AdminApplicationRow = z.infer<typeof adminApplicationRowSchema>;

export const adminApplicationListResponseSchema = z.object({
  postingId: z.string(),
  postingTitle: z.string(),
  items: z.array(adminApplicationRowSchema),
});
export type AdminApplicationListResponse = z.infer<
  typeof adminApplicationListResponseSchema
>;

export const updateApplicationStatusRequestSchema = z.object({
  status: applicationStatusSchema,
});
export type UpdateApplicationStatusRequest = z.infer<
  typeof updateApplicationStatusRequestSchema
>;
