/**
 * System-wide constants shared by api, worker, and web.
 */
import { CodeLanguage } from "./enums.js";

// ---------------------------------------------------------------------------
// BullMQ queues — mirror the original django-rq setup.
// ---------------------------------------------------------------------------

export const QueueName = {
  DEFAULT: "default",
  PRACTICE: "practice",
  ASSESSMENT: "assessment",
  PLAYGROUND: "playground",
} as const;
export type QueueName = (typeof QueueName)[keyof typeof QueueName];
export const QUEUE_NAME_VALUES = Object.values(QueueName);

/**
 * Per-queue configuration. `timeoutSeconds` mirrors the django-rq job timeouts;
 * `priority` marks the assessment queue as the high-priority one (grading a
 * live, timed exam must not sit behind practice runs).
 */
export interface QueueConfig {
  readonly name: QueueName;
  readonly timeoutSeconds: number;
  readonly priority: boolean;
}

export const QUEUE_CONFIGS: Record<QueueName, QueueConfig> = {
  [QueueName.DEFAULT]: {
    name: QueueName.DEFAULT,
    timeoutSeconds: 300,
    priority: false,
  },
  [QueueName.PRACTICE]: {
    name: QueueName.PRACTICE,
    timeoutSeconds: 300,
    priority: false,
  },
  [QueueName.ASSESSMENT]: {
    name: QueueName.ASSESSMENT,
    timeoutSeconds: 600,
    priority: true,
  },
  [QueueName.PLAYGROUND]: {
    name: QueueName.PLAYGROUND,
    timeoutSeconds: 300,
    priority: false,
  },
};

// ---------------------------------------------------------------------------
// Code execution — Piston language mapping + limits.
// ---------------------------------------------------------------------------

/**
 * Why a submission runs, which decides the queue it lands on. Mirrors the
 * original django-rq split: playground/practice runs are best-effort, while
 * `assessment` (live, timed exams) gets the high-priority queue. Exams reserve
 * `assessment`; the playground uses `playground`.
 */
export const ExecutionPurpose = {
  PLAYGROUND: "playground",
  PRACTICE: "practice",
  ASSESSMENT: "assessment",
} as const;
export type ExecutionPurpose =
  (typeof ExecutionPurpose)[keyof typeof ExecutionPurpose];
export const EXECUTION_PURPOSE_VALUES = Object.values(ExecutionPurpose);

/** Each execution purpose maps 1:1 to the queue that carries it. */
export const PURPOSE_QUEUE: Record<ExecutionPurpose, QueueName> = {
  [ExecutionPurpose.PLAYGROUND]: QueueName.PLAYGROUND,
  [ExecutionPurpose.PRACTICE]: QueueName.PRACTICE,
  [ExecutionPurpose.ASSESSMENT]: QueueName.ASSESSMENT,
};

/**
 * Language → Piston runtime + version. Mirrors the original executor's mapping
 * (Python / JavaScript / Java / C++ / C). Versions match the public Piston
 * (emkc) runtimes; a self-hosted Piston should install the same set. The worker
 * resolves a `CodeLanguage` to this pair before calling Piston.
 */
export interface PistonRuntime {
  /** Piston's language key (note: C++ is `c++`, not our `cpp` enum value). */
  readonly language: string;
  readonly version: string;
}
export const PISTON_RUNTIMES: Record<CodeLanguage, PistonRuntime> = {
  [CodeLanguage.PYTHON]: { language: "python", version: "3.10.0" },
  [CodeLanguage.JAVASCRIPT]: { language: "javascript", version: "18.15.0" },
  [CodeLanguage.JAVA]: { language: "java", version: "15.0.2" },
  [CodeLanguage.CPP]: { language: "c++", version: "10.2.0" },
  [CodeLanguage.C]: { language: "c", version: "10.2.0" },
};

/** Human-facing language names for selectors. */
export const CODE_LANGUAGE_LABELS: Record<CodeLanguage, string> = {
  [CodeLanguage.PYTHON]: "Python",
  [CodeLanguage.JAVASCRIPT]: "JavaScript",
  [CodeLanguage.JAVA]: "Java",
  [CodeLanguage.CPP]: "C++",
  [CodeLanguage.C]: "C",
};

/**
 * The source filename Piston should use per language. Java in particular needs
 * a `.java` extension (and its public class is conventionally `Main`).
 */
export const PISTON_SOURCE_FILENAME: Record<CodeLanguage, string> = {
  [CodeLanguage.PYTHON]: "main.py",
  [CodeLanguage.JAVASCRIPT]: "main.js",
  [CodeLanguage.JAVA]: "Main.java",
  [CodeLanguage.CPP]: "main.cpp",
  [CodeLanguage.C]: "main.c",
};

/** Safety limits for the submit endpoint (bytes / counts). */
export const MAX_SOURCE_BYTES = 64 * 1024; // 64 KB of source
export const MAX_STDIN_BYTES = 16 * 1024; // 16 KB of stdin
export const MAX_TEST_CASES = 50;

/** Execution submissions allowed per user inside the rate-limit window. */
export const EXECUTE_RATE_LIMIT_WINDOW_MS = 60 * 1000;
export const EXECUTE_RATE_LIMIT_MAX = 30;

/** Machine-readable codes for the execution surface (UI can switch on these). */
export const ExecutionErrorCode = {
  JOB_NOT_FOUND: "JOB_NOT_FOUND",
  /** The job exists but belongs to another user. */
  JOB_FORBIDDEN: "JOB_FORBIDDEN",
  /** Too many submissions in the rate-limit window. */
  RATE_LIMITED: "RATE_LIMITED",
} as const;
export type ExecutionErrorCode =
  (typeof ExecutionErrorCode)[keyof typeof ExecutionErrorCode];

// ---------------------------------------------------------------------------
// Essay scoring weights. Rebalanced from the original Django engine to weight
// mechanics (grammar+spelling+punctuation) at 22% (was 15%) — now that spelling
// is a real dictionary check — and trim vocabulary (0.30 → 0.22); structure and
// relevance unchanged in intent. Sum of weights MUST remain 1.00 (asserted in a
// test). Original: grammar .08, spelling .03, punctuation .04, readability .05,
// vocabulary .30, structure .25, relevance .25.
// ---------------------------------------------------------------------------

export const ESSAY_SCORE_WEIGHTS = {
  grammar: 0.12,
  spelling: 0.05,
  punctuation: 0.05,
  readability: 0.08,
  vocabulary: 0.22,
  structure: 0.23,
  relevance: 0.25,
} as const;
export type EssayScoreDimension = keyof typeof ESSAY_SCORE_WEIGHTS;

/** +5 bonus if vocabulary, structure, and relevance are ALL >= this threshold. */
export const ESSAY_BONUS_THRESHOLD = 80;
export const ESSAY_BONUS_POINTS = 5;

/**
 * Per-dimension LLM blend weights: a blended sub-score is
 * `deterministic * (1 - b) + llm * b` for the dimension's `b`. ONLY these three
 * "judgment" dimensions are AI-influenced — mechanics (grammar/spelling/
 * punctuation/readability) stay fully deterministic and are never in this map.
 * Relevance leans on the LLM (0.6) because keyword-matching is the weakest
 * deterministic signal. Tunable here.
 */
export const ESSAY_AI_BLEND = {
  vocabulary: 0.5,
  structure: 0.5,
  relevance: 0.6,
} as const;

/** Feature flags for the AI grading path (defaults match the original). */
export const ESSAY_AI_FLAGS = {
  ENABLE_AI_FEEDBACK: true,
  ENABLE_AI_VOCAB: false,
  ENABLE_AI_STRUCTURE: false,
} as const;

/** Submission length bounds enforced when a topic sets no explicit min/max. */
export const ESSAY_DEFAULT_MIN_WORDS = 1;
export const ESSAY_MAX_CONTENT_CHARS = 50_000; // hard ceiling (abuse guard)

/** Essay submissions allowed per user inside the rate-limit window. */
export const ESSAY_SUBMIT_RATE_LIMIT_WINDOW_MS = 60 * 1000;
export const ESSAY_SUBMIT_RATE_LIMIT_MAX = 10;

/** Machine-readable codes for the essay surface (UI switches on these). */
export const EssayErrorCode = {
  /** No active EssayTopic with that id in an enrolled subject. */
  ESSAY_NOT_FOUND: "ESSAY_NOT_FOUND",
  /** The submission/attempt does not exist. */
  SUBMISSION_NOT_FOUND: "SUBMISSION_NOT_FOUND",
  /** Caller is not the owner of the submission. */
  NOT_AUTHORIZED: "NOT_AUTHORIZED",
  /** Content shorter than the topic's minWords / longer than maxWords. */
  LENGTH_OUT_OF_RANGE: "LENGTH_OUT_OF_RANGE",
  /** Not enrolled in a subject that carries this essay topic. */
  NOT_ENROLLED: "NOT_ENROLLED",
  /** Too many submissions in the rate-limit window. */
  RATE_LIMITED: "RATE_LIMITED",
  /** The per-topic attempt cap (EssayTopic.maxAttempts) is exhausted. */
  ATTEMPT_LIMIT_REACHED: "ATTEMPT_LIMIT_REACHED",
} as const;
export type EssayErrorCode =
  (typeof EssayErrorCode)[keyof typeof EssayErrorCode];

/** Machine-readable codes for the essay-topic ADMIN surface. */
export const EssayTopicErrorCode = {
  ESSAY_TOPIC_NOT_FOUND: "ESSAY_TOPIC_NOT_FOUND",
  /**
   * Hard-delete refused because student attempts reference the prompt
   * (details.blockers). Same code the other admins use so the web blocker
   * dialog renders it; deactivation is the retire path.
   */
  DELETE_BLOCKED: "DELETE_BLOCKED",
} as const;
export type EssayTopicErrorCode =
  (typeof EssayTopicErrorCode)[keyof typeof EssayTopicErrorCode];

// ---------------------------------------------------------------------------
// Misc shared constants
// ---------------------------------------------------------------------------

/** IST offset — display concern only; all storage is UTC. */
export const IST_OFFSET_MINUTES = 330; // UTC+05:30

/** Assessments: malpractice flag raised when warnings exceed this count. */
export const EXAM_MAX_WARNINGS = 2;

/** Default score awarded for a correct daily/quiz MCQ. */
export const MCQ_CORRECT_MARKS = 5;

/** API route prefix. */
export const API_PREFIX = "/api";

// ---------------------------------------------------------------------------
// Machine-readable error codes for the auth surface.
// The UI switches on `error.code`; e.g. FORCE_PASSWORD_CHANGE => route to the
// change-password screen. All auth failures use INVALID_CREDENTIALS to avoid
// user enumeration.
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Curriculum / LMS
// ---------------------------------------------------------------------------

/** Machine-readable codes for the curriculum surface (UI switches on these). */
export const CurriculumErrorCode = {
  SUBJECT_NOT_FOUND: "SUBJECT_NOT_FOUND",
  TOPIC_NOT_FOUND: "TOPIC_NOT_FOUND",
  /** Content/quiz route hit without an enrollment. */
  NOT_ENROLLED: "NOT_ENROLLED",
  /** Enroll attempted on a paid subject (checkout arrives in the payments step). */
  PAYMENT_REQUIRED: "PAYMENT_REQUIRED",
  /** Topic is not a quiz topic. */
  NOT_A_QUIZ: "NOT_A_QUIZ",
  /** Program not found (admin authoring). */
  PROGRAM_NOT_FOUND: "PROGRAM_NOT_FOUND",
  /** Module not found (admin authoring). */
  MODULE_NOT_FOUND: "MODULE_NOT_FOUND",
  /** A slug (program/subject) is already in use. */
  SLUG_TAKEN: "SLUG_TAKEN",
  /** Destructive delete blocked by dependent data (details lists the blockers). */
  DELETE_BLOCKED: "DELETE_BLOCKED",
  /** Quiz question not found (admin authoring). */
  QUESTION_NOT_FOUND: "QUESTION_NOT_FOUND",
  /** A topic's type cannot be changed after creation (would strand its sub-tree). */
  TOPIC_TYPE_IMMUTABLE: "TOPIC_TYPE_IMMUTABLE",
} as const;
export type CurriculumErrorCode =
  (typeof CurriculumErrorCode)[keyof typeof CurriculumErrorCode];

// ---------------------------------------------------------------------------
// Payments / coupons
// ---------------------------------------------------------------------------

/** Machine-readable codes for the payments surface (UI switches on these). */
export const PaymentErrorCode = {
  /** Subject id was not found / not visible. */
  SUBJECT_NOT_FOUND: "SUBJECT_NOT_FOUND",
  /** Subject is free — nothing to pay for. */
  SUBJECT_FREE: "SUBJECT_FREE",
  /** The user already owns (is enrolled in) this subject. */
  ALREADY_ENROLLED: "ALREADY_ENROLLED",
  /** Order id not found. */
  ORDER_NOT_FOUND: "ORDER_NOT_FOUND",
  /** Caller does not own this order. */
  NOT_AUTHORIZED: "NOT_AUTHORIZED",
  /** The coupon code could not be applied (see the coupon reason). */
  COUPON_REJECTED: "COUPON_REJECTED",
  /** The payment gateway call failed. */
  GATEWAY_ERROR: "GATEWAY_ERROR",
  /** Callback signature did not verify. */
  INVALID_SIGNATURE: "INVALID_SIGNATURE",
  /** Too many order-creation attempts in the window. */
  RATE_LIMITED: "RATE_LIMITED",
  /** A mock-only affordance was hit while the real gateway is selected. */
  MOCK_DISABLED: "MOCK_DISABLED",
} as const;
export type PaymentErrorCode =
  (typeof PaymentErrorCode)[keyof typeof PaymentErrorCode];

/** Machine-readable codes for the coupon ADMIN surface (UI switches on these). */
export const CouponErrorCode = {
  COUPON_NOT_FOUND: "COUPON_NOT_FOUND",
  /** Another coupon already uses this code. */
  CODE_TAKEN: "CODE_TAKEN",
  /** Scope subject id not found. */
  SUBJECT_NOT_FOUND: "SUBJECT_NOT_FOUND",
  /**
   * Hard-delete refused because orders reference the coupon (details.blockers).
   * Same code the curriculum admin uses so the web blocker dialog renders it.
   */
  DELETE_BLOCKED: "DELETE_BLOCKED",
} as const;
export type CouponErrorCode =
  (typeof CouponErrorCode)[keyof typeof CouponErrorCode];

/**
 * Structured reasons a coupon is rejected. The pure engine returns the
 * window/threshold/active reasons; the service adds the DB-backed usage ones.
 */
export const CouponRejectReason = {
  NOT_FOUND: "not-found",
  INACTIVE: "inactive",
  NOT_YET_VALID: "not-yet-valid",
  EXPIRED: "expired",
  MIN_ORDER_NOT_MET: "min-order-not-met",
  SUBJECT_MISMATCH: "subject-mismatch",
  USAGE_EXHAUSTED: "usage-exhausted",
  PER_USER_LIMIT: "per-user-limit",
} as const;
export type CouponRejectReason =
  (typeof CouponRejectReason)[keyof typeof CouponRejectReason];
export const COUPON_REJECT_REASON_VALUES = Object.values(CouponRejectReason);

/** Order-creation attempts allowed per user inside the rate-limit window. */
export const PAYMENT_ORDER_RATE_LIMIT_WINDOW_MS = 60 * 1000;
export const PAYMENT_ORDER_RATE_LIMIT_MAX = 10;

/** Outcome of a (free-path) enroll request. */
export const EnrollResult = {
  ENROLLED: "ENROLLED",
  ALREADY_ENROLLED: "ALREADY_ENROLLED",
} as const;
export type EnrollResult = (typeof EnrollResult)[keyof typeof EnrollResult];

/** How an enrollment was created. */
export const EnrollmentSource = {
  ORDER: "order",
  MANUAL: "manual",
} as const;
export type EnrollmentSource =
  (typeof EnrollmentSource)[keyof typeof EnrollmentSource];
export const ENROLLMENT_SOURCE_VALUES = Object.values(EnrollmentSource);

// ---------------------------------------------------------------------------
// Assessments / mock exams
// ---------------------------------------------------------------------------

/** Machine-readable codes for the assessment surface. */
export const ExamErrorCode = {
  EXAM_NOT_FOUND: "EXAM_NOT_FOUND",
  ATTEMPT_NOT_FOUND: "ATTEMPT_NOT_FOUND",
  /** Per-user attempt limit hit (ExamAttemptCounter). */
  ATTEMPT_LIMIT_REACHED: "ATTEMPT_LIMIT_REACHED",
  /** The current section's server clock has run out. */
  SECTION_EXPIRED: "SECTION_EXPIRED",
  /** Attempt is already submitted/graded — no more section edits. */
  ALREADY_SUBMITTED: "ALREADY_SUBMITTED",
  /** Public link inactive or outside its start/end window. */
  LINK_UNAVAILABLE: "LINK_UNAVAILABLE",
  /** Caller is neither the attempt's owner nor holds its attempt token. */
  NOT_AUTHORIZED: "NOT_AUTHORIZED",
  /** No next section to advance into. */
  NO_NEXT_SECTION: "NO_NEXT_SECTION",
  /** Grading not finished yet (code jobs still running). */
  GRADING_PENDING: "GRADING_PENDING",
  /**
   * Hard-delete refused because student attempts reference the exam
   * (details.blockers). Same code the other admins use so the web blocker
   * dialog renders it; delete a future/unattempted exam instead.
   */
  DELETE_BLOCKED: "DELETE_BLOCKED",
} as const;
export type ExamErrorCode = (typeof ExamErrorCode)[keyof typeof ExamErrorCode];

/** Anonymous public-exam starts allowed per IP inside the window. */
export const PUBLIC_EXAM_RATE_LIMIT_WINDOW_MS = 60 * 1000;
export const PUBLIC_EXAM_RATE_LIMIT_MAX = 10;

// ---------------------------------------------------------------------------
// Daily challenges
// ---------------------------------------------------------------------------

/** Machine-readable codes for the daily-challenge surface. */
export const ChallengeErrorCode = {
  /** No DailyQuestion released for the current IST day. */
  NO_CHALLENGE_TODAY: "NO_CHALLENGE_TODAY",
  /** A scoring submission already exists for today (one per user per day). */
  ALREADY_ATTEMPTED: "ALREADY_ATTEMPTED",
  /** submit-mcq called on a CODE question (or vice versa). */
  WRONG_QUESTION_TYPE: "WRONG_QUESTION_TYPE",
  /** The execution job does not belong to this user / today's question. */
  JOB_NOT_FOUND: "JOB_NOT_FOUND",
  /** Admin: no DailyQuestion with the given id. */
  QUESTION_NOT_FOUND: "QUESTION_NOT_FOUND",
  /** Admin: another challenge is already scheduled on that release date. */
  DATE_TAKEN: "DATE_TAKEN",
  /**
   * Admin: hard-delete refused because scored submissions reference the
   * question (details.blockers). Same code the other admins use so the web
   * blocker dialog renders it. Challenges have no active flag — reschedule
   * (edit the date) or delete a future one before anyone attempts it.
   */
  DELETE_BLOCKED: "DELETE_BLOCKED",
} as const;
export type ChallengeErrorCode =
  (typeof ChallengeErrorCode)[keyof typeof ChallengeErrorCode];

/** User admin (read/reporting + CONFIG mutations). */
export const UserAdminErrorCode = {
  /** No user with the given id. */
  USER_NOT_FOUND: "USER_NOT_FOUND",
  /** Admin tried to deactivate/demote their own account. */
  SELF_ACTION_FORBIDDEN: "SELF_ACTION_FORBIDDEN",
  /** Action would leave the system with no active admin. */
  LAST_ADMIN: "LAST_ADMIN",
  /** Another profile already uses this roll number. */
  ROLL_TAKEN: "ROLL_TAKEN",
  /** No enrollment of this user in the given subject. */
  ENROLLMENT_NOT_FOUND: "ENROLLMENT_NOT_FOUND",
} as const;
export type UserAdminErrorCode =
  (typeof UserAdminErrorCode)[keyof typeof UserAdminErrorCode];

/** Leaderboard pagination (fixes the original's hard 20 cap). */
export const LEADERBOARD_DEFAULT_PAGE_SIZE = 20;
export const LEADERBOARD_MAX_PAGE_SIZE = 100;

// ---------------------------------------------------------------------------
// Careers / placements
// ---------------------------------------------------------------------------

/** Machine-readable codes for the careers surface (UI switches on these). */
export const CareerErrorCode = {
  POSTING_NOT_FOUND: "POSTING_NOT_FOUND",
  /** Posting is unpublished/inactive. */
  POSTING_CLOSED: "POSTING_CLOSED",
  /** The application deadline has passed. */
  DEADLINE_PASSED: "DEADLINE_PASSED",
  /** The caller already applied to this posting. */
  ALREADY_APPLIED: "ALREADY_APPLIED",
  /**
   * Reserved: the source has NO eligibility rules (CGPA/branch/batch), so this
   * is never currently emitted. Kept for forward-compat if rules are added.
   */
  NOT_ELIGIBLE: "NOT_ELIGIBLE",
  /** Application id not found. */
  APPLICATION_NOT_FOUND: "APPLICATION_NOT_FOUND",
  /** Caller does not own this application. */
  NOT_AUTHORIZED: "NOT_AUTHORIZED",
  /** Status not in the allowed set. */
  INVALID_STATUS: "INVALID_STATUS",
  /**
   * Hard-delete refused because applications reference the posting
   * (details.blockers). Close the posting instead to retire it without
   * destroying application history.
   */
  DELETE_BLOCKED: "DELETE_BLOCKED",
} as const;
export type CareerErrorCode =
  (typeof CareerErrorCode)[keyof typeof CareerErrorCode];

/** Careers listing pagination. */
export const CAREERS_DEFAULT_PAGE_SIZE = 12;
export const CAREERS_MAX_PAGE_SIZE = 50;

// ---------------------------------------------------------------------------
// Orders (ledger read — CRUD batch 3a)
// ---------------------------------------------------------------------------

/** Machine-readable codes for the order admin read surface. */
export const OrderErrorCode = {
  /** No order with the given id. */
  ORDER_NOT_FOUND: "ORDER_NOT_FOUND",
} as const;
export type OrderErrorCode =
  (typeof OrderErrorCode)[keyof typeof OrderErrorCode];

/** Order admin list pagination. */
export const ADMIN_ORDERS_DEFAULT_PAGE_SIZE = 20;
export const ADMIN_ORDERS_MAX_PAGE_SIZE = 100;

// ---------------------------------------------------------------------------
// Image uploads (Cloudinary signed uploads)
// ---------------------------------------------------------------------------

/** Machine-readable codes for the signed-upload surface. */
export const UploadErrorCode = {
  /**
   * Cloudinary env vars are not set on the server. Surfaced (503) so the UI can
   * tell the admin to configure them / fall back to pasting a URL — the secret
   * is never involved.
   */
  UPLOAD_NOT_CONFIGURED: "UPLOAD_NOT_CONFIGURED",
} as const;
export type UploadErrorCode =
  (typeof UploadErrorCode)[keyof typeof UploadErrorCode];

/** Cloudinary folder all app uploads are signed into (server-controlled). */
export const CLOUDINARY_UPLOAD_FOLDER = "codeapt";

export const AuthErrorCode = {
  /** No/invalid credentials presented where auth is required. */
  UNAUTHENTICATED: "UNAUTHENTICATED",
  /** Login failed — deliberately generic (email/username existence hidden). */
  INVALID_CREDENTIALS: "INVALID_CREDENTIALS",
  /** Access/refresh token is expired. */
  TOKEN_EXPIRED: "TOKEN_EXPIRED",
  /** Token signature/shape is invalid. */
  TOKEN_INVALID: "TOKEN_INVALID",
  /** Token's tokenVersion is stale (all sessions revoked). */
  TOKEN_REVOKED: "TOKEN_REVOKED",
  /** A rotated/old refresh token was replayed — session killed. */
  TOKEN_REUSE_DETECTED: "TOKEN_REUSE_DETECTED",
  /** Refresh session was logged out or expired. */
  SESSION_REVOKED: "SESSION_REVOKED",
  /** User must change their password before accessing protected routes. */
  FORCE_PASSWORD_CHANGE: "FORCE_PASSWORD_CHANGE",
  /** Account is deactivated. */
  ACCOUNT_DISABLED: "ACCOUNT_DISABLED",
  /** Authenticated but lacks the required role. */
  FORBIDDEN: "FORBIDDEN",
  /** Registration/update conflict on a unique field. */
  EMAIL_TAKEN: "EMAIL_TAKEN",
  USERNAME_TAKEN: "USERNAME_TAKEN",
  ROLL_NUMBER_TAKEN: "ROLL_NUMBER_TAKEN",
} as const;
export type AuthErrorCode = (typeof AuthErrorCode)[keyof typeof AuthErrorCode];
