/**
 * The single OpenAI-compatible LLM call used across the backend (essay grading
 * in the worker, essay keyword-generation in the API). It lives in @codeapt/
 * shared because it is the ONE integration both services consume — each passes
 * its own env-sourced config; there is no second provider system.
 *
 * Defensive + never-throws: missing config, non-2xx, network error, timeout, or
 * unparseable output all resolve to `null`, so callers fall back cleanly. The
 * caller supplies a system + user prompt that MUST elicit strict JSON; this
 * helper strips code fences, isolates the JSON object, and parses it.
 *
 * Uses global `fetch` + `AbortController` (Node 20+ / browsers). It is only
 * ever invoked server-side.
 */

export interface LlmChatConfig {
  /** Base URL of an OpenAI-compatible API (…/v1). */
  url?: string;
  apiKey?: string;
  model: string;
  timeoutMs: number;
}

/** Strip Markdown code fences and isolate the outermost {...} JSON object. */
export function extractJsonObject(text: string): string {
  let t = text.trim();
  t = t.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "");
  const start = t.indexOf("{");
  const end = t.lastIndexOf("}");
  if (start !== -1 && end !== -1 && end > start) return t.slice(start, end + 1);
  return t;
}

/**
 * POST a system+user chat completion (temperature 0) and return the PARSED JSON
 * object the model was asked to produce, or `null` on ANY failure. Never throws.
 */
export async function callLlmChatJson(
  config: LlmChatConfig,
  systemPrompt: string,
  userPrompt: string,
): Promise<unknown | null> {
  if (!config.url || !config.apiKey) return null;

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), config.timeoutMs);
  try {
    const res = await fetch(`${config.url.replace(/\/$/, "")}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${config.apiKey}`,
      },
      body: JSON.stringify({
        model: config.model,
        temperature: 0,
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
      }),
      signal: controller.signal,
    });
    if (!res.ok) return null;
    const body = (await res.json()) as {
      choices?: { message?: { content?: unknown } }[];
    };
    const content = body.choices?.[0]?.message?.content;
    if (typeof content !== "string" || !content) return null;
    try {
      return JSON.parse(extractJsonObject(content));
    } catch {
      return null; // unparseable → caller falls back
    }
  } catch {
    return null; // network / timeout / abort → caller falls back
  } finally {
    clearTimeout(timer);
  }
}
