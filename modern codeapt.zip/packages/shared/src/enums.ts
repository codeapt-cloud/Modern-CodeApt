/**
 * Centralized enums for the whole system.
 *
 * We use `as const` objects instead of TS `enum`s: they emit no extra runtime
 * machinery, tree-shake cleanly, expose a `*_VALUES` array for Mongoose
 * `enum:` options, and give us a same-named union type for free.
 */

// ---------------------------------------------------------------------------
// Auth / users
// ---------------------------------------------------------------------------

export const Role = {
  STUDENT: "student",
  ADMIN: "admin",
} as const;
export type Role = (typeof Role)[keyof typeof Role];
export const ROLE_VALUES = Object.values(Role);

// ---------------------------------------------------------------------------
// Payments (Order.status)
// ---------------------------------------------------------------------------

export const OrderStatus = {
  PENDING: "PENDING",
  SUCCESS: "SUCCESS",
  FAILED: "FAILED",
} as const;
export type OrderStatus = (typeof OrderStatus)[keyof typeof OrderStatus];
export const ORDER_STATUS_VALUES = Object.values(OrderStatus);

export const CouponDiscountType = {
  PERCENTAGE: "percentage",
  FIXED: "fixed",
} as const;
export type CouponDiscountType =
  (typeof CouponDiscountType)[keyof typeof CouponDiscountType];
export const COUPON_DISCOUNT_TYPE_VALUES = Object.values(CouponDiscountType);

/**
 * Payment order lifecycle. Richer than the original Django `{PENDING, SUCCESS,
 * FAILED}` (kept as {@link OrderStatus} for reference): an order starts
 * `created` (row written + gateway invoked), may sit `pending` at the gateway,
 * and transitions EXACTLY ONCE to a terminal `success`/`failed`/`expired`.
 */
export const PaymentStatus = {
  CREATED: "created",
  PENDING: "pending",
  SUCCESS: "success",
  FAILED: "failed",
  EXPIRED: "expired",
} as const;
export type PaymentStatus = (typeof PaymentStatus)[keyof typeof PaymentStatus];
export const PAYMENT_STATUS_VALUES = Object.values(PaymentStatus);

/** Pre-terminal states an order may still legally transition FROM. */
export const PAYMENT_NON_TERMINAL_STATUSES: readonly PaymentStatus[] = [
  PaymentStatus.CREATED,
  PaymentStatus.PENDING,
];

// ---------------------------------------------------------------------------
// Curriculum
// ---------------------------------------------------------------------------

export const TopicType = {
  TEXT: "text",
  VIDEO: "video",
  QUIZ: "quiz",
  EXAM: "exam",
  ESSAY: "essay",
} as const;
export type TopicType = (typeof TopicType)[keyof typeof TopicType];
export const TOPIC_TYPE_VALUES = Object.values(TopicType);

// ---------------------------------------------------------------------------
// Question types
// ---------------------------------------------------------------------------

/** Exam questions (assessments surface). */
export const ExamQuestionType = {
  MCQ_SINGLE: "MCQ_SINGLE",
  MCQ_MULTI: "MCQ_MULTI",
  CODE: "CODE",
} as const;
export type ExamQuestionType =
  (typeof ExamQuestionType)[keyof typeof ExamQuestionType];
export const EXAM_QUESTION_TYPE_VALUES = Object.values(ExamQuestionType);

/** Daily-challenge questions. */
export const DailyQuestionType = {
  MCQ: "MCQ",
  CODE: "CODE",
} as const;
export type DailyQuestionType =
  (typeof DailyQuestionType)[keyof typeof DailyQuestionType];
export const DAILY_QUESTION_TYPE_VALUES = Object.values(DailyQuestionType);

// ---------------------------------------------------------------------------
// Assessments (StudentExamAttempt.status)
// ---------------------------------------------------------------------------

export const ExamAttemptStatus = {
  /** Candidate is working through sections. */
  IN_PROGRESS: "in_progress",
  /** Submitted; MCQ graded, CODE grading may still be running on the queue. */
  SUBMITTED: "submitted",
  /** Fully graded (score/passed final). */
  GRADED: "graded",
  /** Abandoned/expired without a completed submission. */
  EXPIRED: "expired",
} as const;
export type ExamAttemptStatus =
  (typeof ExamAttemptStatus)[keyof typeof ExamAttemptStatus];
export const EXAM_ATTEMPT_STATUS_VALUES = Object.values(ExamAttemptStatus);

// ---------------------------------------------------------------------------
// Essays
// ---------------------------------------------------------------------------

export const EssayStatus = {
  DRAFT: "DRAFT",
  IN_PROGRESS: "IN_PROGRESS",
  SUBMITTED: "SUBMITTED",
  UNDER_REVIEW: "UNDER_REVIEW",
  GRADED: "GRADED",
  CANCELLED: "CANCELLED",
} as const;
export type EssayStatus = (typeof EssayStatus)[keyof typeof EssayStatus];
export const ESSAY_STATUS_VALUES = Object.values(EssayStatus);

/** Difficulty levels 1/2/3 as in the original EssayTopic. */
export const EssayDifficulty = {
  EASY: 1,
  MEDIUM: 2,
  HARD: 3,
} as const;
export type EssayDifficulty =
  (typeof EssayDifficulty)[keyof typeof EssayDifficulty];
export const ESSAY_DIFFICULTY_VALUES = Object.values(EssayDifficulty);

/**
 * How an essay's final score was produced:
 * - `ai_hybrid`: deterministic engine blended with a successful AI analysis
 *   (vocabulary & structure = 0.6 deterministic + 0.4 AI).
 * - `deterministic_fallback`: AI was disabled/failed/timed out, so the score is
 *   the deterministic engine alone. This is the guaranteed floor — grading
 *   NEVER fails just because the AI layer is unavailable.
 */
export const EssayScoreSource = {
  AI_HYBRID: "ai_hybrid",
  DETERMINISTIC_FALLBACK: "deterministic_fallback",
} as const;
export type EssayScoreSource =
  (typeof EssayScoreSource)[keyof typeof EssayScoreSource];
export const ESSAY_SCORE_SOURCE_VALUES = Object.values(EssayScoreSource);

/**
 * Essay grading lifecycle. Mirrors {@link JobStatus} value-for-value (essays
 * ride the same async-job model) but is named for the essay surface so the UI
 * and schemas can refer to it directly.
 */
export const EssayGradingStatus = {
  QUEUED: "queued",
  PROCESSING: "processing",
  COMPLETED: "completed",
  FAILED: "failed",
} as const;
export type EssayGradingStatus =
  (typeof EssayGradingStatus)[keyof typeof EssayGradingStatus];
export const ESSAY_GRADING_STATUS_VALUES = Object.values(EssayGradingStatus);

// ---------------------------------------------------------------------------
// Grading / async jobs
// ---------------------------------------------------------------------------

/** ExecutionJob.status and essay grading_status share this lifecycle. */
export const JobStatus = {
  QUEUED: "queued",
  PROCESSING: "processing",
  COMPLETED: "completed",
  FAILED: "failed",
} as const;
export type JobStatus = (typeof JobStatus)[keyof typeof JobStatus];
export const JOB_STATUS_VALUES = Object.values(JobStatus);

// ---------------------------------------------------------------------------
// Code execution
// ---------------------------------------------------------------------------

/** Languages supported by the Piston-backed executor. */
export const CodeLanguage = {
  PYTHON: "python",
  JAVASCRIPT: "javascript",
  JAVA: "java",
  CPP: "cpp",
  C: "c",
} as const;
export type CodeLanguage = (typeof CodeLanguage)[keyof typeof CodeLanguage];
export const CODE_LANGUAGE_VALUES = Object.values(CodeLanguage);

// ---------------------------------------------------------------------------
// Job applications (careers)
// ---------------------------------------------------------------------------

export const JobApplicationStatus = {
  SUBMITTED: "SUBMITTED",
  UNDER_REVIEW: "UNDER_REVIEW",
  SHORTLISTED: "SHORTLISTED",
  REJECTED: "REJECTED",
  HIRED: "HIRED",
} as const;
export type JobApplicationStatus =
  (typeof JobApplicationStatus)[keyof typeof JobApplicationStatus];
export const JOB_APPLICATION_STATUS_VALUES =
  Object.values(JobApplicationStatus);

/**
 * Posting employment type. The original stored a free-text `employment_type`;
 * this typed set (added for a filterable, validated UI) is the minimal sensible
 * enumeration for a campus placement board.
 */
export const PostingType = {
  FULL_TIME: "full_time",
  INTERNSHIP: "internship",
  PART_TIME: "part_time",
  CONTRACT: "contract",
} as const;
export type PostingType = (typeof PostingType)[keyof typeof PostingType];
export const POSTING_TYPE_VALUES = Object.values(PostingType);
