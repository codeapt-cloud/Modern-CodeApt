/**
 * The essay-writing screen's compose view: the prompt (title/description/
 * instructions, safely rendered), a plain-text writing area, a LIVE word
 * counter with under/in/over affordances, an optional DISPLAY-ONLY countdown,
 * and cheap in-memory compose-analytics capture.
 *
 * Word bounds are advisory client-side — submit is disabled out of range, but
 * the server's 422 is the source of truth and is surfaced inline (`submitError`).
 * The timer is guidance only: on expiry we show a gentle cue and STILL allow
 * submit (there is no server-side essay timer). Draft is in-memory only; a
 * beforeunload guard warns before losing unsaved text.
 */
import type { EssayAnalyticsInput, EssayPromptDetail } from "@codeapt/shared";
import { useReducedMotion } from "framer-motion";
import { AlertTriangle, Check, Clock, Loader2, Save, Send } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";

import { formatCountdown } from "../../lib/exam-runner.js";
import {
  countWords,
  emptyAnalytics,
  onKeystroke,
  onPaste,
  wordCountStatus,
  type ComposeAnalytics,
} from "../../lib/essay-compose.js";
import { draftStatusLabel, shouldRecoverDraft } from "../../lib/essay-draft.js";
import type { EssayWriterApi } from "../../lib/essay-writer-api.js";
import { useEssayDraft } from "../../lib/use-essay-draft.js";
import { Alert } from "../ui/alert.js";
import { Button } from "../ui/button.js";
import { Textarea } from "../ui/textarea.js";
import { Markdown } from "../player/Markdown.js";

const STATE_TEXT: Record<string, string> = {
  empty: "text-ink-muted",
  under: "text-warning-fg",
  in: "text-success-fg",
  over: "text-error-fg",
};

export function EssayComposer({
  prompt,
  submitting,
  submitError,
  attemptLabel,
  onSubmit,
  writerApi,
}: {
  prompt: EssayPromptDetail;
  submitting: boolean;
  submitError: string | null;
  /** e.g. "Attempt 2 of 3" — shown as guidance; null hides it. */
  attemptLabel?: string | null;
  /** Called with the essay text + captured compose analytics on submit. */
  onSubmit: (content: string, analytics: EssayAnalyticsInput) => void;
  /** Draft autosave backend — defaults to the individual api; the college
   * writer injects a slug-bound adapter. */
  writerApi?: EssayWriterApi;
}) {
  const reduced = useReducedMotion();
  const [content, setContent] = useState("");
  const [recovered, setRecovered] = useState(false);

  // Analytics + compose-time are refs — updated per keystroke without re-render.
  const analyticsRef = useRef<ComposeAnalytics>(emptyAnalytics());
  const startedAtRef = useRef<number | null>(null);

  // Autosave + recovery (a pure snapshot buffer — never submits or grades).
  const draft = useEssayDraft(prompt.id, writerApi);
  const contentRef = useRef(content);
  contentRef.current = content;
  const didRecover = useRef(false);
  useEffect(() => {
    if (didRecover.current) return;
    didRecover.current = true;
    void (async () => {
      const text = await draft.recover();
      // Only restore into a still-empty editor; never clobber fresh typing.
      if (text && shouldRecoverDraft(text, contentRef.current)) {
        setContent(text);
        setRecovered(true);
      }
    })();
  }, [draft]);

  const status = useMemo(
    () =>
      wordCountStatus(countWords(content), prompt.minWords, prompt.maxWords),
    [content, prompt.minWords, prompt.maxWords],
  );

  // Guard against accidental navigation loss while there's unsaved text.
  useEffect(() => {
    const dirty = content.trim().length > 0;
    if (!dirty) return;
    const handler = (e: BeforeUnloadEvent): void => {
      e.preventDefault();
      e.returnValue = "";
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, [content]);

  // --- Display-only countdown (guidance, NOT enforced) ---
  const timed = prompt.timeLimitMinutes > 0;
  const [remaining, setRemaining] = useState(prompt.timeLimitMinutes * 60);
  useEffect(() => {
    if (!timed) return;
    const id = window.setInterval(
      () => setRemaining((s) => (s <= 0 ? 0 : s - 1)),
      1000,
    );
    return () => window.clearInterval(id);
  }, [timed]);
  const timeUp = timed && remaining <= 0;

  const handleSubmit = (): void => {
    if (!status.canSubmit || submitting) return;
    const a = analyticsRef.current;
    const composeSeconds = startedAtRef.current
      ? Math.round((performance.now() - startedAtRef.current) / 1000)
      : 0;
    onSubmit(content, {
      keystrokes: a.keystrokes,
      deletes: a.deletes,
      pasteCount: a.pasteCount,
      pastedChars: a.pastedChars,
      composeSeconds,
      wordCount: status.count,
      characterCount: content.length,
    });
  };

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_1.4fr]">
      {/* Prompt */}
      <aside className="space-y-4">
        <div className="rounded-2xl border border-subtle bg-surface-raised p-5">
          <div className="flex items-start justify-between gap-3">
            <h2 className="text-lg font-semibold text-ink">{prompt.title}</h2>
            {attemptLabel ? (
              <span className="shrink-0 rounded-full border border-subtle px-2.5 py-1 text-xs font-medium text-ink-muted">
                {attemptLabel}
              </span>
            ) : null}
          </div>
          {prompt.description ? (
            <p className="mt-2 text-sm text-ink-secondary">
              {prompt.description}
            </p>
          ) : null}
        </div>
        {prompt.instructions ? (
          <div className="rounded-2xl border border-subtle bg-surface-raised p-5">
            <h3 className="mb-1 text-xs font-semibold uppercase tracking-wide text-ink-muted">
              Instructions
            </h3>
            <Markdown content={prompt.instructions} className="text-sm" />
          </div>
        ) : null}
      </aside>

      {/* Editor */}
      <div className="space-y-3">
        <div className="flex items-center justify-between gap-3">
          <div className={`text-sm font-medium ${STATE_TEXT[status.state]}`}>
            <span className="font-mono">{status.count}</span> words —{" "}
            {status.message}
          </div>
          {timed ? (
            <div
              className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 font-mono text-sm ${
                timeUp
                  ? "border-warning/60 text-warning-fg"
                  : "border-subtle text-ink"
              }`}
            >
              <Clock className="h-3.5 w-3.5" />
              {formatCountdown(remaining)}
            </div>
          ) : null}
        </div>

        {recovered ? (
          <Alert variant="info">
            Recovered your last draft — pick up right where you left off.
          </Alert>
        ) : null}
        {timeUp ? (
          <Alert variant="warning">
            Time&rsquo;s up — this timer is guidance only, so you can still
            finish and submit when you&rsquo;re ready.
          </Alert>
        ) : null}
        {submitError ? <Alert variant="error">{submitError}</Alert> : null}

        <Textarea
          value={content}
          onChange={(e) => {
            if (startedAtRef.current === null) {
              startedAtRef.current = performance.now();
            }
            setContent(e.target.value);
            draft.schedule(e.target.value);
          }}
          onKeyDown={(e) => {
            analyticsRef.current = onKeystroke(analyticsRef.current, e.key);
          }}
          onPaste={(e) => {
            const pasted = e.clipboardData.getData("text");
            analyticsRef.current = onPaste(analyticsRef.current, pasted.length);
          }}
          invalid={status.state === "over"}
          placeholder="Write your essay here…"
          className="min-h-[46vh] resize-y text-[0.95rem] leading-7"
          aria-label="Essay text"
        />

        <div className="flex items-center justify-between gap-3">
          <div
            className="inline-flex items-center gap-1.5 text-xs text-ink-muted"
            aria-live="polite"
          >
            {draft.state === "saving" ? (
              <Loader2 className="h-3 w-3 animate-spin" />
            ) : draft.state === "error" ? (
              <AlertTriangle className="h-3 w-3 text-warning-fg" />
            ) : draft.savedAt ? (
              <Check className="h-3 w-3 text-success-fg" />
            ) : (
              <Save className="h-3 w-3" />
            )}
            <span>
              {draft.state === "idle"
                ? draft.savedAt
                  ? "Draft saved"
                  : "Autosaves as you write"
                : draftStatusLabel(draft.state)}
            </span>
          </div>
          <Button
            onClick={handleSubmit}
            disabled={!status.canSubmit}
            loading={submitting}
            className={reduced ? "" : "transition-transform"}
          >
            <Send className="h-4 w-4" /> Submit for grading
          </Button>
        </div>
      </div>
    </div>
  );
}
