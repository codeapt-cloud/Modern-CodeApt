/**
 * Typed API client — axios wrapper for the CodeApt REST API.
 *
 * Browser auth rides on httpOnly cookies (withCredentials), so we don't store
 * tokens in JS. A response interceptor transparently refreshes once on 401 and
 * retries; a 403 FORCE_PASSWORD_CHANGE is surfaced to the app via a handler so
 * the router can gate access. In dev, VITE_API_URL is empty and requests hit
 * `/api/*` same-origin (Vite proxies to the API).
 */
import {
  API_PREFIX,
  AuthErrorCode,
  type AdminApplicationListResponse,
  type AdminCoupon,
  type AdminCouponListResponse,
  type AdminCouponUpsert,
  type AdminChallenge,
  type AdminChallengeBulkImportResponse,
  type AdminChallengeListResponse,
  type AdminChallengeUpsert,
  type AdminEssayAnalyticsListQuery,
  type AdminEssayAnalyticsListResponse,
  type AdminEssayAttemptAnalytics,
  type AdminOrderDetail,
  type AdminOrderListQuery,
  type AdminOrderListResponse,
  type College,
  type CollegeAdmin,
  type CollegeAdminListResponse,
  type CollegeContextResponse,
  type CollegeCourseListResponse,
  type CollegeExamListResponse,
  type CollegeExamResultsResponse,
  type CreateCollegeExamInput,
  type UpdateCollegeExamInput,
  type CollegeEssayListResponse,
  type CollegeEssayResultsResponse,
  type CreateCollegeEssayInput,
  type CollegeChallengeLeaderboardResponse,
  type CollegeAnalyticsOverview,
  type CollegeAnalyticsByUnitResponse,
  type CollegeAnalyticsStudent,
  type CollegePostingListResponse,
  type CollegePostingSummary,
  type CollegeStudentPostingListResponse,
  type CreateCollegePostingInput,
  type CollegeSummaryResponse,
  type CollegeListResponse,
  type CreateCollegeAdminInput,
  type CollegeStudent,
  type CollegeStudentListQuery,
  type CollegeStudentListResponse,
  type CollegeStudentSummaryResponse,
  type CourseAssignResponse,
  type CourseAssignedStudentsResponse,
  type CourseRevokeResponse,
  type CreateCollegeInput,
  type CreateCollegeStudentInput,
  type CreateFacultyInput,
  type CreateOrgUnitInput,
  type BulkCreateOrgUnitsInput,
  type BulkCreateOrgUnitsResponse,
  type Faculty,
  type FacultyListResponse,
  type GrantCoursesInput,
  type MyCollegeResponse,
  type OrgUnit,
  type OrgUnitTreeResponse,
  type SetEntitlementsInput,
  type StudentImportCommitResponse,
  type StudentImportPreviewResponse,
  type StudentImportRowInput,
  type UpdateCollegeInput,
  type UpdateCollegeStudentInput,
  type UpdateFacultyInput,
  type UpdateOrgUnitInput,
  type UploadSignatureResponse,
  type AdminExamAttemptCountersResponse,
  type AdminExamResetLogResponse,
  type AdminUserExamAttemptsResponse,
  type AdminUpdateProfile,
  type AdminUserDetail,
  type AdminUserListQuery,
  type AdminUserListResponse,
  type Role,
  type AdminEssayTopic,
  type AdminEssayTopicListResponse,
  type AdminEssayTopicUpsert,
  type GenerateKeywordsRequest,
  type GenerateKeywordsResponse,
  type AdminExamDetail,
  type AdminExamListResponse,
  type AdminExamUpsert,
  type AdminExamTopicListResponse,
  type AdminModule,
  type AdminModuleListResponse,
  type AdminModuleUpsert,
  type AdminProgram,
  type AdminProgramListResponse,
  type AdminProgramUpsert,
  type AdminQuizQuestion,
  type AdminQuizQuestionListResponse,
  type AdminQuizQuestionUpsert,
  type AdminReorder,
  type AdminSubject,
  type AdminSubjectListResponse,
  type AdminSubjectUpsert,
  type AdminTopic,
  type BulkEnrollResponse,
  type AdminTopicListResponse,
  type AdminTopicUpsert,
  type TopicExcelUploadResponse,
  type AdminPosting,
  type AdminPostingListResponse,
  type AdminPostingUpsert,
  type AdminPublicLinkUpsert,
  type AdminQuestionUpsert,
  type AdminResetAttemptsRequest,
  type AdminSectionUpsert,
  type AdminTestCaseUpsert,
  type ExamBulkUploadKind,
  type ExcelUploadResponse,
  type PublicLink,
  type ApplicationResponse,
  type ApplyRequest,
  type AuthResponse,
  type CatalogQuery,
  type CatalogResponse,
  type ChallengeTodayResponse,
  type ChangePasswordInput,
  type AnswerInput,
  type AttemptSectionView,
  type CreateOrderRequest,
  type CreateOrderResponse,
  type JobApplicationStatus,
  type MyApplicationsResponse,
  type PostingDetail,
  type PostingListQuery,
  type PostingListResponse,
  type EnrollResponse,
  type EssayAnalyticsInput,
  type EssayDraftResponse,
  type EssayGradingResult,
  type EssayListResponse,
  type EssayPromptDetail,
  type EssaySubmissionListResponse,
  type SaveEssayDraftResponse,
  type ExamListResponse,
  type ExamResult,
  type MockPayRequest,
  type OrderListResponse,
  type OrderStatusResponse,
  type QuoteRequest,
  type QuoteResponse,
  type ExecuteRequest,
  type ExecuteStatusResponse,
  type FinalizeChallengeResponse,
  type HealthResponse,
  type JobRef,
  type LeaderboardQuery,
  type LeaderboardResponse,
  type LoginInput,
  type PublicExamAvailability,
  type PublicStartRequest,
  type RecordWarningResponse,
  type SaveSectionAnswersResponse,
  type StartAttemptResponse,
  type MeResponse,
  type MyEnrollmentsResponse,
  type Quiz,
  type QuizResult,
  type QuizSubmitRequest,
  type RegisterInput,
  type RegisterResponse,
  type SubmitCodeRequest,
  type SubmitMcqResponse,
  type SubjectDetail,
  type TopicCompleteResponse,
  type TopicContent,
  type UpdateMeInput,
} from "@codeapt/shared";
import axios, {
  AxiosError,
  type AxiosInstance,
  type InternalAxiosRequestConfig,
} from "axios";

import { apiUrl } from "./url.js";

// Trim any trailing slash so manual joins (e.g. the SSE stream URL below) don't
// produce a double slash like `http://host//api/...` when VITE_API_URL is set
// with a trailing "/". Axios already normalizes its own base+path join, so this
// is a no-op for axios requests and a correctness fix for hand-built URLs.
const baseURL = (import.meta.env.VITE_API_URL ?? "").replace(/\/+$/, "");

export const http: AxiosInstance = axios.create({
  baseURL,
  withCredentials: true,
  headers: { "Content-Type": "application/json" },
});

// --- Structured API error helper -------------------------------------------

export interface ApiErrorShape {
  message: string;
  code?: string;
  /** Field-level validation errors, when the server provides them. */
  fields?: Record<string, string>;
  /** Raw `error.details` payload (e.g. delete-blocker counts), when present. */
  details?: unknown;
  status?: number;
}

export function parseApiError(err: unknown): ApiErrorShape {
  if (err instanceof AxiosError && err.response) {
    const data = err.response.data as
      | { error?: { message?: string; code?: string; details?: unknown } }
      | undefined;
    const detail = data?.error;
    let message = detail?.message ?? "Something went wrong";
    let fields =
      detail?.details &&
      typeof detail.details === "object" &&
      "fields" in detail.details
        ? ((detail.details as { fields?: Record<string, string> }).fields ??
          undefined)
        : undefined;

    // A Zod validation error serializes its `issues` array into `details`. Turn
    // those into per-field messages and a specific top-level message, so forms
    // show the actual reason (e.g. "Password must contain an uppercase letter")
    // instead of the generic "Request validation failed".
    if (!fields && Array.isArray(detail?.details)) {
      const issues = detail.details as Array<{
        path?: (string | number)[];
        message?: string;
      }>;
      const derived: Record<string, string> = {};
      for (const issue of issues) {
        if (!issue?.message) continue;
        const key =
          Array.isArray(issue.path) && issue.path.length > 0
            ? issue.path.join(".")
            : "_";
        derived[key] ??= issue.message;
      }
      if (Object.keys(derived).length > 0) {
        fields = derived;
        const first = issues.find((i) => i?.message)?.message;
        if (first && message === "Request validation failed") message = first;
      }
    }

    return {
      message,
      code: detail?.code,
      fields,
      details: detail?.details,
      status: err.response.status,
    };
  }
  return { message: "Network error — please try again" };
}

// --- Auth event handlers (registered by AuthProvider) ----------------------

interface AuthEventHandlers {
  onSessionExpired?: () => void;
  onForcePasswordChange?: () => void;
}
let handlers: AuthEventHandlers = {};
export function setAuthEventHandlers(next: AuthEventHandlers): void {
  handlers = next;
}

// --- Refresh interceptor (single-flight) -----------------------------------

const AUTH_PATHS = [
  "/auth/login",
  "/auth/register",
  "/auth/refresh",
  "/auth/logout",
];
type RetryConfig = InternalAxiosRequestConfig & { _retried?: boolean };

let refreshPromise: Promise<void> | null = null;

async function runRefresh(): Promise<void> {
  refreshPromise ??= http
    .post(`${API_PREFIX}/auth/refresh`)
    .then(() => undefined)
    .finally(() => {
      refreshPromise = null;
    });
  return refreshPromise;
}

http.interceptors.response.use(
  (res) => res,
  async (error: unknown) => {
    if (!(error instanceof AxiosError) || !error.config || !error.response) {
      return Promise.reject(error);
    }
    const config = error.config as RetryConfig;
    const status = error.response.status;
    const code = (error.response.data as { error?: { code?: string } })?.error
      ?.code;
    const isAuthPath = AUTH_PATHS.some((p) => config.url?.includes(p));

    // Forced password change: let the app route to the change-password gate.
    if (status === 403 && code === AuthErrorCode.FORCE_PASSWORD_CHANGE) {
      handlers.onForcePasswordChange?.();
      return Promise.reject(error);
    }

    // One transparent refresh + retry on 401 (never for auth endpoints).
    if (status === 401 && !config._retried && !isAuthPath) {
      config._retried = true;
      try {
        await runRefresh();
        return await http(config);
      } catch (refreshErr) {
        handlers.onSessionExpired?.();
        return Promise.reject(refreshErr);
      }
    }

    return Promise.reject(error);
  },
);

// --- Endpoint helpers ------------------------------------------------------

export const api = {
  health: async (): Promise<HealthResponse> => {
    const { data } = await http.get<HealthResponse>(`${API_PREFIX}/health`);
    return data;
  },

  auth: {
    register: async (input: RegisterInput): Promise<RegisterResponse> => {
      const { data } = await http.post<RegisterResponse>(
        `${API_PREFIX}/auth/register`,
        input,
      );
      return data;
    },
    login: async (input: LoginInput): Promise<AuthResponse> => {
      const { data } = await http.post<AuthResponse>(
        `${API_PREFIX}/auth/login`,
        input,
      );
      return data;
    },
    logout: async (): Promise<void> => {
      await http.post(`${API_PREFIX}/auth/logout`);
    },
    changePassword: async (
      input: ChangePasswordInput,
    ): Promise<AuthResponse> => {
      const { data } = await http.post<AuthResponse>(
        `${API_PREFIX}/auth/change-password`,
        input,
      );
      return data;
    },
  },

  me: {
    get: async (): Promise<MeResponse> => {
      const { data } = await http.get<MeResponse>(`${API_PREFIX}/me`);
      return data;
    },
    update: async (input: UpdateMeInput): Promise<MeResponse> => {
      const { data } = await http.patch<MeResponse>(`${API_PREFIX}/me`, input);
      return data;
    },
    enrollments: async (): Promise<MyEnrollmentsResponse> => {
      const { data } = await http.get<MyEnrollmentsResponse>(
        `${API_PREFIX}/me/enrollments`,
      );
      return data;
    },
    /** The caller's own college membership (null for individual users). */
    college: async (): Promise<MyCollegeResponse> => {
      const { data } = await http.get<MyCollegeResponse>(
        `${API_PREFIX}/me/college`,
      );
      return data;
    },
  },

  curriculum: {
    catalog: async (
      params: Partial<CatalogQuery> = {},
    ): Promise<CatalogResponse> => {
      const { data } = await http.get<CatalogResponse>(
        `${API_PREFIX}/catalog`,
        {
          params,
        },
      );
      return data;
    },
    subject: async (slug: string): Promise<SubjectDetail> => {
      const { data } = await http.get<SubjectDetail>(
        `${API_PREFIX}/subjects/${slug}`,
      );
      return data;
    },
    enroll: async (slug: string): Promise<EnrollResponse> => {
      const { data } = await http.post<EnrollResponse>(
        `${API_PREFIX}/subjects/${slug}/enroll`,
      );
      return data;
    },
    topic: async (slug: string, topicId: string): Promise<TopicContent> => {
      const { data } = await http.get<TopicContent>(
        `${API_PREFIX}/subjects/${slug}/topics/${topicId}`,
      );
      return data;
    },
    completeTopic: async (
      slug: string,
      topicId: string,
      completed: boolean,
    ): Promise<TopicCompleteResponse> => {
      const { data } = await http.post<TopicCompleteResponse>(
        `${API_PREFIX}/subjects/${slug}/topics/${topicId}/complete`,
        { completed },
      );
      return data;
    },
    quiz: async (slug: string, topicId: string): Promise<Quiz> => {
      const { data } = await http.get<Quiz>(
        `${API_PREFIX}/subjects/${slug}/topics/${topicId}/quiz`,
      );
      return data;
    },
    submitQuiz: async (
      slug: string,
      topicId: string,
      body: QuizSubmitRequest,
    ): Promise<QuizResult> => {
      const { data } = await http.post<QuizResult>(
        `${API_PREFIX}/subjects/${slug}/topics/${topicId}/quiz/submit`,
        body,
      );
      return data;
    },
  },

  execute: {
    /** Submit code; returns fast with a jobId to poll/stream. */
    submit: async (body: ExecuteRequest): Promise<JobRef> => {
      const { data } = await http.post<JobRef>(`${API_PREFIX}/execute`, body);
      return data;
    },
    /** Poll a job's status + result. */
    status: async (jobId: string): Promise<ExecuteStatusResponse> => {
      const { data } = await http.get<ExecuteStatusResponse>(
        `${API_PREFIX}/execute/${jobId}`,
      );
      return data;
    },
    /** SSE endpoint URL for status transitions (same-origin; cookies ride along). */
    streamUrl: (jobId: string): string =>
      apiUrl(baseURL, `${API_PREFIX}/execute/${jobId}/stream`),
  },

  challenges: {
    today: async (): Promise<ChallengeTodayResponse> => {
      const { data } = await http.get<ChallengeTodayResponse>(
        `${API_PREFIX}/challenges/today`,
      );
      return data;
    },
    submitMcq: async (option: number): Promise<SubmitMcqResponse> => {
      const { data } = await http.post<SubmitMcqResponse>(
        `${API_PREFIX}/challenges/today/submit-mcq`,
        { option },
      );
      return data;
    },
    submitCode: async (body: SubmitCodeRequest): Promise<JobRef> => {
      const { data } = await http.post<JobRef>(
        `${API_PREFIX}/challenges/today/submit-code`,
        body,
      );
      return data;
    },
    finalize: async (jobId: string): Promise<FinalizeChallengeResponse> => {
      const { data } = await http.post<FinalizeChallengeResponse>(
        `${API_PREFIX}/challenges/submissions/${jobId}/finalize`,
      );
      return data;
    },
    leaderboard: async (
      params: Partial<LeaderboardQuery> = {},
    ): Promise<LeaderboardResponse> => {
      const { data } = await http.get<LeaderboardResponse>(
        `${API_PREFIX}/challenges/leaderboard`,
        { params },
      );
      return data;
    },
  },

  payments: {
    /** Price + coupon preview (no side effects). */
    quote: async (body: QuoteRequest): Promise<QuoteResponse> => {
      const { data } = await http.post<QuoteResponse>(
        `${API_PREFIX}/payments/quote`,
        body,
      );
      return data;
    },
    /** Create an order; returns the gateway redirect payload. */
    createOrder: async (
      body: CreateOrderRequest,
    ): Promise<CreateOrderResponse> => {
      const { data } = await http.post<CreateOrderResponse>(
        `${API_PREFIX}/payments/orders`,
        body,
      );
      return data;
    },
    /** Poll an order's status + enrollment flag. */
    order: async (orderId: string): Promise<OrderStatusResponse> => {
      const { data } = await http.get<OrderStatusResponse>(
        `${API_PREFIX}/payments/orders/${orderId}`,
      );
      return data;
    },
    /** The caller's order history (newest first). */
    orders: async (): Promise<OrderListResponse> => {
      const { data } = await http.get<OrderListResponse>(
        `${API_PREFIX}/payments/orders`,
      );
      return data;
    },
    /** Mock-only: drive a verified success/failure callback (dev gateway). */
    mockPay: async (body: MockPayRequest): Promise<OrderStatusResponse> => {
      const { data } = await http.post<OrderStatusResponse>(
        `${API_PREFIX}/payments/mock/pay`,
        body,
      );
      return data;
    },
  },

  essays: {
    /** Essay prompts the logged-in student can attempt (enrolled subjects). */
    list: async (): Promise<EssayListResponse> => {
      const { data } = await http.get<EssayListResponse>(
        `${API_PREFIX}/essays`,
      );
      return data;
    },
    /** Student prompt detail (no rubric internals / reference keywords). */
    get: async (id: string): Promise<EssayPromptDetail> => {
      const { data } = await http.get<EssayPromptDetail>(
        `${API_PREFIX}/essays/${id}`,
      );
      return data;
    },
    /** Latest recoverable draft for a prompt ({ draft: … | null }). */
    draft: async (id: string): Promise<EssayDraftResponse> => {
      const { data } = await http.get<EssayDraftResponse>(
        `${API_PREFIX}/essays/${id}/draft`,
      );
      return data;
    },
    /** Autosave a draft snapshot. Never submits/grades/consumes an attempt. */
    saveDraft: async (
      id: string,
      content: string,
    ): Promise<SaveEssayDraftResponse> => {
      const { data } = await http.put<SaveEssayDraftResponse>(
        `${API_PREFIX}/essays/${id}/draft`,
        { content },
      );
      return data;
    },
    /** Submit an essay; returns fast (202) with a jobId to poll. */
    submit: async (id: string, content: string): Promise<JobRef> => {
      const { data } = await http.post<JobRef>(
        `${API_PREFIX}/essays/${id}/submit`,
        { content },
      );
      return data;
    },
    /** Poll a submission's grading status/result. */
    submission: async (jobId: string): Promise<EssayGradingResult> => {
      const { data } = await http.get<EssayGradingResult>(
        `${API_PREFIX}/essays/submissions/${jobId}`,
      );
      return data;
    },
    /** A prompt's submission history (newest first). */
    submissions: async (id: string): Promise<EssaySubmissionListResponse> => {
      const { data } = await http.get<EssaySubmissionListResponse>(
        `${API_PREFIX}/essays/${id}/submissions`,
      );
      return data;
    },
    /**
     * Optional, additive writing analytics (counts + timings, no content).
     * Never affects the grade. Best-effort — failures are swallowed by callers.
     */
    analytics: async (
      jobId: string,
      body: EssayAnalyticsInput,
    ): Promise<void> => {
      await http.post(
        `${API_PREFIX}/essays/submissions/${jobId}/analytics`,
        body,
      );
    },
  },

  careers: {
    /** Paginated job/placement postings (active + not-past-deadline by default). */
    list: async (
      params: Partial<PostingListQuery> = {},
    ): Promise<PostingListResponse> => {
      const { data } = await http.get<PostingListResponse>(
        `${API_PREFIX}/careers`,
        { params },
      );
      return data;
    },
    /** Student posting detail (+ the caller's own application, if any). */
    get: async (id: string): Promise<PostingDetail> => {
      const { data } = await http.get<PostingDetail>(
        `${API_PREFIX}/careers/${id}`,
      );
      return data;
    },
    /** Apply in-app to a posting (only for postings without an applyUrl). */
    apply: async (
      id: string,
      body: ApplyRequest,
    ): Promise<ApplicationResponse> => {
      const { data } = await http.post<ApplicationResponse>(
        `${API_PREFIX}/careers/${id}/apply`,
        body,
      );
      return data;
    },
    /** The caller's own in-app applications (newest first). */
    myApplications: async (): Promise<MyApplicationsResponse> => {
      const { data } = await http.get<MyApplicationsResponse>(
        `${API_PREFIX}/careers/applications`,
      );
      return data;
    },
  },

  adminCareers: {
    list: async (): Promise<AdminPostingListResponse> => {
      const { data } = await http.get<AdminPostingListResponse>(
        `${API_PREFIX}/admin/careers`,
      );
      return data;
    },
    get: async (id: string): Promise<AdminPosting> => {
      const { data } = await http.get<AdminPosting>(
        `${API_PREFIX}/admin/careers/${id}`,
      );
      return data;
    },
    create: async (body: AdminPostingUpsert): Promise<AdminPosting> => {
      const { data } = await http.post<AdminPosting>(
        `${API_PREFIX}/admin/careers`,
        body,
      );
      return data;
    },
    update: async (
      id: string,
      body: AdminPostingUpsert,
    ): Promise<AdminPosting> => {
      const { data } = await http.patch<AdminPosting>(
        `${API_PREFIX}/admin/careers/${id}`,
        body,
      );
      return data;
    },
    publish: async (id: string): Promise<AdminPosting> => {
      const { data } = await http.post<AdminPosting>(
        `${API_PREFIX}/admin/careers/${id}/publish`,
      );
      return data;
    },
    close: async (id: string): Promise<AdminPosting> => {
      const { data } = await http.post<AdminPosting>(
        `${API_PREFIX}/admin/careers/${id}/close`,
      );
      return data;
    },
    remove: async (id: string): Promise<{ deleted: true }> => {
      const { data } = await http.delete<{ deleted: true }>(
        `${API_PREFIX}/admin/careers/${id}`,
      );
      return data;
    },
    applications: async (
      id: string,
    ): Promise<AdminApplicationListResponse> => {
      const { data } = await http.get<AdminApplicationListResponse>(
        `${API_PREFIX}/admin/careers/${id}/applications`,
      );
      return data;
    },
    updateApplicationStatus: async (
      appId: string,
      status: JobApplicationStatus,
    ): Promise<{ id: string; status: JobApplicationStatus }> => {
      const { data } = await http.patch<{
        id: string;
        status: JobApplicationStatus;
      }>(`${API_PREFIX}/admin/careers/applications/${appId}`, { status });
      return data;
    },
  },

  adminCoupons: {
    list: async (): Promise<AdminCouponListResponse> => {
      const { data } = await http.get<AdminCouponListResponse>(
        `${API_PREFIX}/admin/coupons`,
      );
      return data;
    },
    get: async (id: string): Promise<AdminCoupon> => {
      const { data } = await http.get<AdminCoupon>(
        `${API_PREFIX}/admin/coupons/${id}`,
      );
      return data;
    },
    create: async (body: AdminCouponUpsert): Promise<AdminCoupon> => {
      const { data } = await http.post<AdminCoupon>(
        `${API_PREFIX}/admin/coupons`,
        body,
      );
      return data;
    },
    update: async (
      id: string,
      body: AdminCouponUpsert,
    ): Promise<AdminCoupon> => {
      const { data } = await http.patch<AdminCoupon>(
        `${API_PREFIX}/admin/coupons/${id}`,
        body,
      );
      return data;
    },
    setActive: async (id: string, active: boolean): Promise<AdminCoupon> => {
      const { data } = await http.post<AdminCoupon>(
        `${API_PREFIX}/admin/coupons/${id}/active`,
        { active },
      );
      return data;
    },
    remove: async (id: string): Promise<{ deleted: true }> => {
      const { data } = await http.delete<{ deleted: true }>(
        `${API_PREFIX}/admin/coupons/${id}`,
      );
      return data;
    },
  },

  /**
   * College (tenant) provisioning + entitlement control — the Phase 0
   * super-admin API. All routes are platform-admin-guarded server-side.
   */
  adminColleges: {
    list: async (): Promise<CollegeListResponse> => {
      const { data } = await http.get<CollegeListResponse>(
        `${API_PREFIX}/admin/colleges`,
      );
      return data;
    },
    get: async (id: string): Promise<College> => {
      const { data } = await http.get<College>(
        `${API_PREFIX}/admin/colleges/${id}`,
      );
      return data;
    },
    create: async (body: CreateCollegeInput): Promise<College> => {
      const { data } = await http.post<College>(
        `${API_PREFIX}/admin/colleges`,
        body,
      );
      return data;
    },
    update: async (id: string, body: UpdateCollegeInput): Promise<College> => {
      const { data } = await http.patch<College>(
        `${API_PREFIX}/admin/colleges/${id}`,
        body,
      );
      return data;
    },
    /** Toggle any subset of feature / sub-capability entitlements. */
    setEntitlements: async (
      id: string,
      body: SetEntitlementsInput,
    ): Promise<College> => {
      const { data } = await http.put<College>(
        `${API_PREFIX}/admin/colleges/${id}/entitlements`,
        body,
      );
      return data;
    },
    /** Grant specific master-catalog courses (Subject ids) to the college. */
    grantCourses: async (
      id: string,
      body: GrantCoursesInput,
    ): Promise<College> => {
      const { data } = await http.post<College>(
        `${API_PREFIX}/admin/colleges/${id}/courses`,
        body,
      );
      return data;
    },
    /** Revoke previously-granted courses from the college. */
    revokeCourses: async (
      id: string,
      body: GrantCoursesInput,
    ): Promise<College> => {
      const { data } = await http.delete<College>(
        `${API_PREFIX}/admin/colleges/${id}/courses`,
        { data: body },
      );
      return data;
    },
    /** The college_admins provisioned for a college. */
    listAdmins: async (id: string): Promise<CollegeAdminListResponse> => {
      const { data } = await http.get<CollegeAdminListResponse>(
        `${API_PREFIX}/admin/colleges/${id}/admins`,
      );
      return data;
    },
    /** Designate a new college_admin (temp password + forced first-login change). */
    createAdmin: async (
      id: string,
      body: CreateCollegeAdminInput,
    ): Promise<CollegeAdmin> => {
      const { data } = await http.post<CollegeAdmin>(
        `${API_PREFIX}/admin/colleges/${id}/admins`,
        body,
      );
      return data;
    },
  },

  /**
   * Tenant-scoped college space (Phase 2b) — everything under /c/:slug/... . The
   * caller must be a member of (or a platform admin over) the college; the server
   * validates the slug via resolveTenant and 403s cross-tenant access.
   */
  collegeContext: {
    /** Resolved identity + membership + entitlements for the college. */
    get: async (slug: string): Promise<CollegeContextResponse> => {
      const { data } = await http.get<CollegeContextResponse>(
        `${API_PREFIX}/c/${slug}/context`,
      );
      return data;
    },
    /** Dashboard aggregate counts + recent students (operators only). */
    summary: async (slug: string): Promise<CollegeSummaryResponse> => {
      const { data } = await http.get<CollegeSummaryResponse>(
        `${API_PREFIX}/c/${slug}/summary`,
      );
      return data;
    },
    /** Student home overview counts (any tenant member; computed for the caller). */
    studentSummary: async (
      slug: string,
    ): Promise<CollegeStudentSummaryResponse> => {
      const { data } = await http.get<CollegeStudentSummaryResponse>(
        `${API_PREFIX}/c/${slug}/student/summary`,
      );
      return data;
    },
    /** The student's assigned college courses (same shape as /me/enrollments). */
    studentCourses: async (slug: string): Promise<MyEnrollmentsResponse> => {
      const { data } = await http.get<MyEnrollmentsResponse>(
        `${API_PREFIX}/c/${slug}/student/courses`,
      );
      return data;
    },
  },

  /** The college's academic structure (departments → years → sections → …). */
  collegeOrgUnits: {
    /** The full nested tree (faculty and above may read). */
    listTree: async (slug: string): Promise<OrgUnitTreeResponse> => {
      const { data } = await http.get<OrgUnitTreeResponse>(
        `${API_PREFIX}/c/${slug}/org-units`,
      );
      return data;
    },
    create: async (slug: string, body: CreateOrgUnitInput): Promise<OrgUnit> => {
      const { data } = await http.post<OrgUnit>(
        `${API_PREFIX}/c/${slug}/org-units`,
        body,
      );
      return data;
    },
    update: async (
      slug: string,
      id: string,
      body: UpdateOrgUnitInput,
    ): Promise<OrgUnit> => {
      const { data } = await http.patch<OrgUnit>(
        `${API_PREFIX}/c/${slug}/org-units/${id}`,
        body,
      );
      return data;
    },
    remove: async (slug: string, id: string): Promise<{ deleted: true }> => {
      const { data } = await http.delete<{ deleted: true }>(
        `${API_PREFIX}/c/${slug}/org-units/${id}`,
      );
      return data;
    },
    /** Paste-to-create: one parent + type + many names → many sibling units. */
    bulkCreate: async (
      slug: string,
      body: BulkCreateOrgUnitsInput,
    ): Promise<BulkCreateOrgUnitsResponse> => {
      const { data } = await http.post<BulkCreateOrgUnitsResponse>(
        `${API_PREFIX}/c/${slug}/org-units/bulk`,
        body,
      );
      return data;
    },
  },

  /** Faculty accounts for the college (gated by the faculty_management feature). */
  collegeFaculty: {
    list: async (slug: string): Promise<FacultyListResponse> => {
      const { data } = await http.get<FacultyListResponse>(
        `${API_PREFIX}/c/${slug}/faculty`,
      );
      return data;
    },
    create: async (slug: string, body: CreateFacultyInput): Promise<Faculty> => {
      const { data } = await http.post<Faculty>(
        `${API_PREFIX}/c/${slug}/faculty`,
        body,
      );
      return data;
    },
    update: async (
      slug: string,
      id: string,
      body: UpdateFacultyInput,
    ): Promise<Faculty> => {
      const { data } = await http.patch<Faculty>(
        `${API_PREFIX}/c/${slug}/faculty/${id}`,
        body,
      );
      return data;
    },
    /** Soft-deactivate (kills sessions; preserves records). */
    deactivate: async (slug: string, id: string): Promise<Faculty> => {
      const { data } = await http.delete<Faculty>(
        `${API_PREFIX}/c/${slug}/faculty/${id}`,
      );
      return data;
    },
  },

  /**
   * College students + bulk import (Phase 3b). List/add are open to any college
   * member (faculty scope enforced server-side); the import endpoints require the
   * `bulk_import` feature. Both file and paste UIs produce the SAME
   * StudentImportRowInput[] and hit the same preview/commit endpoints.
   */
  collegeStudents: {
    list: async (
      slug: string,
      query: CollegeStudentListQuery = {},
    ): Promise<CollegeStudentListResponse> => {
      const { data } = await http.get<CollegeStudentListResponse>(
        `${API_PREFIX}/c/${slug}/students`,
        { params: query },
      );
      return data;
    },
    create: async (
      slug: string,
      body: CreateCollegeStudentInput,
    ): Promise<CollegeStudent> => {
      const { data } = await http.post<CollegeStudent>(
        `${API_PREFIX}/c/${slug}/students`,
        body,
      );
      return data;
    },
    /** Edit a student's details (name / email / roll / org-unit). */
    update: async (
      slug: string,
      id: string,
      body: UpdateCollegeStudentInput,
    ): Promise<CollegeStudent> => {
      const { data } = await http.patch<CollegeStudent>(
        `${API_PREFIX}/c/${slug}/students/${id}`,
        body,
      );
      return data;
    },
    /** Soft-deactivate a student (kills sessions; preserves records). */
    deactivate: async (slug: string, id: string): Promise<CollegeStudent> => {
      const { data } = await http.delete<CollegeStudent>(
        `${API_PREFIX}/c/${slug}/students/${id}`,
      );
      return data;
    },
    /** Dry-run: per-row verdicts + summary. Writes nothing. */
    importPreview: async (
      slug: string,
      rows: StudentImportRowInput[],
    ): Promise<StudentImportPreviewResponse> => {
      const { data } = await http.post<StudentImportPreviewResponse>(
        `${API_PREFIX}/c/${slug}/students/import/preview`,
        { rows },
      );
      return data;
    },
    /** Create the valid rows; returns created / skipped / failed. */
    importCommit: async (
      slug: string,
      rows: StudentImportRowInput[],
    ): Promise<StudentImportCommitResponse> => {
      const { data } = await http.post<StudentImportCommitResponse>(
        `${API_PREFIX}/c/${slug}/students/import/commit`,
        { rows },
      );
      return data;
    },
    /** Download the sample import CSV (auth cookie rides along). */
    template: async (
      slug: string,
    ): Promise<{ blob: Blob; filename: string }> => {
      const res = await http.get(
        `${API_PREFIX}/c/${slug}/students/import/template`,
        { responseType: "blob" },
      );
      const disposition = String(res.headers["content-disposition"] ?? "");
      const match = /filename="?([^"]+)"?/.exec(disposition);
      return {
        blob: res.data as Blob,
        filename: match?.[1] ?? "student-import-template.csv",
      };
    },
  },

  /**
   * College course assignment (Phase 4a). Assign the super-admin-granted courses
   * to college students (faculty scope enforced server-side); students then learn
   * them through the existing player. Requires the `courses` feature.
   */
  collegeCourses: {
    /** Granted courses + current assignment counts. */
    list: async (slug: string): Promise<CollegeCourseListResponse> => {
      const { data } = await http.get<CollegeCourseListResponse>(
        `${API_PREFIX}/c/${slug}/courses/catalog`,
      );
      return data;
    },
    /** The college students currently assigned a course. */
    assignedStudents: async (
      slug: string,
      courseId: string,
    ): Promise<CourseAssignedStudentsResponse> => {
      const { data } = await http.get<CourseAssignedStudentsResponse>(
        `${API_PREFIX}/c/${slug}/courses/${courseId}/students`,
      );
      return data;
    },
    assign: async (
      slug: string,
      courseId: string,
      studentIds: string[],
    ): Promise<CourseAssignResponse> => {
      const { data } = await http.post<CourseAssignResponse>(
        `${API_PREFIX}/c/${slug}/courses/${courseId}/assign`,
        { studentIds },
      );
      return data;
    },
    revoke: async (
      slug: string,
      courseId: string,
      studentIds: string[],
    ): Promise<CourseRevokeResponse> => {
      const { data } = await http.post<CourseRevokeResponse>(
        `${API_PREFIX}/c/${slug}/courses/${courseId}/revoke`,
        { studentIds },
      );
      return data;
    },
  },

  /**
   * College exams (Phase 4b-ii) — tenant-scoped authoring + results over the
   * REUSED exam engine. Mirrors `adminExams` for the shared authoring surface
   * (section/question/test-case/public-link CRUD, bulk-upload) so the same
   * editor components drive both; the college-specific bits are exam create/edit
   * with org-unit targeting + a draft→published lifecycle, and tenant-scoped
   * JSON results. Requires the `exams` feature (faculty scope enforced server-
   * side). The mutation shapes match `ExamAuthoringApi` so a slug-bound adapter
   * can back the reused dialogs (see lib/exam-authoring-api.ts).
   */
  collegeExams: {
    /** The college's exams (authoring list) — scope-filtered for faculty. */
    list: async (slug: string): Promise<CollegeExamListResponse> => {
      const { data } = await http.get<CollegeExamListResponse>(
        `${API_PREFIX}/c/${slug}/exams/manage`,
      );
      return data;
    },
    /** Create a standalone college exam shell (title + pass % + targeting). */
    create: async (
      slug: string,
      body: CreateCollegeExamInput,
    ): Promise<AdminExamDetail> => {
      const { data } = await http.post<AdminExamDetail>(
        `${API_PREFIX}/c/${slug}/exams`,
        body,
      );
      return data;
    },
    /** Full authored tree (sections → questions → test cases), incl. answers. */
    get: async (slug: string, examId: string): Promise<AdminExamDetail> => {
      const { data } = await http.get<AdminExamDetail>(
        `${API_PREFIX}/c/${slug}/exams/${examId}`,
      );
      return data;
    },
    update: async (
      slug: string,
      examId: string,
      body: UpdateCollegeExamInput,
    ): Promise<AdminExamDetail> => {
      const { data } = await http.patch<AdminExamDetail>(
        `${API_PREFIX}/c/${slug}/exams/${examId}`,
        body,
      );
      return data;
    },
    remove: async (slug: string, examId: string): Promise<{ deleted: true }> => {
      const { data } = await http.delete<{ deleted: true }>(
        `${API_PREFIX}/c/${slug}/exams/${examId}`,
      );
      return data;
    },
    /** Publish / unpublish (publish requires ≥1 question — server-enforced). */
    setPublished: async (
      slug: string,
      examId: string,
      isPublished: boolean,
    ): Promise<AdminExamDetail> => {
      const { data } = await http.post<AdminExamDetail>(
        `${API_PREFIX}/c/${slug}/exams/${examId}/publish`,
        { isPublished },
      );
      return data;
    },
    /** Tenant-scoped per-student results (no xlsx — JSON table). */
    results: async (
      slug: string,
      examId: string,
    ): Promise<CollegeExamResultsResponse> => {
      const { data } = await http.get<CollegeExamResultsResponse>(
        `${API_PREFIX}/c/${slug}/exams/${examId}/results`,
      );
      return data;
    },
    // --- Student take surface (Phase 4b-ii-B) ---
    /**
     * The published, org-unit-targeted exams THIS student may take (same
     * ExamListItem shape as the individual `api.exams.list`, so the same list
     * cards + runner reuse it). Member + `exams` feature; the backend filters by
     * publish state + the student's cohort.
     */
    studentList: async (slug: string): Promise<ExamListResponse> => {
      const { data } = await http.get<ExamListResponse>(
        `${API_PREFIX}/c/${slug}/exams`,
      );
      return data;
    },
    /**
     * Start a college-exam attempt (tenant-scoped). Returns the SAME
     * StartAttemptResponse the individual start does, so the shared runner +
     * /attempts/* engine take over unchanged from here.
     */
    studentStart: async (
      slug: string,
      examId: string,
    ): Promise<StartAttemptResponse> => {
      const { data } = await http.post<StartAttemptResponse>(
        `${API_PREFIX}/c/${slug}/exams/${examId}/attempts`,
      );
      return data;
    },
    /** Per-user attempt-counter reset (audited, tenant-scoped). */
    resetAttempts: async (
      slug: string,
      examId: string,
      body: AdminResetAttemptsRequest,
    ): Promise<{ attemptCount: number; maxAttempts: number }> => {
      const { data } = await http.post<{
        attemptCount: number;
        maxAttempts: number;
      }>(`${API_PREFIX}/c/${slug}/exams/${examId}/reset-attempts`, body);
      return data;
    },
    // --- Authoring CRUD (matches ExamAuthoringApi; delegates to the engine) ---
    createSection: async (
      slug: string,
      examId: string,
      body: AdminSectionUpsert,
    ): Promise<AdminExamDetail> => {
      const { data } = await http.post<AdminExamDetail>(
        `${API_PREFIX}/c/${slug}/exams/${examId}/sections`,
        body,
      );
      return data;
    },
    updateSection: async (
      slug: string,
      sectionId: string,
      body: AdminSectionUpsert,
    ): Promise<AdminExamDetail> => {
      const { data } = await http.patch<AdminExamDetail>(
        `${API_PREFIX}/c/${slug}/exam-sections/${sectionId}`,
        body,
      );
      return data;
    },
    deleteSection: async (slug: string, sectionId: string): Promise<void> => {
      await http.delete(`${API_PREFIX}/c/${slug}/exam-sections/${sectionId}`);
    },
    createQuestion: async (
      slug: string,
      body: AdminQuestionUpsert,
    ): Promise<{ id: string }> => {
      const { data } = await http.post<{ id: string }>(
        `${API_PREFIX}/c/${slug}/exam-questions`,
        body,
      );
      return data;
    },
    updateQuestion: async (
      slug: string,
      questionId: string,
      body: AdminQuestionUpsert,
    ): Promise<{ id: string }> => {
      const { data } = await http.patch<{ id: string }>(
        `${API_PREFIX}/c/${slug}/exam-questions/${questionId}`,
        body,
      );
      return data;
    },
    deleteQuestion: async (slug: string, questionId: string): Promise<void> => {
      await http.delete(`${API_PREFIX}/c/${slug}/exam-questions/${questionId}`);
    },
    addTestCase: async (
      slug: string,
      questionId: string,
      body: AdminTestCaseUpsert,
    ): Promise<{ id: string }> => {
      const { data } = await http.post<{ id: string }>(
        `${API_PREFIX}/c/${slug}/exam-questions/${questionId}/test-cases`,
        body,
      );
      return data;
    },
    updateTestCase: async (
      slug: string,
      testCaseId: string,
      body: AdminTestCaseUpsert,
    ): Promise<{ id: string }> => {
      const { data } = await http.patch<{ id: string }>(
        `${API_PREFIX}/c/${slug}/exam-test-cases/${testCaseId}`,
        body,
      );
      return data;
    },
    deleteTestCase: async (slug: string, testCaseId: string): Promise<void> => {
      await http.delete(`${API_PREFIX}/c/${slug}/exam-test-cases/${testCaseId}`);
    },
    bulkUpload: async (
      slug: string,
      examId: string,
      fileBase64: string,
      kind: ExamBulkUploadKind,
    ): Promise<ExcelUploadResponse> => {
      const { data } = await http.post<ExcelUploadResponse>(
        `${API_PREFIX}/c/${slug}/exams/${examId}/bulk-upload`,
        { fileBase64, kind },
      );
      return data;
    },
    /** Download the ready-to-fill MCQ or coding .xlsx template (tenant-gated). */
    bulkUploadTemplate: async (
      slug: string,
      kind: ExamBulkUploadKind,
    ): Promise<{ blob: Blob; filename: string }> => {
      const res = await http.get(
        `${API_PREFIX}/c/${slug}/exams/bulk-upload-template`,
        { params: { kind }, responseType: "blob" },
      );
      const disposition = String(res.headers["content-disposition"] ?? "");
      const match = /filename="?([^"]+)"?/.exec(disposition);
      return {
        blob: res.data as Blob,
        filename: match?.[1] ?? `${kind}-questions-template.xlsx`,
      };
    },
    createPublicLink: async (
      slug: string,
      examId: string,
      body: AdminPublicLinkUpsert,
    ): Promise<PublicLink> => {
      const { data } = await http.post<PublicLink>(
        `${API_PREFIX}/c/${slug}/exams/${examId}/public-links`,
        body,
      );
      return data;
    },
    updatePublicLink: async (
      slug: string,
      linkId: string,
      body: AdminPublicLinkUpsert,
    ): Promise<PublicLink> => {
      const { data } = await http.patch<PublicLink>(
        `${API_PREFIX}/c/${slug}/exam-public-links/${linkId}`,
        body,
      );
      return data;
    },
    deletePublicLink: async (slug: string, linkId: string): Promise<void> => {
      await http.delete(`${API_PREFIX}/c/${slug}/exam-public-links/${linkId}`);
    },
  },

  /**
   * College essay AUTHORING (Phase 4c-ii) — tenant-scoped over the REUSED essay
   * engine. Mirrors `adminEssayTopics` for the shared authoring surface (topic
   * CRUD + keyword generation) so the same editor dialog drives both via an
   * injected adapter (see lib/essay-authoring-api.ts); the college-specific bits
   * are org-unit targeting + a draft→published lifecycle + tenant-scoped results.
   * Requires the `essays` feature (faculty scope enforced server-side).
   */
  collegeEssayTopics: {
    list: async (slug: string): Promise<CollegeEssayListResponse> => {
      const { data } = await http.get<CollegeEssayListResponse>(
        `${API_PREFIX}/c/${slug}/essay-topics`,
      );
      return data;
    },
    create: async (
      slug: string,
      body: CreateCollegeEssayInput,
    ): Promise<AdminEssayTopic> => {
      const { data } = await http.post<AdminEssayTopic>(
        `${API_PREFIX}/c/${slug}/essay-topics`,
        body,
      );
      return data;
    },
    get: async (slug: string, id: string): Promise<AdminEssayTopic> => {
      const { data } = await http.get<AdminEssayTopic>(
        `${API_PREFIX}/c/${slug}/essay-topics/${id}`,
      );
      return data;
    },
    update: async (
      slug: string,
      id: string,
      body: CreateCollegeEssayInput,
    ): Promise<AdminEssayTopic> => {
      const { data } = await http.patch<AdminEssayTopic>(
        `${API_PREFIX}/c/${slug}/essay-topics/${id}`,
        body,
      );
      return data;
    },
    setPublished: async (
      slug: string,
      id: string,
      isPublished: boolean,
    ): Promise<AdminEssayTopic> => {
      const { data } = await http.post<AdminEssayTopic>(
        `${API_PREFIX}/c/${slug}/essay-topics/${id}/publish`,
        { isPublished },
      );
      return data;
    },
    remove: async (slug: string, id: string): Promise<{ deleted: true }> => {
      const { data } = await http.delete<{ deleted: true }>(
        `${API_PREFIX}/c/${slug}/essay-topics/${id}`,
      );
      return data;
    },
    results: async (
      slug: string,
      id: string,
    ): Promise<CollegeEssayResultsResponse> => {
      const { data } = await http.get<CollegeEssayResultsResponse>(
        `${API_PREFIX}/c/${slug}/essay-topics/${id}/results`,
      );
      return data;
    },
    generateKeywords: async (
      slug: string,
      body: GenerateKeywordsRequest,
    ): Promise<GenerateKeywordsResponse> => {
      const { data } = await http.post<GenerateKeywordsResponse>(
        `${API_PREFIX}/c/${slug}/essay-topics/generate-keywords`,
        body,
      );
      return data;
    },
  },

  /**
   * College essay WRITING (Phase 4c-ii) — the student surface. Same DTOs as the
   * individual `api.essays` (so the same list card + writer reuse it); only the
   * list/detail/draft/submit/submissions are tenant-scoped. The grading-status
   * POLL + analytics stay on the SHARED `api.essays` endpoints (authorized by
   * attempt ownership), so a college attempt rides them unchanged.
   */
  collegeEssays: {
    studentList: async (slug: string): Promise<EssayListResponse> => {
      const { data } = await http.get<EssayListResponse>(
        `${API_PREFIX}/c/${slug}/essays`,
      );
      return data;
    },
    detail: async (slug: string, id: string): Promise<EssayPromptDetail> => {
      const { data } = await http.get<EssayPromptDetail>(
        `${API_PREFIX}/c/${slug}/essays/${id}`,
      );
      return data;
    },
    draftGet: async (slug: string, id: string): Promise<EssayDraftResponse> => {
      const { data } = await http.get<EssayDraftResponse>(
        `${API_PREFIX}/c/${slug}/essays/${id}/draft`,
      );
      return data;
    },
    draftPut: async (
      slug: string,
      id: string,
      content: string,
    ): Promise<SaveEssayDraftResponse> => {
      const { data } = await http.put<SaveEssayDraftResponse>(
        `${API_PREFIX}/c/${slug}/essays/${id}/draft`,
        { content },
      );
      return data;
    },
    submit: async (
      slug: string,
      id: string,
      content: string,
    ): Promise<JobRef> => {
      const { data } = await http.post<JobRef>(
        `${API_PREFIX}/c/${slug}/essays/${id}/submit`,
        { content },
      );
      return data;
    },
    submissions: async (
      slug: string,
      id: string,
    ): Promise<EssaySubmissionListResponse> => {
      const { data } = await http.get<EssaySubmissionListResponse>(
        `${API_PREFIX}/c/${slug}/essays/${id}/submissions`,
      );
      return data;
    },
  },

  /**
   * College challenges (Phase 4d) — a tenant-scoped LEADERBOARD over the shared
   * daily-challenge engine (no per-college authoring/assignment: the daily
   * challenge is global). Requires the `challenges` feature; an operator view of
   * the college's own students' standings.
   */
  collegeChallenges: {
    leaderboard: async (
      slug: string,
      query: { page?: number; pageSize?: number } = {},
    ): Promise<CollegeChallengeLeaderboardResponse> => {
      const { data } = await http.get<CollegeChallengeLeaderboardResponse>(
        `${API_PREFIX}/c/${slug}/challenges/leaderboard`,
        { params: query },
      );
      return data;
    },
  },

  /**
   * College analytics (Phase 5a-ii) — tenant + faculty-scoped READ-ONLY rollups
   * of student performance (exams/essays/courses/challenges) three ways. Requires
   * the `analytics` feature; the backend enforces faculty org-unit scope.
   */
  collegeAnalytics: {
    overview: async (slug: string): Promise<CollegeAnalyticsOverview> => {
      const { data } = await http.get<CollegeAnalyticsOverview>(
        `${API_PREFIX}/c/${slug}/analytics/overview`,
      );
      return data;
    },
    byOrgUnit: async (
      slug: string,
    ): Promise<CollegeAnalyticsByUnitResponse> => {
      const { data } = await http.get<CollegeAnalyticsByUnitResponse>(
        `${API_PREFIX}/c/${slug}/analytics/by-org-unit`,
      );
      return data;
    },
    student: async (
      slug: string,
      studentId: string,
    ): Promise<CollegeAnalyticsStudent> => {
      const { data } = await http.get<CollegeAnalyticsStudent>(
        `${API_PREFIX}/c/${slug}/analytics/students/${studentId}`,
      );
      return data;
    },
  },

  /**
   * College postings AUTHORING + the student browse/apply surface (Phase 5b) —
   * tenant-scoped over the REUSED careers engine. Mirrors `adminCareers` for the
   * shared authoring surface (posting CRUD + applications review) so the same
   * PostingEditorDialog drives both via an injected adapter (see
   * lib/careers-authoring-api.ts); the college-specific bits are org-unit
   * targeting + a draft→published lifecycle. Requires the `postings` feature
   * (faculty scope enforced server-side).
   */
  collegeCareers: {
    // --- Authoring (faculty/college_admin) ---
    list: async (slug: string): Promise<CollegePostingListResponse> => {
      const { data } = await http.get<CollegePostingListResponse>(
        `${API_PREFIX}/c/${slug}/postings`,
      );
      return data;
    },
    get: async (slug: string, id: string): Promise<AdminPosting> => {
      const { data } = await http.get<AdminPosting>(
        `${API_PREFIX}/c/${slug}/postings/${id}`,
      );
      return data;
    },
    create: async (
      slug: string,
      body: CreateCollegePostingInput,
    ): Promise<AdminPosting> => {
      const { data } = await http.post<AdminPosting>(
        `${API_PREFIX}/c/${slug}/postings`,
        body,
      );
      return data;
    },
    update: async (
      slug: string,
      id: string,
      body: CreateCollegePostingInput,
    ): Promise<AdminPosting> => {
      const { data } = await http.patch<AdminPosting>(
        `${API_PREFIX}/c/${slug}/postings/${id}`,
        body,
      );
      return data;
    },
    setPublished: async (
      slug: string,
      id: string,
      isPublished: boolean,
    ): Promise<CollegePostingSummary> => {
      const { data } = await http.post<CollegePostingSummary>(
        `${API_PREFIX}/c/${slug}/postings/${id}/publish`,
        { isPublished },
      );
      return data;
    },
    remove: async (slug: string, id: string): Promise<{ deleted: true }> => {
      const { data } = await http.delete<{ deleted: true }>(
        `${API_PREFIX}/c/${slug}/postings/${id}`,
      );
      return data;
    },
    applications: async (
      slug: string,
      id: string,
    ): Promise<AdminApplicationListResponse> => {
      const { data } = await http.get<AdminApplicationListResponse>(
        `${API_PREFIX}/c/${slug}/postings/${id}/applications`,
      );
      return data;
    },
    updateApplicationStatus: async (
      slug: string,
      appId: string,
      status: JobApplicationStatus,
    ): Promise<{ id: string; status: JobApplicationStatus }> => {
      const { data } = await http.patch<{
        id: string;
        status: JobApplicationStatus;
      }>(`${API_PREFIX}/c/${slug}/posting-applications/${appId}`, { status });
      return data;
    },
    // --- Student browse + apply (member; ?c=<slug> seam on the learner pages) ---
    studentList: async (
      slug: string,
    ): Promise<CollegeStudentPostingListResponse> => {
      const { data } = await http.get<CollegeStudentPostingListResponse>(
        `${API_PREFIX}/c/${slug}/careers`,
      );
      return data;
    },
    studentGet: async (slug: string, id: string): Promise<PostingDetail> => {
      const { data } = await http.get<PostingDetail>(
        `${API_PREFIX}/c/${slug}/careers/${id}`,
      );
      return data;
    },
    studentApply: async (
      slug: string,
      id: string,
      body: ApplyRequest,
    ): Promise<ApplicationResponse> => {
      const { data } = await http.post<ApplicationResponse>(
        `${API_PREFIX}/c/${slug}/careers/${id}/apply`,
        body,
      );
      return data;
    },
  },

  adminEssayTopics: {
    list: async (): Promise<AdminEssayTopicListResponse> => {
      const { data } = await http.get<AdminEssayTopicListResponse>(
        `${API_PREFIX}/admin/essay-topics`,
      );
      return data;
    },
    get: async (id: string): Promise<AdminEssayTopic> => {
      const { data } = await http.get<AdminEssayTopic>(
        `${API_PREFIX}/admin/essay-topics/${id}`,
      );
      return data;
    },
    create: async (body: AdminEssayTopicUpsert): Promise<AdminEssayTopic> => {
      const { data } = await http.post<AdminEssayTopic>(
        `${API_PREFIX}/admin/essay-topics`,
        body,
      );
      return data;
    },
    update: async (
      id: string,
      body: AdminEssayTopicUpsert,
    ): Promise<AdminEssayTopic> => {
      const { data } = await http.patch<AdminEssayTopic>(
        `${API_PREFIX}/admin/essay-topics/${id}`,
        body,
      );
      return data;
    },
    setActive: async (id: string, isActive: boolean): Promise<AdminEssayTopic> => {
      const { data } = await http.post<AdminEssayTopic>(
        `${API_PREFIX}/admin/essay-topics/${id}/active`,
        { isActive },
      );
      return data;
    },
    remove: async (id: string): Promise<{ deleted: true }> => {
      const { data } = await http.delete<{ deleted: true }>(
        `${API_PREFIX}/admin/essay-topics/${id}`,
      );
      return data;
    },
    /** Propose semantic keywords (LLM-assisted; deterministic fallback). */
    generateKeywords: async (
      body: GenerateKeywordsRequest,
    ): Promise<GenerateKeywordsResponse> => {
      const { data } = await http.post<GenerateKeywordsResponse>(
        `${API_PREFIX}/admin/essay-topics/generate-keywords`,
        body,
      );
      return data;
    },
  },

  adminChallenges: {
    list: async (): Promise<AdminChallengeListResponse> => {
      const { data } = await http.get<AdminChallengeListResponse>(
        `${API_PREFIX}/admin/challenges`,
      );
      return data;
    },
    get: async (id: string): Promise<AdminChallenge> => {
      const { data } = await http.get<AdminChallenge>(
        `${API_PREFIX}/admin/challenges/${id}`,
      );
      return data;
    },
    create: async (body: AdminChallengeUpsert): Promise<AdminChallenge> => {
      const { data } = await http.post<AdminChallenge>(
        `${API_PREFIX}/admin/challenges`,
        body,
      );
      return data;
    },
    update: async (
      id: string,
      body: AdminChallengeUpsert,
    ): Promise<AdminChallenge> => {
      const { data } = await http.patch<AdminChallenge>(
        `${API_PREFIX}/admin/challenges/${id}`,
        body,
      );
      return data;
    },
    remove: async (id: string): Promise<{ deleted: true }> => {
      const { data } = await http.delete<{ deleted: true }>(
        `${API_PREFIX}/admin/challenges/${id}`,
      );
      return data;
    },
    bulkImport: async (
      fileBase64: string,
      startDate?: string,
    ): Promise<AdminChallengeBulkImportResponse> => {
      const { data } = await http.post<AdminChallengeBulkImportResponse>(
        `${API_PREFIX}/admin/challenges/bulk-import`,
        { fileBase64, ...(startDate ? { startDate } : {}) },
      );
      return data;
    },
    /** Download the ready-to-fill daily-challenge .xlsx template. */
    bulkImportTemplate: async (): Promise<{ blob: Blob; filename: string }> => {
      const res = await http.get(
        `${API_PREFIX}/admin/challenges/bulk-import-template`,
        { responseType: "blob" },
      );
      const disposition = String(res.headers["content-disposition"] ?? "");
      const match = /filename="?([^"]+)"?/.exec(disposition);
      return {
        blob: res.data as Blob,
        filename: match?.[1] ?? "daily-challenges-template.xlsx",
      };
    },
  },

  adminUsers: {
    list: async (
      params: Partial<AdminUserListQuery> = {},
    ): Promise<AdminUserListResponse> => {
      const { data } = await http.get<AdminUserListResponse>(
        `${API_PREFIX}/admin/users`,
        { params },
      );
      return data;
    },
    get: async (id: string): Promise<AdminUserDetail> => {
      const { data } = await http.get<AdminUserDetail>(
        `${API_PREFIX}/admin/users/${id}`,
      );
      return data;
    },
    setActive: async (
      id: string,
      isActive: boolean,
    ): Promise<AdminUserDetail> => {
      const { data } = await http.post<AdminUserDetail>(
        `${API_PREFIX}/admin/users/${id}/active`,
        { isActive },
      );
      return data;
    },
    setRole: async (id: string, role: Role): Promise<AdminUserDetail> => {
      const { data } = await http.post<AdminUserDetail>(
        `${API_PREFIX}/admin/users/${id}/role`,
        { role },
      );
      return data;
    },
    updateProfile: async (
      id: string,
      body: AdminUpdateProfile,
    ): Promise<AdminUserDetail> => {
      const { data } = await http.patch<AdminUserDetail>(
        `${API_PREFIX}/admin/users/${id}/profile`,
        body,
      );
      return data;
    },
    unenroll: async (
      id: string,
      enrollmentId: string,
    ): Promise<AdminUserDetail> => {
      const { data } = await http.delete<AdminUserDetail>(
        `${API_PREFIX}/admin/users/${id}/enrollments/${enrollmentId}`,
      );
      return data;
    },
    /** Download the per-college performance workbook as a blob (auth cookie rides along). */
    performanceBlob: async (): Promise<{ blob: Blob; filename: string }> => {
      const res = await http.get(
        `${API_PREFIX}/admin/users/college-performance.xlsx`,
        { responseType: "blob" },
      );
      const disposition = String(res.headers["content-disposition"] ?? "");
      const match = /filename="?([^"]+)"?/.exec(disposition);
      return {
        blob: res.data as Blob,
        filename: match?.[1] ?? "college-performance.xlsx",
      };
    },
  },

  adminEssayAnalytics: {
    list: async (
      params: Partial<AdminEssayAnalyticsListQuery> = {},
    ): Promise<AdminEssayAnalyticsListResponse> => {
      const { data } = await http.get<AdminEssayAnalyticsListResponse>(
        `${API_PREFIX}/admin/essay-analytics`,
        { params },
      );
      return data;
    },
    get: async (attemptId: string): Promise<AdminEssayAttemptAnalytics> => {
      const { data } = await http.get<AdminEssayAttemptAnalytics>(
        `${API_PREFIX}/admin/essay-analytics/${attemptId}`,
      );
      return data;
    },
  },

  adminOrders: {
    list: async (
      params: Partial<AdminOrderListQuery> = {},
    ): Promise<AdminOrderListResponse> => {
      const { data } = await http.get<AdminOrderListResponse>(
        `${API_PREFIX}/admin/orders`,
        { params },
      );
      return data;
    },
    get: async (id: string): Promise<AdminOrderDetail> => {
      const { data } = await http.get<AdminOrderDetail>(
        `${API_PREFIX}/admin/orders/${id}`,
      );
      return data;
    },
  },

  uploads: {
    /** Ask the API for a short-lived Cloudinary upload signature (admin-only). */
    signature: async (): Promise<UploadSignatureResponse> => {
      const { data } = await http.post<UploadSignatureResponse>(
        `${API_PREFIX}/admin/uploads/signature`,
      );
      return data;
    },
  },

  adminExams: {
    /** Every exam (regardless of enrollment) with cheap section/question counts. */
    list: async (): Promise<AdminExamListResponse> => {
      const { data } = await http.get<AdminExamListResponse>(
        `${API_PREFIX}/admin/exams`,
      );
      return data;
    },
    /** Full authored exam tree (sections → questions → test cases), incl. answers. */
    get: async (examId: string): Promise<AdminExamDetail> => {
      const { data } = await http.get<AdminExamDetail>(
        `${API_PREFIX}/admin/exams/${examId}`,
      );
      return data;
    },
    /** Create/update an exam (upsert, keyed by its Topic). Returns the tree. */
    upsert: async (body: AdminExamUpsert): Promise<AdminExamDetail> => {
      const { data } = await http.post<AdminExamDetail>(
        `${API_PREFIX}/admin/exams`,
        body,
      );
      return data;
    },
    deleteExam: async (examId: string): Promise<{ deleted: true }> => {
      const { data } = await http.delete<{ deleted: true }>(
        `${API_PREFIX}/admin/exams/${examId}`,
      );
      return data;
    },
    createSection: async (
      examId: string,
      body: AdminSectionUpsert,
    ): Promise<AdminExamDetail> => {
      const { data } = await http.post<AdminExamDetail>(
        `${API_PREFIX}/admin/exams/${examId}/sections`,
        body,
      );
      return data;
    },
    updateSection: async (
      sectionId: string,
      body: AdminSectionUpsert,
    ): Promise<AdminExamDetail> => {
      const { data } = await http.patch<AdminExamDetail>(
        `${API_PREFIX}/admin/sections/${sectionId}`,
        body,
      );
      return data;
    },
    deleteSection: async (sectionId: string): Promise<void> => {
      await http.delete(`${API_PREFIX}/admin/sections/${sectionId}`);
    },
    createQuestion: async (
      body: AdminQuestionUpsert,
    ): Promise<{ id: string }> => {
      const { data } = await http.post<{ id: string }>(
        `${API_PREFIX}/admin/exam-questions`,
        body,
      );
      return data;
    },
    updateQuestion: async (
      questionId: string,
      body: AdminQuestionUpsert,
    ): Promise<{ id: string }> => {
      const { data } = await http.patch<{ id: string }>(
        `${API_PREFIX}/admin/exam-questions/${questionId}`,
        body,
      );
      return data;
    },
    deleteQuestion: async (questionId: string): Promise<void> => {
      await http.delete(`${API_PREFIX}/admin/exam-questions/${questionId}`);
    },
    addTestCase: async (
      questionId: string,
      body: AdminTestCaseUpsert,
    ): Promise<{ id: string }> => {
      const { data } = await http.post<{ id: string }>(
        `${API_PREFIX}/admin/exam-questions/${questionId}/test-cases`,
        body,
      );
      return data;
    },
    updateTestCase: async (
      testCaseId: string,
      body: AdminTestCaseUpsert,
    ): Promise<{ id: string }> => {
      const { data } = await http.patch<{ id: string }>(
        `${API_PREFIX}/admin/test-cases/${testCaseId}`,
        body,
      );
      return data;
    },
    deleteTestCase: async (testCaseId: string): Promise<void> => {
      await http.delete(`${API_PREFIX}/admin/test-cases/${testCaseId}`);
    },
    // --- Power features (Step 2b) ---
    /** Bulk-upload MCQ or coding questions from a base64-encoded .xlsx workbook. */
    bulkUpload: async (
      examId: string,
      fileBase64: string,
      kind: ExamBulkUploadKind,
    ): Promise<ExcelUploadResponse> => {
      const { data } = await http.post<ExcelUploadResponse>(
        `${API_PREFIX}/admin/exams/${examId}/bulk-upload`,
        { fileBase64, kind },
      );
      return data;
    },
    /** Download the ready-to-fill MCQ or coding .xlsx template. */
    bulkUploadTemplate: async (
      kind: ExamBulkUploadKind,
    ): Promise<{ blob: Blob; filename: string }> => {
      const res = await http.get(
        `${API_PREFIX}/admin/exams/bulk-upload-template`,
        { params: { kind }, responseType: "blob" },
      );
      const disposition = String(res.headers["content-disposition"] ?? "");
      const match = /filename="?([^"]+)"?/.exec(disposition);
      return {
        blob: res.data as Blob,
        filename: match?.[1] ?? `${kind}-questions-template.xlsx`,
      };
    },
    createPublicLink: async (
      examId: string,
      body: AdminPublicLinkUpsert,
    ): Promise<PublicLink> => {
      const { data } = await http.post<PublicLink>(
        `${API_PREFIX}/admin/exams/${examId}/public-links`,
        body,
      );
      return data;
    },
    updatePublicLink: async (
      linkId: string,
      body: AdminPublicLinkUpsert,
    ): Promise<PublicLink> => {
      const { data } = await http.patch<PublicLink>(
        `${API_PREFIX}/admin/public-links/${linkId}`,
        body,
      );
      return data;
    },
    deletePublicLink: async (linkId: string): Promise<void> => {
      await http.delete(`${API_PREFIX}/admin/public-links/${linkId}`);
    },
    /** Per-user attempt-counter reset (audited). Returns the reset counter. */
    resetAttempts: async (
      examId: string,
      body: AdminResetAttemptsRequest,
    ): Promise<{ attemptCount: number; maxAttempts: number }> => {
      const { data } = await http.post<{
        attemptCount: number;
        maxAttempts: number;
      }>(`${API_PREFIX}/admin/exams/${examId}/reset-attempts`, body);
      return data;
    },
    /** Attempt-management reads (item C4). */
    attemptCounters: async (
      examId: string,
    ): Promise<AdminExamAttemptCountersResponse> => {
      const { data } = await http.get<AdminExamAttemptCountersResponse>(
        `${API_PREFIX}/admin/exams/${examId}/attempt-counters`,
      );
      return data;
    },
    userAttempts: async (
      examId: string,
      userId: string,
    ): Promise<AdminUserExamAttemptsResponse> => {
      const { data } = await http.get<AdminUserExamAttemptsResponse>(
        `${API_PREFIX}/admin/exams/${examId}/users/${userId}/attempts`,
      );
      return data;
    },
    resetLog: async (examId: string): Promise<AdminExamResetLogResponse> => {
      const { data } = await http.get<AdminExamResetLogResponse>(
        `${API_PREFIX}/admin/exams/${examId}/reset-log`,
      );
      return data;
    },
    /** Download the results workbook as a blob (auth cookie rides along). */
    resultsBlob: async (
      examId: string,
    ): Promise<{ blob: Blob; filename: string }> => {
      const res = await http.get(
        `${API_PREFIX}/admin/exams/${examId}/results.xlsx`,
        { responseType: "blob" },
      );
      const disposition = String(res.headers["content-disposition"] ?? "");
      const match = /filename="?([^"]+)"?/.exec(disposition);
      return {
        blob: res.data as Blob,
        filename: match?.[1] ?? `results-${examId}.xlsx`,
      };
    },
  },

  adminCurriculum: {
    programs: {
      list: async (): Promise<AdminProgramListResponse> => {
        const { data } = await http.get<AdminProgramListResponse>(
          `${API_PREFIX}/admin/programs`,
        );
        return data;
      },
      get: async (id: string): Promise<AdminProgram> => {
        const { data } = await http.get<AdminProgram>(
          `${API_PREFIX}/admin/programs/${id}`,
        );
        return data;
      },
      create: async (body: AdminProgramUpsert): Promise<AdminProgram> => {
        const { data } = await http.post<AdminProgram>(
          `${API_PREFIX}/admin/programs`,
          body,
        );
        return data;
      },
      update: async (
        id: string,
        body: AdminProgramUpsert,
      ): Promise<AdminProgram> => {
        const { data } = await http.patch<AdminProgram>(
          `${API_PREFIX}/admin/programs/${id}`,
          body,
        );
        return data;
      },
      remove: async (id: string): Promise<{ deleted: true }> => {
        const { data } = await http.delete<{ deleted: true }>(
          `${API_PREFIX}/admin/programs/${id}`,
        );
        return data;
      },
      /** Reorder by supplying the full ordered id array (order = index). */
      reorder: async (ids: string[]): Promise<AdminProgramListResponse> => {
        const body: AdminReorder = { ids };
        const { data } = await http.post<AdminProgramListResponse>(
          `${API_PREFIX}/admin/programs/reorder`,
          body,
        );
        return data;
      },
    },
    subjects: {
      /** All subjects (admin projection); optionally filtered to one program. */
      list: async (programId?: string): Promise<AdminSubjectListResponse> => {
        const { data } = await http.get<AdminSubjectListResponse>(
          `${API_PREFIX}/admin/subjects`,
          { params: programId ? { programId } : {} },
        );
        return data;
      },
      get: async (id: string): Promise<AdminSubject> => {
        const { data } = await http.get<AdminSubject>(
          `${API_PREFIX}/admin/subjects/${id}`,
        );
        return data;
      },
      create: async (body: AdminSubjectUpsert): Promise<AdminSubject> => {
        const { data } = await http.post<AdminSubject>(
          `${API_PREFIX}/admin/subjects`,
          body,
        );
        return data;
      },
      update: async (
        id: string,
        body: AdminSubjectUpsert,
      ): Promise<AdminSubject> => {
        const { data } = await http.patch<AdminSubject>(
          `${API_PREFIX}/admin/subjects/${id}`,
          body,
        );
        return data;
      },
      remove: async (id: string): Promise<{ deleted: true }> => {
        const { data } = await http.delete<{ deleted: true }>(
          `${API_PREFIX}/admin/subjects/${id}`,
        );
        return data;
      },
    },
    modules: {
      /** Modules under a subject (ordered). */
      list: async (subjectId: string): Promise<AdminModuleListResponse> => {
        const { data } = await http.get<AdminModuleListResponse>(
          `${API_PREFIX}/admin/subjects/${subjectId}/modules`,
        );
        return data;
      },
      create: async (
        subjectId: string,
        body: AdminModuleUpsert,
      ): Promise<AdminModule> => {
        const { data } = await http.post<AdminModule>(
          `${API_PREFIX}/admin/subjects/${subjectId}/modules`,
          body,
        );
        return data;
      },
      update: async (
        moduleId: string,
        body: AdminModuleUpsert,
      ): Promise<AdminModule> => {
        const { data } = await http.patch<AdminModule>(
          `${API_PREFIX}/admin/modules/${moduleId}`,
          body,
        );
        return data;
      },
      remove: async (moduleId: string): Promise<{ deleted: true }> => {
        const { data } = await http.delete<{ deleted: true }>(
          `${API_PREFIX}/admin/modules/${moduleId}`,
        );
        return data;
      },
      /** Reorder a subject's modules by the full ordered id array. */
      reorder: async (
        subjectId: string,
        ids: string[],
      ): Promise<AdminModuleListResponse> => {
        const body: AdminReorder = { ids };
        const { data } = await http.post<AdminModuleListResponse>(
          `${API_PREFIX}/admin/subjects/${subjectId}/modules/reorder`,
          body,
        );
        return data;
      },
    },
    topics: {
      /** Topics under a module (ordered). */
      list: async (moduleId: string): Promise<AdminTopicListResponse> => {
        const { data } = await http.get<AdminTopicListResponse>(
          `${API_PREFIX}/admin/modules/${moduleId}/topics`,
        );
        return data;
      },
      get: async (topicId: string): Promise<AdminTopic> => {
        const { data } = await http.get<AdminTopic>(
          `${API_PREFIX}/admin/topics/${topicId}`,
        );
        return data;
      },
      create: async (
        moduleId: string,
        body: AdminTopicUpsert,
      ): Promise<AdminTopic> => {
        const { data } = await http.post<AdminTopic>(
          `${API_PREFIX}/admin/modules/${moduleId}/topics`,
          body,
        );
        return data;
      },
      update: async (
        topicId: string,
        body: AdminTopicUpsert,
      ): Promise<AdminTopic> => {
        const { data } = await http.patch<AdminTopic>(
          `${API_PREFIX}/admin/topics/${topicId}`,
          body,
        );
        return data;
      },
      remove: async (topicId: string): Promise<{ deleted: true }> => {
        const { data } = await http.delete<{ deleted: true }>(
          `${API_PREFIX}/admin/topics/${topicId}`,
        );
        return data;
      },
      /** Reorder a module's topics by the full ordered id array. */
      reorder: async (
        moduleId: string,
        ids: string[],
      ): Promise<AdminTopicListResponse> => {
        const body: AdminReorder = { ids };
        const { data } = await http.post<AdminTopicListResponse>(
          `${API_PREFIX}/admin/modules/${moduleId}/topics/reorder`,
          body,
        );
        return data;
      },
      /** Bulk-import text/video topics from a base64 .xlsx (per-row report). */
      bulkUpload: async (
        subjectId: string,
        fileBase64: string,
      ): Promise<TopicExcelUploadResponse> => {
        const { data } = await http.post<TopicExcelUploadResponse>(
          `${API_PREFIX}/admin/subjects/${subjectId}/topics/bulk-upload`,
          { fileBase64 },
        );
        return data;
      },
      /** Download the ready-to-fill topics .xlsx template. */
      bulkUploadTemplate: async (): Promise<{
        blob: Blob;
        filename: string;
      }> => {
        const res = await http.get(`${API_PREFIX}/admin/topics/import-template`, {
          responseType: "blob",
        });
        const disposition = String(res.headers["content-disposition"] ?? "");
        const match = /filename="?([^"]+)"?/.exec(disposition);
        return {
          blob: res.data as Blob,
          filename: match?.[1] ?? "topics-template.xlsx",
        };
      },
    },
    questions: {
      /** Quiz questions (with their choices) for a quiz-type topic. */
      list: async (
        topicId: string,
      ): Promise<AdminQuizQuestionListResponse> => {
        const { data } = await http.get<AdminQuizQuestionListResponse>(
          `${API_PREFIX}/admin/topics/${topicId}/questions`,
        );
        return data;
      },
      create: async (
        topicId: string,
        body: AdminQuizQuestionUpsert,
      ): Promise<AdminQuizQuestion> => {
        const { data } = await http.post<AdminQuizQuestion>(
          `${API_PREFIX}/admin/topics/${topicId}/questions`,
          body,
        );
        return data;
      },
      update: async (
        questionId: string,
        body: AdminQuizQuestionUpsert,
      ): Promise<AdminQuizQuestion> => {
        const { data } = await http.patch<AdminQuizQuestion>(
          `${API_PREFIX}/admin/questions/${questionId}`,
          body,
        );
        return data;
      },
      remove: async (questionId: string): Promise<{ deleted: true }> => {
        const { data } = await http.delete<{ deleted: true }>(
          `${API_PREFIX}/admin/questions/${questionId}`,
        );
        return data;
      },
    },
    /** Exam-type topics with Subject›Module›Topic labels — feeds the exam picker. */
    examTopics: {
      list: async (): Promise<AdminExamTopicListResponse> => {
        const { data } = await http.get<AdminExamTopicListResponse>(
          `${API_PREFIX}/admin/exam-topics`,
        );
        return data;
      },
    },
    enrollments: {
      /** Provision + enroll students from a base64 .xlsx roster (per-row report). */
      bulkUpload: async (
        subjectIds: string[],
        fileBase64: string,
      ): Promise<BulkEnrollResponse> => {
        const { data } = await http.post<BulkEnrollResponse>(
          `${API_PREFIX}/admin/enrollments/bulk-upload`,
          { subjectIds, fileBase64 },
        );
        return data;
      },
      /** Download the ready-to-fill bulk-enroll roster .xlsx template. */
      bulkUploadTemplate: async (): Promise<{
        blob: Blob;
        filename: string;
      }> => {
        const res = await http.get(
          `${API_PREFIX}/admin/enrollments/bulk-upload-template`,
          { responseType: "blob" },
        );
        const disposition = String(res.headers["content-disposition"] ?? "");
        const match = /filename="?([^"]+)"?/.exec(disposition);
        return {
          blob: res.data as Blob,
          filename: match?.[1] ?? "bulk-enroll-roster-template.xlsx",
        };
      },
    },
  },

  exams: {
    /** Exams the logged-in student can take. */
    list: async (): Promise<ExamListResponse> => {
      const { data } = await http.get<ExamListResponse>(`${API_PREFIX}/exams`);
      return data;
    },
    start: async (examId: string): Promise<StartAttemptResponse> => {
      const { data } = await http.post<StartAttemptResponse>(
        `${API_PREFIX}/exams/${examId}/attempts`,
      );
      return data;
    },
    // --- Attempt engine. `token` (X-Attempt-Token) authorizes anonymous
    //     public takers; logged-in takers rely on the session cookie. ---
    section: async (
      attemptId: string,
      token?: string,
    ): Promise<AttemptSectionView> => {
      const { data } = await http.get<AttemptSectionView>(
        `${API_PREFIX}/attempts/${attemptId}/section`,
        attemptHeaders(token),
      );
      return data;
    },
    saveAnswers: async (
      attemptId: string,
      answers: AnswerInput[],
      token?: string,
      markedForReview?: string[],
    ): Promise<SaveSectionAnswersResponse> => {
      const { data } = await http.post<SaveSectionAnswersResponse>(
        `${API_PREFIX}/attempts/${attemptId}/section/answers`,
        markedForReview ? { answers, markedForReview } : { answers },
        attemptHeaders(token),
      );
      return data;
    },
    advance: async (
      attemptId: string,
      token?: string,
    ): Promise<AttemptSectionView> => {
      const { data } = await http.post<AttemptSectionView>(
        `${API_PREFIX}/attempts/${attemptId}/advance`,
        undefined,
        attemptHeaders(token),
      );
      return data;
    },
    submit: async (
      attemptId: string,
      auto: boolean,
      token?: string,
    ): Promise<ExamResult> => {
      const { data } = await http.post<ExamResult>(
        `${API_PREFIX}/attempts/${attemptId}/submit`,
        { auto },
        attemptHeaders(token),
      );
      return data;
    },
    finalize: async (
      attemptId: string,
      token?: string,
    ): Promise<ExamResult> => {
      const { data } = await http.post<ExamResult>(
        `${API_PREFIX}/attempts/${attemptId}/finalize`,
        undefined,
        attemptHeaders(token),
      );
      return data;
    },
    result: async (attemptId: string, token?: string): Promise<ExamResult> => {
      const { data } = await http.get<ExamResult>(
        `${API_PREFIX}/attempts/${attemptId}/result`,
        attemptHeaders(token),
      );
      return data;
    },
    warning: async (
      attemptId: string,
      token?: string,
    ): Promise<RecordWarningResponse> => {
      const { data } = await http.post<RecordWarningResponse>(
        `${API_PREFIX}/attempts/${attemptId}/warning`,
        undefined,
        attemptHeaders(token),
      );
      return data;
    },
    // --- Public (anonymous) ---
    publicAvailability: async (
      token: string,
    ): Promise<PublicExamAvailability> => {
      const { data } = await http.get<PublicExamAvailability>(
        `${API_PREFIX}/public/exams/${token}`,
      );
      return data;
    },
    publicStart: async (
      token: string,
      body: PublicStartRequest,
    ): Promise<StartAttemptResponse> => {
      const { data } = await http.post<StartAttemptResponse>(
        `${API_PREFIX}/public/exams/${token}/attempts`,
        body,
      );
      return data;
    },
  },
};

/** Attach the X-Attempt-Token header for anonymous attempt authorization. */
function attemptHeaders(token?: string): { headers?: Record<string, string> } {
  return token ? { headers: { "X-Attempt-Token": token } } : {};
}
