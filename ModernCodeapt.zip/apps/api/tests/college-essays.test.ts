/**
 * College essays (Phase 4c) — tenant-scoped authoring + writing over the REUSED
 * essay engine. Proves: authoring behind the `essays` feature (create → publish),
 * keyword generation tenant-scoped, a college student writing + submitting via the
 * reused engine and being graded by the SAME pipeline (worker simulated), drafts +
 * attempt-cap tenant-scoped, tenant-scoped results; feature-off 403; faculty
 * out-of-scope denial; cross-tenant author/read denial; hard isolation (College A's
 * essay is invisible/inaccessible to College B and to individual users, and an
 * individual essay is unaffected); unpublished/not-targeted essays neither listed
 * nor writable. The existing essay suite (essay.test.ts et al.) proves individual
 * essays are byte-for-byte unchanged. supertest + in-memory Mongo, mirroring
 * college-exams.test.ts.
 */
import { JobStatus, Role, UserType } from "@codeapt/shared";
import type { Express } from "express";
import { Types } from "mongoose";
import { beforeAll, describe, expect, it, vi } from "vitest";
import request from "supertest";

// The BullMQ producer is mocked (no Redis in tests); grading is simulated by
// writing the grade onto the EssayAttempt directly — exactly as essay.test.ts does.
vi.mock("../src/lib/execution-queue.js", () => ({
  enqueueCodeJob: vi.fn(async () => undefined),
  enqueueEssayGradingJob: vi.fn(async () => undefined),
  closeQueues: vi.fn(async () => undefined),
  knownQueues: [],
  ESSAY_GRADING_JOB_NAME: "grade-essay",
}));

import { createApp } from "../src/app.js";
import { EssayAttemptModel } from "../src/models/essay.model.js";
import { UserModel } from "../src/models/user.model.js";
import * as colleges from "../src/services/college.service.js";

let app: Express;
beforeAll(() => {
  app = createApp();
});

const TEMP_PW = "CodeApt@123"; // env BULK_ENROLL_DEFAULT_PASSWORD default
const auth = (t: string) => ({ Authorization: `Bearer ${t}` });
const LONG_ESSAY =
  "Climate change is one of the most pressing challenges of our era and it " +
  "demands coordinated action across governments, industry, and individuals " +
  "who together can reduce emissions and build a more sustainable future.";

let counter = 0;
async function makeUser(fields?: {
  role?: string;
  userType?: string;
  college?: Types.ObjectId | null;
}): Promise<{ token: string; userId: string }> {
  counter += 1;
  const u = `cs${counter}`;
  await request(app)
    .post("/api/auth/register")
    .send({
      username: u,
      email: `${u}@example.com`,
      password: "Password123",
      fullName: `CS User ${counter}`,
      rollNumber: `CSU-${counter}`,
      collegeName: "Acme",
      phoneNumber: "9999999999",
      state: "KA",
    });
  const res = await request(app)
    .post("/api/auth/login")
    .send({ identifier: u, password: "Password123" });
  const userId = res.body.user.id as string;
  if (fields) await UserModel.updateOne({ _id: userId }, { $set: fields });
  return { token: res.body.accessToken as string, userId };
}

async function makeCollege(slug: string, createdBy: string): Promise<string> {
  const dto = await colleges.createCollege({ name: slug, slug }, createdBy);
  return dto.id;
}

/** A college with a college_admin + the `essays` feature on (unless disabled). */
async function setupCollege(
  slug: string,
  features: Record<string, boolean> = { essays: true },
): Promise<{ collegeId: string; adminToken: string }> {
  const platform = await makeUser({ role: Role.SUPER_ADMIN });
  const collegeId = await makeCollege(slug, platform.userId);
  await colleges.setEntitlements(collegeId, { features });
  const admin = await makeUser({
    role: Role.COLLEGE_ADMIN,
    userType: UserType.COLLEGE,
    college: new Types.ObjectId(collegeId),
  });
  return { collegeId, adminToken: admin.token };
}

async function createUnit(
  slug: string,
  token: string,
  body: { type: string; name: string; parentId?: string },
): Promise<string> {
  const res = await request(app)
    .post(`/api/c/${slug}/org-units`)
    .set(auth(token))
    .send(body);
  expect(res.status).toBe(201);
  return res.body.id as string;
}

async function addStudent(
  slug: string,
  token: string,
  email: string,
  roll: string,
  orgUnitId: string,
): Promise<{ id: string; token: string }> {
  const created = await request(app)
    .post(`/api/c/${slug}/students`)
    .set(auth(token))
    .send({ fullName: email, email, rollNumber: roll, orgUnitId });
  expect(created.status).toBe(201);
  const id = created.body.id as string;
  await UserModel.updateOne({ _id: id }, { $set: { forcePasswordChange: false } });
  const login = await request(app)
    .post("/api/auth/login")
    .send({ identifier: email, password: TEMP_PW });
  expect(login.status).toBe(200);
  return { id, token: login.body.accessToken as string };
}

/** Author + publish a college essay topic; returns its id. */
async function authorPublishedEssay(
  slug: string,
  adminToken: string,
  orgUnitIds: string[] = [],
): Promise<string> {
  const created = await request(app)
    .post(`/api/c/${slug}/essay-topics`)
    .set(auth(adminToken))
    .send({
      title: "The Climate Essay",
      description: "Discuss the causes and remedies of climate change.",
      instructions: "Write a structured argument in 150–400 words.",
      minWords: 5,
      semanticKeywords: ["climate", "emissions", "sustainability"],
      orgUnitIds,
    });
  expect(created.status).toBe(201);
  const id = created.body.id as string;
  const published = await request(app)
    .post(`/api/c/${slug}/essay-topics/${id}/publish`)
    .set(auth(adminToken))
    .send({ isPublished: true });
  expect(published.status).toBe(200);
  return id;
}

/** Simulate the grading worker finalizing an attempt (as essay.test.ts does). */
async function simulateGrade(jobId: string, finalScore = 74): Promise<void> {
  await EssayAttemptModel.updateOne(
    { gradingJobId: jobId },
    {
      $set: {
        gradingStatus: JobStatus.COMPLETED,
        finalScore,
        scoreSource: "deterministic_fallback",
        gradedAt: new Date(),
        feedback: "Solid structure and relevance.",
      },
    },
  );
}

describe("College essays — authoring + writing + grading", () => {
  it("author → publish → student writes + is graded → tenant results", async () => {
    const { adminToken } = await setupCollege("essa");
    const dept = await createUnit("essa", adminToken, {
      type: "department",
      name: "CSE",
    });
    const student = await addStudent(
      "essa",
      adminToken,
      "s1@essa.edu",
      "R1",
      dept,
    );
    // College-wide essay (no targeting).
    const essayId = await authorPublishedEssay("essa", adminToken);

    // Student sees it in their tenant list.
    const list = await request(app)
      .get(`/api/c/essa/essays`)
      .set(auth(student.token));
    expect(list.status).toBe(200);
    expect(list.body.items.map((e: { id: string }) => e.id)).toContain(essayId);

    // Detail (no reference keywords leaked).
    const detail = await request(app)
      .get(`/api/c/essa/essays/${essayId}`)
      .set(auth(student.token));
    expect(detail.status).toBe(200);
    expect(detail.body).not.toHaveProperty("semanticKeywords");
    expect(detail.body).not.toHaveProperty("referenceKeywords");

    // Autosave draft round-trips.
    const saved = await request(app)
      .put(`/api/c/essa/essays/${essayId}/draft`)
      .set(auth(student.token))
      .send({ content: "early thoughts on climate" });
    expect(saved.status).toBe(200);
    const gotDraft = await request(app)
      .get(`/api/c/essa/essays/${essayId}/draft`)
      .set(auth(student.token));
    expect(gotDraft.body.draft.content).toBe("early thoughts on climate");

    // Submit → grading job (fast), then simulate the worker + poll the SHARED
    // grading endpoint (authorized by attempt ownership — reused unchanged).
    const submit = await request(app)
      .post(`/api/c/essa/essays/${essayId}/submit`)
      .set(auth(student.token))
      .send({ content: LONG_ESSAY });
    expect(submit.status).toBe(202);
    const jobId = submit.body.jobId as string;
    expect(jobId).toBeTruthy();

    await simulateGrade(jobId, 74);
    const poll = await request(app)
      .get(`/api/essays/submissions/${jobId}`)
      .set(auth(student.token));
    expect(poll.status).toBe(200);
    expect(poll.body.status).toBe("completed");
    expect(poll.body.total).toBe(74);

    // The attempt is tenant-stamped.
    const attempt = await EssayAttemptModel.findOne({ gradingJobId: jobId });
    expect(attempt?.college?.toString()).toBeTruthy();

    // Operator results are tenant-scoped and show the submission.
    const results = await request(app)
      .get(`/api/c/essa/essay-topics/${essayId}/results`)
      .set(auth(adminToken));
    expect(results.status).toBe(200);
    expect(results.body.items).toHaveLength(1);
    expect(results.body.items[0].rollNumber).toBe("R1");
    expect(results.body.items[0].finalScore).toBe(74);
  });

  it("feature off → 403 for authoring and student list", async () => {
    const { adminToken } = await setupCollege("essb", { essays: false });
    const dept = await createUnit("essb", adminToken, {
      type: "department",
      name: "CSE",
    });
    const student = await addStudent("essb", adminToken, "b1@essb.edu", "B1", dept);

    const create = await request(app)
      .post(`/api/c/essb/essay-topics`)
      .set(auth(adminToken))
      .send({ title: "X", description: "d", instructions: "i" });
    expect(create.status).toBe(403);

    const list = await request(app)
      .get(`/api/c/essb/essays`)
      .set(auth(student.token));
    expect(list.status).toBe(403);
  });

  it("keyword generation works tenant-scoped", async () => {
    const { adminToken } = await setupCollege("essk");
    const res = await request(app)
      .post(`/api/c/essk/essay-topics/generate-keywords`)
      .set(auth(adminToken))
      .send({
        title: "Renewable Energy",
        description: "Solar and wind adoption",
        instructions: "",
      });
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body.keywords)).toBe(true);
    expect(res.body.keywords.length).toBeGreaterThan(0);
    expect(["llm", "deterministic"]).toContain(res.body.source);
  });

  it("faculty may only target org-units within their scope", async () => {
    const { collegeId, adminToken } = await setupCollege("essf");
    const unitA = await createUnit("essf", adminToken, {
      type: "department",
      name: "A",
    });
    const unitB = await createUnit("essf", adminToken, {
      type: "department",
      name: "B",
    });
    // A faculty scoped to unit A only.
    const faculty = await makeUser({
      role: Role.FACULTY,
      userType: UserType.COLLEGE,
      college: new Types.ObjectId(collegeId),
    });
    await UserModel.updateOne(
      { _id: faculty.userId },
      { $set: { facultyScope: { orgUnits: [new Types.ObjectId(unitA)] } } },
    );

    // Targeting unit B (out of scope) → denied.
    const denied = await request(app)
      .post(`/api/c/essf/essay-topics`)
      .set(auth(faculty.token))
      .send({
        title: "T",
        description: "d",
        instructions: "i",
        orgUnitIds: [unitB],
      });
    expect(denied.status).toBe(403);

    // Targeting unit A (in scope) → allowed.
    const ok = await request(app)
      .post(`/api/c/essf/essay-topics`)
      .set(auth(faculty.token))
      .send({
        title: "T",
        description: "d",
        instructions: "i",
        orgUnitIds: [unitA],
      });
    expect(ok.status).toBe(201);
  });

  it("hard isolation: College B + individuals cannot see/read College A's essay", async () => {
    const a = await setupCollege("essa1");
    const b = await setupCollege("essb1");
    const essayId = await authorPublishedEssay("essa1", a.adminToken);

    // College B admin: not in B's authoring list, and 404 on read/update/delete.
    const bList = await request(app)
      .get(`/api/c/essb1/essay-topics`)
      .set(auth(b.adminToken));
    expect(bList.status).toBe(200);
    expect(bList.body.items).toHaveLength(0);

    const bRead = await request(app)
      .get(`/api/c/essb1/essay-topics/${essayId}`)
      .set(auth(b.adminToken));
    expect(bRead.status).toBe(404);

    const bDelete = await request(app)
      .delete(`/api/c/essb1/essay-topics/${essayId}`)
      .set(auth(b.adminToken));
    expect(bDelete.status).toBe(404);

    // An individual (B2C) user: college essay never appears in the enrollment
    // list and is not readable via the individual endpoint.
    const indiv = await makeUser();
    const indivList = await request(app)
      .get(`/api/essays`)
      .set(auth(indiv.token));
    expect(indivList.status).toBe(200);
    expect(indivList.body.items.map((e: { id: string }) => e.id)).not.toContain(
      essayId,
    );
    const indivRead = await request(app)
      .get(`/api/essays/${essayId}`)
      .set(auth(indiv.token));
    expect(indivRead.status).toBe(404);
  });

  it("unpublished + not-targeted essays are neither listed nor writable", async () => {
    const { adminToken } = await setupCollege("essu");
    const unitA = await createUnit("essu", adminToken, {
      type: "department",
      name: "A",
    });
    const unitB = await createUnit("essu", adminToken, {
      type: "department",
      name: "B",
    });
    const student = await addStudent("essu", adminToken, "u1@essu.edu", "U1", unitA);

    // Unpublished (draft) essay → not listed, not writable (404).
    const draft = await request(app)
      .post(`/api/c/essu/essay-topics`)
      .set(auth(adminToken))
      .send({ title: "Draft", description: "d", instructions: "i", minWords: 5 });
    const draftId = draft.body.id as string;

    // Published but targeted at unit B (student is in unit A).
    const targetedB = await authorPublishedEssay("essu", adminToken, [unitB]);

    const list = await request(app)
      .get(`/api/c/essu/essays`)
      .set(auth(student.token));
    const ids = list.body.items.map((e: { id: string }) => e.id);
    expect(ids).not.toContain(draftId);
    expect(ids).not.toContain(targetedB);

    // Writing the draft → 404 (unpublished); writing targetedB → 403 (cohort).
    const submitDraft = await request(app)
      .post(`/api/c/essu/essays/${draftId}/submit`)
      .set(auth(student.token))
      .send({ content: LONG_ESSAY });
    expect(submitDraft.status).toBe(404);

    const submitB = await request(app)
      .post(`/api/c/essu/essays/${targetedB}/submit`)
      .set(auth(student.token))
      .send({ content: LONG_ESSAY });
    expect(submitB.status).toBe(403);
  });

  it("attempt cap is enforced tenant-scoped", async () => {
    const { adminToken } = await setupCollege("essc");
    const dept = await createUnit("essc", adminToken, {
      type: "department",
      name: "CSE",
    });
    const student = await addStudent("essc", adminToken, "c1@essc.edu", "C1", dept);
    // maxAttempts = 1 topic.
    const created = await request(app)
      .post(`/api/c/essc/essay-topics`)
      .set(auth(adminToken))
      .send({
        title: "OneShot",
        description: "d",
        instructions: "i",
        minWords: 5,
        maxAttempts: 1,
      });
    const id = created.body.id as string;
    await request(app)
      .post(`/api/c/essc/essay-topics/${id}/publish`)
      .set(auth(adminToken))
      .send({ isPublished: true });

    const first = await request(app)
      .post(`/api/c/essc/essays/${id}/submit`)
      .set(auth(student.token))
      .send({ content: LONG_ESSAY });
    expect(first.status).toBe(202);

    const second = await request(app)
      .post(`/api/c/essc/essays/${id}/submit`)
      .set(auth(student.token))
      .send({ content: LONG_ESSAY });
    expect(second.status).toBe(409); // ATTEMPT_LIMIT_REACHED
  });
});
